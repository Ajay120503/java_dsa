<%@ page import="java.sql.*" %>

<%
    String uname = request.getParameter("uname");
    String pass = request.getParameter("pass");

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/test", "root", "root");

        PreparedStatement ps = con.prepareStatement(
            "SELECT * FROM users WHERE uname=? AND pass=?");

        ps.setString(1, uname);
        ps.setString(2, pass);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            String fname = rs.getString(1);
%>
            <h2>Login Successful!</h2>
            <h3>Welcome <%= fname %></h3>
<%
        } else {
%>
            <h3>Invalid Username or Password</h3>
<%
        }

        con.close();

    } catch (Exception e) {
%>
        <h3>Error: <%= e.getMessage() %></h3>
<%
    }
%>