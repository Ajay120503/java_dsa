<html>
<body>

<form action="validate.jsp" method="post">

    Username:
    <input type="text" name="uname" required><br><br>
    Password:
    <input type="password" name="pass" required><br><br>
    <input type="submit" value="Login">

</form>

</body>
</html>