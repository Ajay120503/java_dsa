<html>
<body>

    <form action="display.jsp" method="get">
        Enter Extension: 
        <input type="text" name="ext">
        <input type="submit" value="Search">
    </form>
</body>
</html>