<%@ page import="java.io.*" %>

<html>
<body>

<%
    String ext = request.getParameter("ext");

    if (ext != null && !ext.trim().isEmpty()) {

        String path = application.getRealPath(".");
        File dir = new File(path);

        File[] files = dir.listFiles();

        boolean found = false;

        for (File f : files) {
            if (f.isFile() && f.getName().endsWith("." + ext)) {
                found = true;
%>
                <a href="<%= f.getName() %>">
                <%= f.getName() %></a><br>
<%
            }
        }

        if (!found) {
            out.println("<p>No files found!</p>");
        }
    } else {
        out.println("<p>Invalid extension!</p>");
    }
%>

</body>
</html>