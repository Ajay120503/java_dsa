<%
    String color = request.getParameter("color");

    if (color == null || color.trim().equals("")) {
        color = "white";
    }
%>

<html>

<body style="background-color:<%= color %>;">

    <h2 align="center">
        Selected Color: <%= color.toUpperCase() %>
    </h2>

</body>
</html>