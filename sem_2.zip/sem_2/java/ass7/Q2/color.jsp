<html>
<body>

<div style="text-align:center;">

    <a href="result.jsp?color=red">
        <div style="width:100px;height:100px;background:red;display:inline-block;"></div>
    </a>

    <a href="result.jsp?color=green">
        <div style="width:100px;height:100px;background:green;display:inline-block;"></div>
    </a>

    <a href="result.jsp?color=blue">
        <div style="width:100px;height:100px;background:blue;display:inline-block;"></div>
    </a>

    <br><br>
    <a href="#">Select the color</a>

</div>

</body>
</html>