<html>
<head>
    <title>Registration Form</title>
</head>
<body>

<h2>Registration Form</h2>

<form action="save.jsp" method="post">

    First Name: <input type="text" name="fname" required><br><br>
    Last Name: <input type="text" name="lname" required><br><br>
    Username: <input type="text" name="uname" required><br><br>
    Password: <input type="password" name="pass" required><br><br>
    Address: <textarea name="addr" required></textarea><br><br>
    Contact: <input type="text" name="contact" required><br><br>

    <input type="submit" value="Register">

</form>

</body>
</html>