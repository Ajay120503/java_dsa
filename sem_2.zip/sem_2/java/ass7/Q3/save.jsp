<%@ page import="java.sql.*" %>

<%
    String fname = request.getParameter("fname");
    String lname = request.getParameter("lname");
    String uname = request.getParameter("uname");
    String pass = request.getParameter("pass");
    String addr = request.getParameter("addr");
    String contact = request.getParameter("contact");

    try {
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/test", "root", "root");

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO users VALUES (?, ?, ?, ?, ?, ?)");

        ps.setString(1, fname);
        ps.setString(2, lname);
        ps.setString(3, uname);
        ps.setString(4, pass);
        ps.setString(5, addr);
        ps.setString(6, contact);

        int result = ps.executeUpdate();

        if (result > 0) {
%>
            <h2>Welcome <%= fname %></h2>
<%
        } else {
            out.println("<h3>Registration Failed</h3>");
        }

        con.close();

    } catch (Exception e) {
        out.println("Error: " + e);
    }
%>


<!-- 

CREATE TABLE users (
    fname VARCHAR(50),
    lname VARCHAR(50),
    uname VARCHAR(50),
    pass VARCHAR(50),
    addr VARCHAR(100),
    contact VARCHAR(15)
);

-->