class Employee{
   String name;
   String position;
   double salary;

   static int count = 0;

   Employee(String name, String position, double salary){
      this.name = name;
      this.position = position;
      this.salary = salary;

      count++;
   }

   public String toString(){
      return "Name "+name+"Position "+position+"Salary "+salary;
   }

   public static int getCount(){
      return count;
   }
}


public class AssQ1{
     public static void main(String args[]){
        Employee emp1 = new Employee("Samarth","MERN developer",5.8);
        System.out.println(emp1);

        System.out.println("count is "+Employee.getCount());

        Employee emp2 = new Employee("Rohit","UI/UX developer",9.5);
        System.out.println(emp2);

        System.out.println("count is "+Employee.getCount());
    }
}