import java.util.Scanner;

class Student{

    int rollNo;
    String name;
    double percentage;

    Student(){
        rollNo = 256307;
        name = "Ajay Kandhare";
        percentage = 40.57;
    }

    Student(int rollNo, String name, double percentage){
        this.rollNo = rollNo;
        this.name = name;
        this.percentage = percentage;
    }

    void display(){
        System.out.println("Roll No. :"+rollNo+"\nName :"+name+"\nPercentage : "+percentage);
    }

    static void sortStudent(Student[] s, int n){
        Student temp;
        for(int i=0;i<n-1;i++){
            for(int j=i+1;j<n;j++){
                if(s[i].percentage < s[j].percentage){
                    temp = s[i];
                    s[i] = s[j];
                    s[j] = temp;
                }
            }
        }
    }

    public static void main(String args[]){

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the Student count : ");
        int n = sc.nextInt();

        Student[ ] student = new Student[n];

        System.out.println("Enter the Student Details : ");
        for(int i=0;i<n;i++){
            student[i] = new Student(sc.nextInt(), sc.next(), sc.nextDouble());
        }

        Student.sortStudent(student, n);

        System.out.println("Student details : ");
        for(int i=0;i<n;i++){
            student[i].display();
        }
    }
}
