import java.util.Scanner;

class Matrix{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the row and col size : ");
        int row = sc.nextInt();
        int col = sc.nextInt();

        int[][] a = new int[row][col];
        int[][] b = new int[row][col];
        int[][] sum = new int[row][col];

        System.out.println("Enter the Maxtrix A : ");
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                a[i][j] = sc.nextInt();
            }
        }

        System.out.println("Enter the Maxtrix B : ");
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                b[i][j] = sc.nextInt();
            }
        }

        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                sum[i][j] = a[i][j] + b[i][j];
            }
        }

        System.out.println("Sum of Matrix A and B is  : ");
         for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                 System.out.print(sum[i][j]+" ");
            }
                 System.out.println();
        }

    }
}