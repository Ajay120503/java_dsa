class Number{

    private int num;

    Number(){
        this.num = 0;
    }

    Number(int num){
        this.num = num;
    }

    void checkOddEven(){

        if(num%2==0){
            System.out.println("Even");
        }else{
            System.out.println("Odd");
        }
    }

    void checkPosNeg(){
        if(num>0){
            System.out.println("Positive");
        }else if(num<0){
            System.out.println("Negative");
        }else{
            System.out.println("Zero");
        }
    }

    public static void main(String args[]){
        int value = Integer.parseInt(args[0]);

        Number number = new Number(value);
        number.checkOddEven();
        number.checkPosNeg();
    }
}