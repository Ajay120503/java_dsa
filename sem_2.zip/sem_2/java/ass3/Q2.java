abstract class Shape {
    abstract void calcArea();
    abstract void calcVolume();
}

class Sphere extends Shape {
    double r;
    Sphere(double r) { 
        this.r = r; 
    }

    void calcArea() {
        System.out.println("Sphere Area: " + (4 * Math.PI * r * r));
    }

    void calcVolume() {
        System.out.println("Sphere Volume: " + ((4.0 / 3) * Math.PI * r * r * r));
    }
}

class Cone extends Shape {
    double r, h;
    
    Cone(double r, double h){
            this.r = r;
            this.h = h; 
    }

    void calcArea() {
        System.out.println("Cone Area: " + (Math.PI * r * (r + Math.sqrt(h*h + r*r))));
    }

    void calcVolume() {
        System.out.println("Cone Volume: " + ((1.0 / 3) * Math.PI * r * r * h));
    }
}

class Cylinder extends Shape {
    double r, h;
    Cylinder(double r, double h) { 
        this.r = r; 
        this.h = h; 
    }

    void calcArea() {
        System.out.println("Cylinder Area: " + (2 * Math.PI * r * (r + h)));
    }

    void calcVolume() {
        System.out.println("Cylinder Volume: " + (Math.PI * r * r * h));
    }
}

class Q2 extends Shape {
    
    double l, b, h;
    Q2(double l, double b, double h) {
        this.l = l; this.b = b; this.h = h;
    }

    void calcArea() {
        System.out.println("Box Area: " + (2 * (l*b + b*h + l*h)));
    }

    void calcVolume() {
        System.out.println("Box Volume: " + (l * b * h));
    }

    public static void main(String[] args) {
        Shape s;

        s = new Sphere(5);
        s.calcArea(); s.calcVolume();

        s = new Cone(3, 4);
        s.calcArea(); s.calcVolume();

        s = new Cylinder(3, 5);
        s.calcArea(); s.calcVolume();

        s = new Q2(2, 3, 4);
        s.calcArea(); s.calcVolume();
    }
}
