import java.util.Scanner;

class Vehicle {
    String company;
    double price;

    Vehicle(String c, double p) {
        company = c;
        price = p;
    }
}

class LightMotorVehicle extends Vehicle {
    double mileage;

    LightMotorVehicle(String c, double p, double m) {
        super(c, p);
        mileage = m;
    }

    void display() {
        System.out.println(company + " " + price + " Mileage: " + mileage);
    }
}

class Q6 extends Vehicle {
    double capacity;

    Q6(String c, double p, double cap) {
        super(c, p);
        capacity = cap;
    }

    void display() {
        System.out.println("company "+company +" "+"price " + price + " Capacity: " + capacity + " tons");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter vehicle type (1-Light, 2-Heavy): ");
        int ch = sc.nextInt();

        if (ch == 1) {
            System.out.println("company price capacity");
            new LightMotorVehicle(sc.next(), sc.nextDouble(), sc.nextDouble()).display();
        } else {
            System.out.println("company price capacity");
            new HeavyMotorVehicle(sc.next(), sc.nextDouble(), sc.nextDouble()).display();
        }
    }
}
