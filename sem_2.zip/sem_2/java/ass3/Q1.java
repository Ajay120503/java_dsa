import java.util.Scanner;

class Employee {
    private int id;
    private String name, department;
    protected double salary;

    Employee() {
        id = 0;
        name = "NA";
        department = "NA";
        salary = 0.0f;
    }

    Employee(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Department: " + department);
        System.out.println("Salary: " + salary);
    }
}

class Q1 extends Employee {
    private double bonus;

    Q1(int id, String name, String dept, double salary, double bonus) {
        super(id, name, dept, salary);
        this.bonus = bonus;
    }

    double totalSalary() {
        return salary + bonus;
    }

    void display() {
        super.display();
        System.out.println("Bonus: " + bonus);
        System.out.println("Total Salary: " + totalSalary());
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of managers: ");
        int n = sc.nextInt();

        Q1[] m = new Q1[n];
        int maxIndex = 0;

        for (int i = 0; i < n; i++) {
            System.out.println("\nManager " + (i + 1));
            System.out.println("id name department salary bounce");
            m[i] = new Q1(
                    sc.nextInt(),
                    sc.next(),
                    sc.next(),
                    sc.nextDouble(),
                    sc.nextDouble()
            );
            if (m[i].totalSalary() > m[maxIndex].totalSalary())
                maxIndex = i;
        }

        System.out.println("\nManager with Maximum Salary:");
        m[maxIndex].display();
    }
}
