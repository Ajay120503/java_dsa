import java.util.*;

abstract class Staff {
    String name, address;
    Staff(String name, String address) {
        this.name = name;
        this.address = address;
    }
    abstract void display();
}

class FullTimeStaff extends Staff {
    String department;
    double salary;

    FullTimeStaff(String n, String a, String d, double s) {
        super(n, a);
        department = d;
        salary = s;
    }

    void display() {
        System.out.println(name + " | " + address + " | " + department + " | Salary: " + salary);
    }
}

class PartTimeStaff extends Staff {
    int hours;
    double rate;

    PartTimeStaff(String n, String a, int h, double r) {
        super(n, a);
        hours = h;
        rate = r;
    }

    void display() {
        System.out.println(name + " | " + address + " | Hours: " + hours + " | Pay: " + (hours * rate));
    }
}

class Q3{
    public static void main(String args[]){

	Scanner sc = new Scanner(System.in);
	
    int choice;
    
    do{
		System.out.print("\n1. Fulltime staff\n2. Parttime staff\n3. Exit\nEnter the Choice : ");
		choice = sc.nextInt();
		
		switch(choice){
			case 1:
				System.out.print("Enter the staff count : ");
				int temp = sc.nextInt();
				FullTimeStaff[] fulltime= new FullTimeStaff[temp];
				for(int i = 0; i < temp; i++){
					System.out.println("Fulltime "+(i+1)+":");
					System.out.println("name address department salary");
					fulltime[i] = new FullTimeStaff(sc.next(), sc.next(), sc.next(), sc.nextDouble());
				
					fulltime[i].display();
				}
				
				break;
			case 2:
				System.out.print("Enter the staff count : ");
				int temp_ = sc.nextInt();
				PartTimeStaff[] parttime = new PartTimeStaff[temp_];
				for(int i = 0; i < temp_; i++){
					System.out.println("Parttime "+(i+1)+":");
					System.out.println("name address department salary");
					parttime[i] = new PartTimeStaff(sc.next(), sc.next(), sc.nextInt(), sc.nextDouble());
				
				}
				
				for(PartTimeStaff staff : parttime){
					staff.display();
				}
				break;
			case 3:
				break;
			default:
				System.out.println("invalid choice");
		}
		
		}while(choice!=3);
    }
}
