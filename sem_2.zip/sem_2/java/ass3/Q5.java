interface CreditCardInterface{
    void viewCreditAmount();
    void useCard(float amount);
    void payCredit(float amount);
    void increaseLimit();
}

class SilverCardCustomer implements CreditCardInterface{
    String name;
    String cardnumber;
    float creditAmount=0;
    private float creditLimit=50000;
    SilverCardCustomer(String name,String cardnumber){
        this.name = name;
        this.cardnumber = cardnumber;
    }

    public void viewCreditAmount(){
        System.out.println("Credit amount: "+creditAmount);
    }
    
    public void useCard(float amount){
        if(amount > (creditLimit - creditAmount)){
        System.out.println("Over Card limit");
        return;
        } else {
            this.creditAmount+=amount;
            getremainingamount();
        }
    }

    public void payCredit(float amount){
        if((creditAmount - amount) < 0 ){
            System.out.println("credit amount cannot be negative");
        } else {
            creditAmount -= amount;
            getremainingamount();
        }
    }
    public void increaseLimit(){
        System.out.println("Cannot increase limit for Silver Card");
    }

    public void getremainingamount(){
        System.out.println("remaining amount: "+(creditLimit - creditAmount));
    }
}

class GoldCardCustomer extends SilverCardCustomer{
    String name;
    String cardnumber;
    float creditAmount=0;
    private float creditLimit=100000;

    GoldCardCustomer(String name,String cardnumber){
        super(name,cardnumber);
    }
    public void viewCreditAmount(){
        System.out.println("Credit amount: "+creditAmount);
    }
    
    public void useCard(float amount){
        if(amount > (creditLimit - creditAmount)){
        System.out.println("Over Card limit");
        return;
        } else {
            this.creditAmount+=amount;
            getremainingamount();
        }
    }
    public void payCredit(float amount){
        if((creditAmount - amount) < 0 ){
            System.out.println("credit amount cannot be negative");
        } else {
            creditAmount -= amount;
            getremainingamount();
        }
    }
    public void increaseLimit(){
        if(creditLimit > 150000){
         System.out.println("Cannot increase the limit more"); 
        } else{
            creditLimit += 5000;
            System.out.println("Limit increases by 5000");
        }
        
    }
     public void getremainingamount(){
        System.out.println("remaining amount: "+(creditLimit - creditAmount));
    }

    float getCreditLimit(){
        return creditLimit;
    }
}
public class Q5{
    public static void main(String[] args){
        SilverCardCustomer S = new SilverCardCustomer("Harshada","1234567891023654");
        System.out.println("Silver card customer Details");
        S.useCard(40000);
        S.useCard(20000);
        S.payCredit(30000);
        S.increaseLimit();

        GoldCardCustomer G =new GoldCardCustomer("Ajay","5456554455655");
        System.out.println("Gold card customer Details");
        G.useCard(40000);
        G.useCard(20000);
        G.payCredit(30000);
        G.increaseLimit();
        System.out.println("After increase: "+ G.getCreditLimit());
    }
}