import java.util.*;

interface JavaArray {
    void arrayReverse();
    void arrayCopy();
    void arrayMax();
}

class Q4 implements JavaArray {
    int[] arr;

    Q4(int[] arr) {
        this.arr = arr;
    }

    public void arrayReverse() {
        System.out.print("Reversed Array: ");
        for (int i = arr.length - 1; i >= 0; i--)
            System.out.print(arr[i] + " ");
        System.out.println();
    }

    public void arrayCopy() {
        int[] copy = arr.clone();
        System.out.println("Copied Array: " + Arrays.toString(copy));
    }

    public void arrayMax() {
        int max = Arrays.stream(arr).max().getAsInt();
        System.out.println("Maximum Element: " + max);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] a = new int[5];
        System.out.println("Enter the "+a.length+" elements :");
        for (int i = 0; i < 5; i++)
            a[i] = sc.nextInt();

        Q4 op = new Q4(a);
        op.arrayReverse();
        op.arrayCopy();
        op.arrayMax();
    }
}
