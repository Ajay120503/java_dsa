import java.sql.*;

public class BookTable {
    public static void main(String[] args) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/mcafy7", "mcafy7", "");

            Statement stmt = con.createStatement();

            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS Book(" +
                "bookname VARCHAR(50), " +
                "author VARCHAR(50), " +
                "isbn VARCHAR(20), " +
                "price FLOAT)");

            stmt.executeUpdate("INSERT INTO Book VALUES('Java', 'James', '111', 500)");
            stmt.executeUpdate("INSERT INTO Book VALUES('C++', 'Bjarne', '222', 600)");
            stmt.executeUpdate("INSERT INTO Book VALUES('Python', 'Guido', '333', 700)");
            stmt.executeUpdate("INSERT INTO Book VALUES('DBMS', 'Korth', '444', 550)");
            stmt.executeUpdate("INSERT INTO Book VALUES('OS', 'Silberschatz', '555', 650)");

            System.out.println("Table created and records inserted!");

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}