import java.sql.*;
import java.util.Scanner;

public class DBMetadataDemo {
    public static void main(String[] args) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/mcafy7", "mcafy7", "");

            Scanner sc = new Scanner(System.in);
            int choice;

            do {
                System.out.println("\n--- MENU ---");
                System.out.println("1. Database Info");
                System.out.println("2. List Tables");
                System.out.println("3. Column Info");
                System.out.println("4. Exit");
                System.out.print("Enter choice: ");
                choice = sc.nextInt();

                switch (choice) {
                    case 1:
                        DatabaseMetaData dbmd = con.getMetaData();
                        System.out.println("Driver Name: " + dbmd.getDriverName());
                        System.out.println("Driver Version: " + dbmd.getDriverVersion());
                        System.out.println("User: " + dbmd.getUserName());
                        System.out.println("Database Product: " + dbmd.getDatabaseProductName());
                        break;

                    case 2:
                        DatabaseMetaData dbmd2 = con.getMetaData();
                        ResultSet tables = dbmd2.getTables(null, null, "%", null);
                        System.out.println("Tables:");
                        while (tables.next()) {
                            System.out.println(tables.getString(3));
                        }
                        break;

                    case 3:
                        sc.nextLine();
                        System.out.print("Enter table name: ");
                        String tableName = sc.nextLine();

                        Statement stmt = con.createStatement();
                        ResultSet rs = stmt.executeQuery("SELECT * FROM " + tableName);
                        ResultSetMetaData rsmd = rs.getMetaData();

                        int count = rsmd.getColumnCount();
                        System.out.println("Columns:");
                        for (int i = 1; i <= count; i++) {
                            System.out.println(rsmd.getColumnName(i) + " - " +
                                               rsmd.getColumnTypeName(i));
                        }
                        break;

                    case 4:
                        System.out.println("Exiting...");
                        break;

                    default:
                        System.out.println("Invalid choice!");
                }
            } while (choice != 4);

            con.close();
            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}