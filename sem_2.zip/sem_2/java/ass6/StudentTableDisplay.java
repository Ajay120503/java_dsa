import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class StudentTableDisplay extends JFrame {

    JTable table;
    DefaultTableModel model;

    public StudentTableDisplay() {
        setTitle("Student Table Data");

        String[] columns = {"Roll No", "Name", "Marks"};
        model = new DefaultTableModel(columns, 0);

        table = new JTable(model);
        JScrollPane pane = new JScrollPane(table);

        add(pane);

        loadData();

        setSize(500, 300);
        setVisible(true);
    }

    void loadData() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/mcafy7", "mcafy7", "");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Student");

            while (rs.next()) {
                int roll = rs.getInt(1);
                String name = rs.getString(2);
                int marks = rs.getInt(3);

                model.addRow(new Object[]{roll, name, marks});
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new StudentTableDisplay();
    }
}