import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentCRUD extends JFrame implements ActionListener {

    JTextField t1, t2, t3;
    JButton add, delete, update, search, clear, exit;

    Connection con;

    public StudentCRUD() {
        setTitle("Student CRUD");

        t1 = new JTextField(15);
        t2 = new JTextField(15);
        t3 = new JTextField(15);

        add = new JButton("Add");
        delete = new JButton("Delete");
        update = new JButton("Update");
        search = new JButton("Search");
        clear = new JButton("Clear");
        exit = new JButton("Exit");

        setLayout(new GridLayout(5,2));

        add(new JLabel("Roll No")); add(t1);
        add(new JLabel("Name")); add(t2);
        add(new JLabel("Marks")); add(t3);

        add(add); add(delete);
        add(update); add(search);
        add(clear); add(exit);

        add.addActionListener(this);
        delete.addActionListener(this);
        update.addActionListener(this);
        search.addActionListener(this);
        clear.addActionListener(this);
        exit.addActionListener(this);

        try {
            con = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/mcafy7", "mcafy7", "");
        } catch (Exception e) {
            e.printStackTrace();
        }

        setSize(350,300);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        try {
            int roll = Integer.parseInt(t1.getText());
            String name = t2.getText();
            int marks = Integer.parseInt(t3.getText());

            if (e.getSource() == add) {
                PreparedStatement ps = con.prepareStatement("INSERT INTO Student VALUES (?, ?, ?)");
                ps.setInt(1, roll);
                ps.setString(2, name);
                ps.setInt(3, marks);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Added");
            }

            if (e.getSource() == delete) {
                int confirm = JOptionPane.showConfirmDialog(
                    this, "Delete Record?");
                if (confirm == 0) {
                    PreparedStatement ps = con.prepareStatement("DELETE FROM Student WHERE roll=?");
                    ps.setInt(1, roll);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Deleted");
                }
            }

            if (e.getSource() == update) {
                PreparedStatement ps = con.prepareStatement("UPDATE Student SET name=?, marks=? WHERE roll=?");
                ps.setString(1, name);
                ps.setInt(2, marks);
                ps.setInt(3, roll);

                int rows = ps.executeUpdate();
                if (rows > 0)
                    JOptionPane.showMessageDialog(this, "Updated");
                else
                    JOptionPane.showMessageDialog(this, "Not Updated");
            }

            if (e.getSource() == search) {
                PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM Student WHERE roll=?");
                ps.setInt(1, roll);

                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    t2.setText(rs.getString(2));
                    t3.setText(rs.getString(3));
                } else {
                    JOptionPane.showMessageDialog(this, "Not Found");
                }
            }

            if (e.getSource() == clear) {
                t1.setText("");
                t2.setText("");
                t3.setText("");
            }

            if (e.getSource() == exit) {
                System.exit(0);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid Input!");
        }
    }

    public static void main(String[] args) {
        new StudentCRUD();
    }
}