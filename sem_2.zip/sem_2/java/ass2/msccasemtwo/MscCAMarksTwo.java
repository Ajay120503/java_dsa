package msccasemtwo;

public class MscCAMarksTwo{
    public int sem_1_total;
	public int sem_2_total;
	
	public int getTotal(){
		return sem_1_total + sem_2_total;
	}
}
