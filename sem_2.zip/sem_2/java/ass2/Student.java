import msccasemone.*;
import msccasemtwo.*;

public class Student{
	
	int rollNo;
	String name;
	MscCAMarksOne m1;
	MscCAMarksTwo m2;

	public Student(int rollNo, String name, MscCAMarksOne m1, MscCAMarksTwo m2){
		this.rollNo = rollNo;
		this.name = name;
		this.m1 = m1;
		this.m2 = m2; 
	}	
	
	public void displayResult(){
		int total = m1.getTotal() + m2.getTotal();
		float percentage = total / 4.0f;

		String grade;
		if(percentage >= 70) grade = "A";
		else if(percentage >= 60) grade = "B";
		else if(percentage >= 50) grade = "C";
		else if(percentage >= 40) grade = "Pass";
		else grade = "Fail";

		System.out.println("Roll no : "+rollNo+"\nname : "+name+"\ntotal marks : "+total+"\npercentage : "+percentage+"\ngrade : "+grade+"\n--------------------\n");
	}
	

}
