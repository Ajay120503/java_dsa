import numoperation.*;

class Main{
    public static void main(String args[]){
        int n = Integer.parseInt(args[0]);

        PrimeNumber prime = new PrimeNumber();
        PerfectNumber perfect = new PerfectNumber();
        ArmstrongNumber armstrong = new ArmstrongNumber();

        if(prime.isPrime(n)) System.out.println("Yes is prime"); // 2
        else System.out.println("is Not prime");

        if(perfect.isPerfect(n)) System.out.println("Yes is pefect"); // 6
        else System.out.println("is Not perfect");

        if(armstrong.isArmstrog(n)) System.out.println("Yes is armstrong"); // 153
        else System.out.println("is Not armstrong");
    }
}
