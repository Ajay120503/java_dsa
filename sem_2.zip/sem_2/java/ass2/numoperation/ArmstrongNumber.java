package numoperation;

 public class ArmstrongNumber{
    public boolean isArmstrog(int n){
        int temp = n;
        int sum = 0;
        int digit;

        while(temp>0){
            digit = temp % 10;
            sum += digit * digit * digit;
            temp /= 10;
        }
        return sum == n;
    }
 } 
