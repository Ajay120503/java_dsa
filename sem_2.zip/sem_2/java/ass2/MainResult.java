import java.util.Scanner;
import msccasemone.*;
import msccasemtwo.*;

class MainResult
{
    public static void main(String args[])
    {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter the n : ");
		int n = sc.nextInt();
		
		Student student[] = new Student[n];
		
		for(int i=0;i<n;i++){
			System.out.println("Enter the "+(i+1)+" student details : ");
			System.out.print("Enter the "+(i+1)+" rollno : ");
			int rollNo = sc.nextInt();
			
			System.out.print("Enter the "+(i+1)+" name : ");
			String name = sc.next();
			
			MscCAMarksOne m1 = new MscCAMarksOne();
			MscCAMarksTwo m2 = new MscCAMarksTwo();
			
			System.out.print("Enter the sem-1 total marks : ");
			m1.sem_1_total = sc.nextInt();
			
			System.out.print("Enter the sem-2 total marks : ");
			m1.sem_2_total = sc.nextInt();
			
			System.out.print("Enter the sem-1 total marks : ");
			m2.sem_1_total = sc.nextInt();
			
			System.out.print("Enter the sem-2 total marks : ");
			m2.sem_2_total = sc.nextInt();
			
			student[i] = new Student(rollNo, name, m1, m2);
					
		}
		System.out.println("Student Details : ");
		for(Student st: student){
		System.out.println();
			st.displayResult();
		}
  	}
}
