import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FontStyleDemo {

    // Constructor
    FontStyleDemo() {

        // Frame
        JFrame frame = new JFrame("Font Style Demo");
        frame.setSize(350,250);
        frame.setLayout(null);

        // Label (Text to change style)
        JLabel lblText = new JLabel("Hello Everyone");
        lblText.setBounds(90, 30, 200, 30);
        lblText.setFont(new Font("Arial", Font.PLAIN, 18));

        // CheckBoxes
        JCheckBox chkBold = new JCheckBox("Bold");
        chkBold.setBounds(70, 80, 80, 25);

        JCheckBox chkItalic = new JCheckBox("Italic");
        chkItalic.setBounds(170, 80, 80, 25);

        // Buttons
        JButton btnApply = new JButton("Apply");
        btnApply.setBounds(60, 140, 100, 30);

        JButton btnExit = new JButton("Exit");
        btnExit.setBounds(180, 140, 100, 30);

        // Add components
        frame.add(lblText);
        frame.add(chkBold);
        frame.add(chkItalic);
        frame.add(btnApply);
        frame.add(btnExit);

        // Apply Button Event
        btnApply.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                int style = Font.PLAIN;

                if(chkBold.isSelected() && chkItalic.isSelected())
                    style = Font.BOLD | Font.ITALIC;
                else if(chkBold.isSelected())
                    style = Font.BOLD;
                else if(chkItalic.isSelected())
                    style = Font.ITALIC;

                lblText.setFont(new Font("Arial", style, 18));
            }
        });

        // Exit Button Event
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Main Method
    public static void main(String[] args) {
        new FontStyleDemo();
    }
}