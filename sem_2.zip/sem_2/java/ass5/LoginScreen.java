import javax.swing.*;
import java.awt.event.*;

public class LoginScreen {

    // Constructor
    LoginScreen() {

        // Frame
        JFrame frame = new JFrame("Login Form");
        frame.setSize(350,220);
        frame.setLayout(null);

        // Labels
        JLabel lblUser = new JLabel("User Name");
        lblUser.setBounds(40, 30, 80, 25);

        JLabel lblPass = new JLabel("Password");
        lblPass.setBounds(40, 70, 80, 25);

        // Text Fields
        JTextField txtUser = new JTextField();
        txtUser.setBounds(140, 30, 140, 25);

        JPasswordField txtPass = new JPasswordField();
        txtPass.setBounds(140, 70, 140, 25);

        // Buttons
        JButton btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(60, 120, 90, 30);

        JButton btnCancel = new JButton("Cancel");
        btnCancel.setBounds(170, 120, 90, 30);

        // Add components
        frame.add(lblUser);
        frame.add(lblPass);
        frame.add(txtUser);
        frame.add(txtPass);
        frame.add(btnSubmit);
        frame.add(btnCancel);

        // Submit Button Event
        btnSubmit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String username = txtUser.getText();
                String password = new String(txtPass.getPassword());

                if(username.equals(password))
                    JOptionPane.showMessageDialog(frame,
                            "Correct login details");
                else
                    JOptionPane.showMessageDialog(frame,
                            "Wrong details");
            }
        });

        // Cancel Button Event
        btnCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                txtUser.setText("");
                txtPass.setText("");
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Main Method
    public static void main(String[] args) {
        new LoginScreen();
    }
}