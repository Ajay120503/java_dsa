import javax.swing.*;
import java.awt.*;

public class FontFamilies {

    // Constructor
    FontFamilies() {

        // Frame
        JFrame frame = new JFrame("Font Families");
        frame.setSize(400,350);
        frame.setLayout(null);

        // Label
        JLabel lblTitle = new JLabel("Available Font Families");
        lblTitle.setBounds(110, 10, 200, 25);

        // TextArea
        JTextArea area = new JTextArea();
        area.setEditable(false);

        // Scroll Pane
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBounds(40, 40, 300, 240);

        // Get System Fonts
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();

        String fonts[] = ge.getAvailableFontFamilyNames();

        // Display fonts
        for(String f : fonts) {
            area.append(f + "\n");
        }

        // Add components
        frame.add(lblTitle);
        frame.add(scroll);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Main Method
    public static void main(String[] args) {
        new FontFamilies();
    }
}