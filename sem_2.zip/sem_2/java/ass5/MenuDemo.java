import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class MenuDemo {

    // Constructor
    MenuDemo() {

        // Frame
        JFrame frame = new JFrame("Menu Example");
        frame.setSize(500,400);
        frame.setLayout(null);

        // Text Area
        JTextArea area = new JTextArea();
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBounds(20, 20, 440, 300);

        frame.add(scroll);

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();

        // File Menu
        JMenu fileMenu = new JMenu("File");

        JMenuItem newItem = new JMenuItem("New");
        JMenuItem openItem = new JMenuItem("Open");
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem exitItem = new JMenuItem("Exit");

        // Add items
        fileMenu.add(newItem);
        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        fileMenu.addSeparator();   // Separator before Exit
        fileMenu.add(exitItem);

        menuBar.add(fileMenu);
        frame.setJMenuBar(menuBar);

        // NEW Menu Event
        newItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                area.setText("");
            }
        });

        // OPEN Menu Event
        openItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JFileChooser chooser = new JFileChooser();
                int result = chooser.showOpenDialog(frame);

                if(result == JFileChooser.APPROVE_OPTION) {

                    File file = chooser.getSelectedFile();

                    try {
                        BufferedReader br =
                                new BufferedReader(new FileReader(file));

                        area.setText("");
                        String line;

                        while((line = br.readLine()) != null) {
                            area.append(line + "\n");
                        }

                        br.close();

                    } catch(Exception ex) {
                        JOptionPane.showMessageDialog(frame,
                                "Error opening file");
                    }
                }
            }
        });

        // SAVE Menu Event (simple save)
        saveItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JFileChooser chooser = new JFileChooser();
                int result = chooser.showSaveDialog(frame);

                if(result == JFileChooser.APPROVE_OPTION) {

                    File file = chooser.getSelectedFile();

                    try {
                        BufferedWriter bw =
                                new BufferedWriter(new FileWriter(file));

                        bw.write(area.getText());
                        bw.close();

                        JOptionPane.showMessageDialog(frame,
                                "File Saved Successfully");

                    } catch(Exception ex) {
                        JOptionPane.showMessageDialog(frame,
                                "Error saving file");
                    }
                }
            }
        });

        // EXIT Menu Event
        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Main Method
    public static void main(String[] args) {
        new MenuDemo();
    }
}