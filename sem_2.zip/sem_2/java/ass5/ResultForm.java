import javax.swing.*;
import java.awt.event.*;

public class ResultForm {

    // Constructor
    ResultForm() {

        // Frame
        JFrame frame = new JFrame("Student Result");
        frame.setSize(350,300);
        frame.setLayout(null);

        // Labels
        JLabel lblRoll = new JLabel("Roll Number");
        lblRoll.setBounds(30, 20, 100, 25);

        JLabel lblName = new JLabel("Name");
        lblName.setBounds(30, 60, 100, 25);

        JLabel lblCE = new JLabel("CE Marks");
        lblCE.setBounds(30, 100, 100, 25);

        JLabel lblESE = new JLabel("ESE Marks");
        lblESE.setBounds(30, 140, 100, 25);

        JLabel lblTotal = new JLabel("Total:");
        lblTotal.setBounds(30, 220, 150, 25);

        JLabel lblGrade = new JLabel("Grade:");
        lblGrade.setBounds(180, 220, 120, 25);

        // TextFields
        JTextField txtRoll = new JTextField();
        txtRoll.setBounds(140, 20, 150, 25);

        JTextField txtName = new JTextField();
        txtName.setBounds(140, 60, 150, 25);

        JTextField txtCE = new JTextField();
        txtCE.setBounds(140, 100, 150, 25);

        JTextField txtESE = new JTextField();
        txtESE.setBounds(140, 140, 150, 25);

        // Button
        JButton btnCalc = new JButton("Calculate");
        btnCalc.setBounds(100, 180, 120, 30);

        // Add components
        frame.add(lblRoll);
        frame.add(lblName);
        frame.add(lblCE);
        frame.add(lblESE);
        frame.add(lblTotal);
        frame.add(lblGrade);

        frame.add(txtRoll);
        frame.add(txtName);
        frame.add(txtCE);
        frame.add(txtESE);
        frame.add(btnCalc);

        // Button Event
        btnCalc.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                int ce = Integer.parseInt(txtCE.getText());
                int ese = Integer.parseInt(txtESE.getText());

                int total = ce + ese;

                lblTotal.setText("Total: " + total);

                if(total >= 75)
                    lblGrade.setText("Grade: A");
                else if(total >= 50)
                    lblGrade.setText("Grade: B");
                else
                    lblGrade.setText("Grade: C");
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Main Method
    public static void main(String[] args) {
        new ResultForm();
    }
}