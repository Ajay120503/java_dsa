#include <stdio.h>
#define MAX 5

struct Order
{
    int orderNo;
    char name[20];
};

struct Order queue[MAX];
int front = -1, rear = -1;

void placeOrder()
{
    if (rear == MAX - 1)
    {
        printf("Order Queue Full!\n");
        return;
    }

    if (front == -1)
        front = 0;

    printf("Enter Order Number: ");
    scanf("%d", &queue[++rear].orderNo);
    printf("Enter Customer Name: ");
    scanf("%s", queue[rear].name);

    printf("Order placed successfully.\n");
}

void deliverOrder()
{
    if (front == -1 || front > rear)
    {
        printf("No orders to deliver.\n");
        return;
    }

    printf("Delivering Order %d for %s\n",
           queue[front].orderNo, queue[front].name);
    front++;
}

void displayOrders()
{
    if (front == -1 || front > rear)
    {
        printf("No pending orders.\n");
        return;
    }

    printf("Pending Orders:\n");
    for (int i = front; i <= rear; i++)
    {
        printf("Order No: %d, Customer: %s\n",
               queue[i].orderNo, queue[i].name);
    }
}

int main()
{
    int choice;
    do
    {
        printf("\n1.Place Order\n2.Deliver Order\n3.Display Orders\n4.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            placeOrder();
            break;
        case 2:
            deliverOrder();
            break;
        case 3:
            displayOrders();
            break;
        case 4:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}
