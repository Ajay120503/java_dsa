#include <stdio.h>
#define MAX 5

struct Job
{
    int jobId;
    int pages;
};

struct Job queue[MAX];
int front = -1, rear = -1;

void addJob()
{
    if (rear == MAX - 1)
    {
        printf("Printer Queue Full!\n");
        return;
    }

    if (front == -1)
        front = 0;

    printf("Enter Job ID: ");
    scanf("%d", &queue[++rear].jobId);
    printf("Enter Number of Pages: ");
    scanf("%d", &queue[rear].pages);

    printf("Print job added.\n");
}

void processJob()
{
    if (front == -1 || front > rear)
    {
        printf("No print jobs to process.\n");
        return;
    }

    printf("Processing Job ID %d (%d pages)\n",
           queue[front].jobId, queue[front].pages);
    front++;
}

void displayJobs()
{
    if (front == -1 || front > rear)
    {
        printf("No pending print jobs.\n");
        return;
    }

    printf("Pending Jobs:\n");
    for (int i = front; i <= rear; i++)
    {
        printf("Job ID: %d, Pages: %d\n",
               queue[i].jobId, queue[i].pages);
    }
}

int main()
{
    int choice;
    do
    {
        printf("\n1.Add Print Job\n2.Process Print Job\n3.Display Jobs\n4.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            addJob();
            break;
        case 2:
            processJob();
            break;
        case 3:
            displayJobs();
            break;
        case 4:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}
