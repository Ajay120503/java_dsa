#include <stdio.h>
#define MAX 5

int queue[MAX];
int front = -1, rear = -1;

void addToken()
{
    int token;
    if (rear == MAX - 1)
    {
        printf("Queue Overflow! No more customers.\n");
        return;
    }
    printf("Enter Token Number: ");
    scanf("%d", &token);

    if (front == -1)
        front = 0;

    queue[++rear] = token;
    printf("Customer added with Token %d\n", token);
}

void serveCustomer()
{
    if (front == -1 || front > rear)
    {
        printf("Queue Underflow! No customers to serve.\n");
        return;
    }
    printf("Serving customer with Token %d\n", queue[front++]);
}

void displayQueue()
{
    if (front == -1 || front > rear)
    {
        printf("No customers waiting.\n");
        return;
    }
    printf("Waiting Queue: ");
    for (int i = front; i <= rear; i++)
        printf("%d ", queue[i]);
    printf("\n");
}

int main()
{
    int choice;
    do
    {
        printf("\n1.Add Customer\n2.Serve Customer\n3.Display Queue\n4.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            addToken();
            break;
        case 2:
            serveCustomer();
            break;
        case 3:
            displayQueue();
            break;
        case 4:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}
