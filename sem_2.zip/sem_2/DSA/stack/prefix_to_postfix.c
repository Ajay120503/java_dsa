#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define MAX 50

char stack[MAX][MAX];
int top = -1;

void push(char str[])
{
    strcpy(stack[++top], str);
}

char *pop()
{
    return stack[top--];
}

int isOperator(char ch)
{
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/');
}

int main()
{
    char prefix[MAX];
    int i, length;

    printf("Enter the Prefix Expression : ");
    scanf("%s", prefix);

    length = strlen(prefix);

    for (i = length - 1; i >= 0; i--)
    {
        char ch = prefix[i];

        if (isalnum(ch))
        {
            char temp[2];
            temp[0] = ch;
            temp[1] = '\0';
            push(temp);
        }
        else if (isOperator(ch))
        {
            char op1[MAX], op2[MAX], result[MAX];

            strcpy(op1, pop());
            strcpy(op2, pop());

            sprintf(result, "%s%s%c", op1, op2, ch);
            push(result);
        }
    }
    printf("Postfix Expression : %s\n", stack[top]);
    return 0;
}