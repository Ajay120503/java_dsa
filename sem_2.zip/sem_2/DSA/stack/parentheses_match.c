#include <stdio.h>
#include <string.h>

char stack[50];
int top = -1;

void push(char ch)
{
    stack[++top] = ch;
}

char pop()
{
    return stack[top--];
}

int isMatchingPair(char open, char close)
{
    if (open == '(' && close == ')')
        return 1;
    if (open == '{' && close == '}')
        return 1;
    if (open == '[' && close == ']')
        return 1;
    return 0;
}

int main()
{
    char expr[50];
    int balanced = 1;

    printf("Enter expression: ");
    scanf("%s", expr);

    for (int i = 0; i < strlen(expr); i++)
    {
        char ch = expr[i];

        if (ch == '(' || ch == '{' || ch == '[')
        {
            push(ch);
        }
        else if (ch == ')' || ch == '}' || ch == ']')
        {
            if (top == -1 || !isMatchingPair(pop(), ch))
            {
                balanced = 0;
                break;
            }
        }
    }

    if (top != -1)
        balanced = 0;

    if (balanced)
        printf("Expression is Balanced.\n");
    else
        printf("Expression is Unbalanced.\n");

    return 0;
}
