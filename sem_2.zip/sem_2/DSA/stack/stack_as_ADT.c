#include <stdio.h>
#define MAX 10
struct Stack
{
    int arr[MAX];
    int top;
};

void push(struct Stack *s);
void pop(struct Stack *s);
void peek(struct Stack *s);
void display(struct Stack *s);

void push(struct Stack *s)
{
    int value;

    if (s->top == MAX - 1)
    {
        printf("\nStack is Overflow...\n");
        return;
    }

    printf("Enter the Value : ");
    scanf("%d", &value);

    s->arr[++s->top] = value;
    printf("\nValue pushed successfully...\n");
}

void pop(struct Stack *s)
{
    if (s->top == -1)
    {
        printf("Stack is Underflow...\n");
        return;
    }

    printf("\npop values is %d\n", s->arr[s->top--]);
}

void peek(struct Stack *s)
{
    if (s->top == -1)
    {
        printf("\nStack is Empty...\n");
        return;
    }

    printf("\nTop element is %d\n", s->arr[s->top]);
}

void display(struct Stack *s)
{
    if (s->top == -1)
    {
        printf("\nStack is Empty...\n");
        return;
    }
    printf("\nStack is :\n");
    for (int i = s->top; i >= 0; i--)
    {
        printf("%d\n", s->arr[i]);
    }
}

int main()
{

    struct Stack s;
    s.top = -1;

    push(&s);
    push(&s);
    push(&s);
    push(&s);
    push(&s);
    display(&s);

    pop(&s);
    display(&s);

    peek(&s);
    return 0;
}