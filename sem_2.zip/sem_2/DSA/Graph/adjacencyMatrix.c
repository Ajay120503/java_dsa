#include<stdio.h>
#include<stdlib.h>
#define MAX 10

int graph[MAX][MAX];
int visitedp[MAX];
int n;

void createGraph(){

}

void displayGraph(){

}

void BFS(){

}

void DFS(){

}

int main(){



    return 0;
}