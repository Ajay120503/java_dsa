#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node *next;
} Node;

Node *head = NULL;

void create()
{
    int n, value;
    Node *temp, *newNode;

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        newNode = (Node *)malloc(sizeof(Node));
        printf("Enter value: ");
        scanf("%d", &value);

        newNode->data = value;

        if (head == NULL)
        {
            head = newNode;
            newNode->next = head;
            temp = head;
        }
        else
        {
            temp->next = newNode;
            newNode->next = head;
            temp = newNode;
        }
    }
}

void display()
{
    if (head == NULL)
    {
        printf("List is empty.\n");
        return;
    }

    Node *temp = head;

    printf("Circular List: ");
    do
    {
        printf("%d -> ", temp->data);
        temp = temp->next;
    } while (temp != head);

    printf("(HEAD)\n");
}

void insertBeginning(int value)
{
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = value;

    if (head == NULL)
    {
        head = newNode;
        newNode->next = head;
        return;
    }

    Node *temp = head;

    while (temp->next != head)
        temp = temp->next;

    newNode->next = head;
    temp->next = newNode;
    head = newNode;
}

void insertEnd(int value)
{
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = value;

    if (head == NULL)
    {
        head = newNode;
        newNode->next = head;
        return;
    }

    Node *temp = head;

    while (temp->next != head)
        temp = temp->next;

    temp->next = newNode;
    newNode->next = head;
}

void deleteBeginning()
{
    if (head == NULL)
    {
        printf("List is empty.\n");
        return;
    }

    Node *temp = head;
    Node *last = head;

    while (last->next != head)
        last = last->next;

    if (head == head->next)
    {
        free(head);
        head = NULL;
        return;
    }

    head = head->next;
    last->next = head;
    free(temp);
}

void deleteEnd()
{
    if (head == NULL)
    {
        printf("List is empty.\n");
        return;
    }

    Node *temp = head;
    Node *prev = NULL;

    while (temp->next != head)
    {
        prev = temp;
        temp = temp->next;
    }

    if (temp == head)
    {
        free(head);
        head = NULL;
        return;
    }

    prev->next = head;
    free(temp);
}

void search(int key)
{
    if (head == NULL)
    {
        printf("List empty.\n");
        return;
    }

    Node *temp = head;
    int pos = 1;

    do
    {
        if (temp->data == key)
        {
            printf("Element found at position %d\n", pos);
            return;
        }
        temp = temp->next;
        pos++;
    } while (temp != head);

    printf("Element not found.\n");
}

void countNodes()
{
    if (head == NULL)
    {
        printf("Total nodes: 0\n");
        return;
    }

    Node *temp = head;
    int count = 0;

    do
    {
        count++;
        temp = temp->next;
    } while (temp != head);

    printf("Total nodes: %d\n", count);
}

int main()
{
    int choice, value;

    while (1)
    {
        printf("\n===== CIRCULAR LINKED LIST MENU =====\n");
        printf("1. Create\n");
        printf("2. Display\n");
        printf("3. Insert at Beginning\n");
        printf("4. Insert at End\n");
        printf("5. Delete from Beginning\n");
        printf("6. Delete from End\n");
        printf("7. Search Element\n");
        printf("8. Count Nodes\n");
        printf("9. Exit\n");

        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            create();
            break;
        case 2:
            display();
            break;

        case 3:
            printf("Enter value: ");
            scanf("%d", &value);
            insertBeginning(value);
            break;

        case 4:
            printf("Enter value: ");
            scanf("%d", &value);
            insertEnd(value);
            break;

        case 5:
            deleteBeginning();
            break;
        case 6:
            deleteEnd();
            break;

        case 7:
            printf("Enter value to search: ");
            scanf("%d", &value);
            search(value);
            break;

        case 8:
            countNodes();
            break;

        case 9:
            printf("Exiting...\n");
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }
}