#include <stdio.h>
#include <stdlib.h>

typedef struct ListNode
{
    int data;
    struct ListNode *next;
} ListNode;

typedef struct TreeNode
{
    int data;
    struct TreeNode *left;
    struct TreeNode *right;
} TreeNode;

ListNode *head = NULL;

void insert(int value)
{
    ListNode *newNode = (ListNode *)malloc(sizeof(ListNode));
    newNode->data = value;
    newNode->next = NULL;

    if (!head)
    {
        head = newNode;
        return;
    }

    ListNode *temp = head;
    while (temp->next)
        temp = temp->next;

    temp->next = newNode;
}

void displayList()
{
    ListNode *temp = head;
    while (temp)
    {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

ListNode *findMiddle(ListNode *start)
{
    ListNode *slow = start;
    ListNode *fast = start;
    ListNode *prev = NULL;

    while (fast && fast->next)
    {
        prev = slow;
        slow = slow->next;
        fast = fast->next->next;
    }

    if (prev)
        prev->next = NULL;

    return slow;
}

TreeNode *createTreeNode(int value)
{
    TreeNode *node = (TreeNode *)malloc(sizeof(TreeNode));
    node->data = value;
    node->left = node->right = NULL;
    return node;
}

TreeNode *sortedListToBST(ListNode *start)
{
    if (start == NULL)
        return NULL;

    if (start->next == NULL)
        return createTreeNode(start->data);

    ListNode *mid = findMiddle(start);

    TreeNode *root = createTreeNode(mid->data);

    root->left = sortedListToBST(start);
    root->right = sortedListToBST(mid->next);

    return root;
}

void inorder(TreeNode *root)
{
    if (root)
    {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

int main()
{
    int n, value;

    printf("Enter number of elements (sorted): ");
    scanf("%d", &n);

    printf("Enter sorted elements:\n");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &value);
        insert(value);
    }

    printf("Linked List:\n");
    displayList();

    TreeNode *bstRoot = sortedListToBST(head);

    printf("Inorder Traversal of BST:\n");
    inorder(bstRoot);

    printf("\n");

    return 0;
}