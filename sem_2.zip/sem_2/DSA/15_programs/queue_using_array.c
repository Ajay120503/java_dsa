#include <stdio.h>
#include <stdlib.h>

#define MAX 5

struct Queue
{
    int arr[MAX];
    int front;
    int rear;
};

void initQueue(struct Queue *q)
{
    q->front = -1;
    q->rear = -1;
}

int isEmpty(struct Queue *q)
{
    return (q->front == -1);
}

int isFull(struct Queue *q)
{
    return (q->rear == MAX - 1);
}

void enqueue(struct Queue *q, int value)
{
    if (isFull(q))
    {
        printf("Queue Overflow!\n");
        return;
    }

    if (q->front == -1)
    {
        q->front = 0;
    }

    q->arr[++q->rear] = value;

    printf("%d inserted into queue\n", value);
}

void dequeue(struct Queue *q)
{
    if (isEmpty(q))
    {
        printf("Queue Underflow!\n");
        return;
    }

    printf("%d removed from queue\n", q->arr[q->front]);
    q->front++;

    if (q->front > q->rear)
    {
        q->front = q->rear = -1;
    }
}

void peek(struct Queue *q)
{
    if (isEmpty(q))
    {
        printf("Queue is empty\n");
        return;
    }

    printf("Front element = %d\n", q->arr[q->front]);
}

void display(struct Queue *q)
{
    if (isEmpty(q))
    {
        printf("Queue is empty\n");
        return;
    }

    printf("Queue elements:\n");

    for (int i = q->front; i <= q->rear; i++)
        printf("%d ", q->arr[i]);

    printf("\n");
}

int main()
{
    struct Queue q;
    int choice, value;

    initQueue(&q);

    while (1)
    {
        printf("\n--- QUEUE MENU ---\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Peek\n");
        printf("4. Display\n");
        printf("5. Exit\n");

        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter value: ");
            scanf("%d", &value);
            enqueue(&q, value);
            break;

        case 2:
            dequeue(&q);
            break;

        case 3:
            peek(&q);
            break;

        case 4:
            display(&q);
            break;

        case 5:
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }
}