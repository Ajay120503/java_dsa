#include <stdio.h>
#include <stdlib.h>

#define MAX 5

typedef struct
{
    int arr[MAX];
    int front;
    int rear;
} CircularQueue;

void initialize(CircularQueue *q)
{
    q->front = -1;
    q->rear = -1;
}

int isEmpty(CircularQueue *q)
{
    return (q->front == -1);
}

int isFull(CircularQueue *q)
{
    return ((q->rear + 1) % MAX == q->front);
}

void enqueue(CircularQueue *q, int value)
{
    if (isFull(q))
    {
        printf("Queue Overflow!\n");
        return;
    }

    if (isEmpty(q))
        q->front = 0;

    q->rear = (q->rear + 1) % MAX;
    q->arr[q->rear] = value;

    printf("Inserted: %d\n", value);
}

void dequeue(CircularQueue *q)
{
    if (isEmpty(q))
    {
        printf("Queue Underflow!\n");
        return;
    }

    printf("Deleted: %d\n", q->arr[q->front]);

    if (q->front == q->rear)
    {
        q->front = q->rear = -1;
    }
    else
    {
        q->front = (q->front + 1) % MAX;
    }
}

void display(CircularQueue *q)
{
    if (isEmpty(q))
    {
        printf("Queue is empty.\n");
        return;
    }

    printf("Queue Elements:\n");

    int i = q->front;

    while (1)
    {
        printf("%d ", q->arr[i]);

        if (i == q->rear)
            break;

        i = (i + 1) % MAX;
    }

    printf("\n");
}

int main()
{
    CircularQueue q;
    initialize(&q);

    int choice, value;

    while (1)
    {
        printf("\n===== CIRCULAR QUEUE MENU =====\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter value: ");
            scanf("%d", &value);
            enqueue(&q, value);
            break;

        case 2:
            dequeue(&q);
            break;

        case 3:
            display(&q);
            break;

        case 4:
            printf("Exiting program...\n");
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }
}