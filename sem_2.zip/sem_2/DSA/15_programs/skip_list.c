#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_LEVEL 4
#define P 0.5

typedef struct Node
{
    int value;
    struct Node *forward[MAX_LEVEL];
} Node;

Node *header;
int level = 0;

Node *createNode(int lvl, int value)
{
    Node *n = (Node *)malloc(sizeof(Node));
    n->value = value;

    for (int i = 0; i < MAX_LEVEL; i++)
        n->forward[i] = NULL;

    return n;
}

int randomLevel()
{
    int lvl = 0;
    while (((float)rand() / RAND_MAX) < P && lvl < MAX_LEVEL - 1)
        lvl++;
    return lvl;
}

void insert(int value)
{
    Node *update[MAX_LEVEL];
    Node *current = header;

    for (int i = level; i >= 0; i--)
    {
        while (current->forward[i] &&
               current->forward[i]->value < value)
            current = current->forward[i];

        update[i] = current;
    }

    current = current->forward[0];

    if (!current || current->value != value)
    {
        int newLevel = randomLevel();

        if (newLevel > level)
        {
            for (int i = level + 1; i <= newLevel; i++)
                update[i] = header;

            level = newLevel;
        }

        Node *newNode = createNode(newLevel, value);

        for (int i = 0; i <= newLevel; i++)
        {
            newNode->forward[i] = update[i]->forward[i];
            update[i]->forward[i] = newNode;
        }

        printf("Inserted %d\n", value);
    }
}

void search(int value)
{
    Node *current = header;

    for (int i = level; i >= 0; i--)
    {
        while (current->forward[i] &&
               current->forward[i]->value < value)
            current = current->forward[i];
    }

    current = current->forward[0];

    if (current && current->value == value)
        printf("Element found!\n");
    else
        printf("Element not found.\n");
}

void deleteNode(int value)
{
    Node *update[MAX_LEVEL];
    Node *current = header;

    for (int i = level; i >= 0; i--)
    {
        while (current->forward[i] &&
               current->forward[i]->value < value)
            current = current->forward[i];

        update[i] = current;
    }

    current = current->forward[0];

    if (current && current->value == value)
    {
        for (int i = 0; i <= level; i++)
        {
            if (update[i]->forward[i] != current)
                break;

            update[i]->forward[i] = current->forward[i];
        }

        free(current);

        while (level > 0 && header->forward[level] == NULL)
            level--;

        printf("Deleted %d\n", value);
    }
    else
        printf("Element not found.\n");
}

void display()
{
    printf("\nSkip List Levels:\n");

    for (int i = level; i >= 0; i--)
    {
        Node *node = header->forward[i];
        printf("Level %d: ", i);

        while (node)
        {
            printf("%d ", node->value);
            node = node->forward[i];
        }
        printf("\n");
    }
}

int main()
{
    srand(time(NULL));

    header = createNode(MAX_LEVEL, -1);

    int choice, value;

    while (1)
    {
        printf("\n===== SKIP LIST MENU =====\n");
        printf("1. Insert\n");
        printf("2. Search\n");
        printf("3. Delete\n");
        printf("4. Display\n");
        printf("5. Exit\n");

        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter value: ");
            scanf("%d", &value);
            insert(value);
            break;

        case 2:
            printf("Enter value: ");
            scanf("%d", &value);
            search(value);
            break;

        case 3:
            printf("Enter value: ");
            scanf("%d", &value);
            deleteNode(value);
            break;

        case 4:
            display();
            break;

        case 5:
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }
}