#include <stdio.h>
#include <string.h>

#define MAX 100

typedef struct
{
    char arr[MAX];
    int top;
} Stack;

void initialize(Stack *s)
{
    s->top = -1;
}

int isEmpty(Stack *s)
{
    return (s->top == -1);
}

void push(Stack *s, char ch)
{
    s->arr[++(s->top)] = ch;
}

char pop(Stack *s)
{
    if (isEmpty(s))
        return '\0';

    return s->arr[(s->top)--];
}

int isMatchingPair(char open, char close)
{
    if (open == '(' && close == ')')
        return 1;
    if (open == '{' && close == '}')
        return 1;
    if (open == '[' && close == ']')
        return 1;
    return 0;
}

int checkBalanced(char expr[])
{
    Stack s;
    initialize(&s);

    for (int i = 0; expr[i] != '\0'; i++)
    {
        char ch = expr[i];

        if (ch == '(' || ch == '{' || ch == '[')
        {
            push(&s, ch);
        }

        else if (ch == ')' || ch == '}' || ch == ']')
        {
            if (isEmpty(&s))
                return 0;

            char open = pop(&s);

            if (!isMatchingPair(open, ch))
                return 0;
        }
    }

    return isEmpty(&s);
}

int main()
{
    char expr[MAX];

    printf("Enter Expression: ");
    scanf("%s", expr);

    if (checkBalanced(expr))
        printf("Expression is BALANCED.\n");
    else
        printf("Expression is UNBALANCED.\n");

    return 0;
}