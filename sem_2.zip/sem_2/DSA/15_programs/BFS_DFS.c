#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int graph[MAX][MAX];
int visited[MAX];
int n;

void createGraph()
{
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &graph[i][j]);
        }
    }
}

void displayGraph()
{
    printf("\nAdjacency Matrix:\n");

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            printf("%d ", graph[i][j]);

        printf("\n");
    }
}

void BFS(int start)
{
    int queue[MAX];
    int front = 0, rear = 0;

    for (int i = 0; i < n; i++)
        visited[i] = 0;

    queue[rear++] = start;
    visited[start] = 1;

    printf("BFS Traversal: ");

    while (front < rear)
    {
        int node = queue[front++];
        printf("%d ", node);

        for (int i = 0; i < n; i++)
        {
            if (graph[node][i] == 1 && !visited[i])
            {
                queue[rear++] = i;
                visited[i] = 1;
            }
        }
    }

    printf("\n");
}

void DFS(int node)
{
    visited[node] = 1;
    printf("%d ", node);

    for (int i = 0; i < n; i++)
    {
        if (graph[node][i] == 1 && !visited[i])
            DFS(i);
    }
}

int main()
{
    int choice, start;

    while (1)
    {
        printf("\n===== GRAPH MENU =====\n");
        printf("1. Create Graph\n");
        printf("2. Display Graph\n");
        printf("3. BFS Traversal\n");
        printf("4. DFS Traversal\n");
        printf("5. Exit\n");

        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            createGraph();
            break;

        case 2:
            displayGraph();
            break;

        case 3:
            printf("Enter starting vertex: ");
            scanf("%d", &start);
            BFS(start);
            break;

        case 4:
            for (int i = 0; i < n; i++)
                visited[i] = 0;

            printf("Enter starting vertex: ");
            scanf("%d", &start);

            printf("DFS Traversal: ");
            DFS(start);
            printf("\n");
            break;

        case 5:
            printf("Exiting...\n");
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }
}