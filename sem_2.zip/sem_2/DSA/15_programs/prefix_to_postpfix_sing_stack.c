#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX 100

typedef struct
{
    char items[MAX][MAX];
    int top;
} Stack;

void initialize(Stack *s)
{
    s->top = -1;
}

int isEmpty(Stack *s)
{
    return (s->top == -1);
}

void push(Stack *s, char str[])
{
    strcpy(s->items[++(s->top)], str);
}

char *pop(Stack *s)
{
    return s->items[(s->top)--];
}

int isOperator(char ch)
{
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/');
}

void prefixToPostfix(char prefix[])
{
    Stack s;
    initialize(&s);

    int len = strlen(prefix);

    for (int i = len - 1; i >= 0; i--)
    {
        char symbol = prefix[i];

        if (symbol == ' ')
            continue;

        if (isalnum(symbol))
        {
            char operand[2];
            operand[0] = symbol;
            operand[1] = '\0';

            push(&s, operand);
        }
        else if (isOperator(symbol))
        {
            char op1[MAX], op2[MAX], temp[MAX];

            strcpy(op1, pop(&s));
            strcpy(op2, pop(&s));

            strcpy(temp, op1);
            strcat(temp, op2);

            int l = strlen(temp);
            temp[l] = symbol;
            temp[l + 1] = '\0';

            push(&s, temp);
        }
    }

    printf("Postfix Expression: %s\n", pop(&s));
}

int main()
{
    char prefix[MAX];

    printf("Enter Prefix Expression: ");
    scanf("%s", prefix);

    prefixToPostfix(prefix);

    return 0;
}