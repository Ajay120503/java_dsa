#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node *next;
};

struct Node *newNode(int data)
{
    struct Node *temp = (struct Node *)malloc(sizeof(struct Node));
    temp->data = data;
    temp->next = NULL;
    return temp;
}

struct Node *insert(struct Node *head, int data)
{
    struct Node *temp = newNode(data);

    if (head == NULL)
        return temp;

    struct Node *p = head;
    while (p->next != NULL)
        p = p->next;

    p->next = temp;
    return head;
}

struct Node *removeDuplicates(struct Node *head)
{
    struct Node *dummy = newNode(0);
    dummy->next = head;

    struct Node *prev = dummy;
    struct Node *curr = head;

    while (curr != NULL)
    {

        if (curr->next != NULL && curr->data == curr->next->data)
        {
            int val = curr->data;

            // Skip all nodes with same value
            while (curr != NULL && curr->data == val)
                curr = curr->next;

            prev->next = curr;
        }
        else
        {
            prev = curr;
            curr = curr->next;
        }
    }

    return dummy->next;
}

void printList(struct Node *head)
{
    while (head != NULL)
    {
        printf("%d -> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}

int main()
{
    int n, x;
    struct Node *head = NULL;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter sorted elements:\n");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &x);
        head = insert(head, x);
    }

    printf("Original List:\n");
    printList(head);

    head = removeDuplicates(head);

    printf("List after removing duplicates:\n");
    printList(head);

    return 0;
}
