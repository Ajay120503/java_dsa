#include <stdio.h>
#include <stdlib.h>
#define MAX 10

struct Stack
{
    int arr[MAX];
    int top;
};

void init(struct Stack *s);
int isFull(struct Stack *s);
int isEmpty(struct Stack *s);
void push(struct Stack *s, int value);
void pop(struct Stack *s);
void peek(struct Stack *s);
void display(struct Stack *s);

void init(struct Stack *s)
{
    s->top = -1;
}

int isFull(struct Stack *s)
{
    return (s->top == MAX - 1);
}

int isEmpty(struct Stack *s)
{
    return (s->top == -1);
}

void push(struct Stack *s, int value)
{
    if (isFull(s))
    {
        printf("Stack is Overflow\n");
        return;
    }

    s->arr[++(s->top)] = value;
    printf("value pushed\n");
}

void pop(struct Stack *s)
{
    if (isEmpty(s))
    {
        printf("Stack is Underflow\n");
        return;
    }

    printf("Poped value is %d\n", s->arr[(s->top)--]);
    printf("value poped");
}

void peek(struct Stack *s)
{
    if (isEmpty(s))
    {
        printf("Stack is Underflow\n");
        return;
    }

    printf("Top value is %d\n", s->arr[s->top]);
}

void display(struct Stack *s)
{
    if (isEmpty(s))
    {
        printf("Stack is Underflow\n");
        return;
    }
    printf("Stack is :\n");
    for (int i = s->top; i >= 0; i--)
    {
        printf("%d\n", s->arr[i]);
    }
}

int main()
{
    struct Stack s;

    init(&s);

    int choice, value;

    while (1)
    {
        printf("\n===== STACK MENU =====\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Peek\n");
        printf("4. Display\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter value: ");
            scanf("%d", &value);
            push(&s, value);
            break;

        case 2:
            pop(&s);
            break;

        case 3:
            peek(&s);
            break;

        case 4:
            display(&s);
            break;

        case 5:
            printf("Exiting program...\n");
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }

    return 0;
}