#include<stdio.h>
#include<stdlib.h>
#include "arrayadt.h"

// --------------------------------------

void display(struct Array arr){
    if(arr.length == 0){
        printf("array is empty");
    }else{
        for(int i=0;i<arr.length;i++){
            printf("%d ",arr.data[i]);
        }
    }    
}
int append(struct Array *arr, int value){

    if(arr->length >= arr->size){
        return 0;
    }else{
        arr->data[arr->length]=value;
        arr->length++;
        return 1;
    }
}

int insertAt(struct Array *arr, int index, int value){
    
    if(index < 0 || index >= arr->length){
        return 0;
    }

    if(arr->length >= arr->size){
        return 0;
    }

    for(int i=arr->length; i > index; i--){
        arr->data[i] = arr->data[i-1];
    }

    arr->data[index] = value;
    arr->length++;
    return 1;
}

int deleteAt(struct Array *arr, int index, int *deletedValue){

    if(index < 0 || index >= arr->length){
        return 0;
    }

    *deletedValue = arr->data[index];

    for(int i=index; i<arr->length-1;i++){
        arr->data[i] = arr->data[i+1];
    }

    arr->length--;
    return 1;
    
}

int linearSearch(struct Array *arr, int key){

    for(int i=0; i<arr->length; i++){
        if(arr->data[i] == key){
            return 1;
        }
    }
    return -1;
}

// --------------------------------------- 

void displayMarks(struct Student *s)
{
    if (s->subjects == 0)
    {
        printf("Marks set is Empty!");
        return;
    }

    else
    {
        printf("\nMarks of subject is : ");
        for (int i = 0; i < s->subjects; i++)
        {
            printf("%d ", s->marks[i]);
        }
    }
}

void acceptMarks(struct Student *s)
{

    printf("\nEnter the Subject Marks : ");
    for (int i = 0; i < s->subjects; i++)
    {
        scanf("%d", &s->marks[i]);
    }
}

int appendMarks(struct Student *s, int marks)
{
    if (s->subjects == 0)
    {
        return 0;
    }

    s->marks[s->subjects++] = marks;
    return 1;
}

int insertMarksAt(struct Student *s, int index, int marks)
{

    for (int i = s->subjects; i > index; i--)
    {
        s->marks[i] = s->marks[i - 1];
    }

    s->marks[index] = marks;
    s->subjects++;
    return 1;
}

int deletedMarksAt(struct Student *s, int index)
{
    for (int i = index; i < s->subjects - 1; i++)
    {
        s->marks[i] = s->marks[i + 1];
    }

    s->subjects--;
    return 1;
}

void findMinMaxMarks(struct Student *s)
{
    int min = s->marks[0], max = s->marks[0];

    for (int i = 0; i < s->subjects; i++)
    {
        if (s->marks[i] < min)
        {
            min = s->marks[i];
        }
        if (s->marks[i] > max)
        {
            max = s->marks[i];
        }
    }

    printf("\nmin marks is %d\nmax marks is %d\n", min, max);
}

int searchMarks(struct Student *s, int marks)
{
    for (int i = 0; i < s->subjects; i++)
    {
        if (s->marks[i] == marks)
        {
            return i;
        }
    }
    return -1;
}

// ---------------------------------------------------

void displayMusicPlayList(struct Music *m)
{
    for (int i = 0; i < m->size; i++)
    {
        printf("%d ", m->musicList[i]);
    }
    printf("\n");
}

void acceptMusicPlayList(struct Music *m)
{
    printf("Enter the music playlist : ");
    for (int i = 0; i < m->size; i++)
    {
        scanf("%d", &m->musicList[i]);
    }
}

int insertSongAt(struct Music *m, int index, int song)
{

    for (int i = m->size; i > index; i--)
    {
        m->musicList[i] = m->musicList[i - 1];
    }

    m->musicList[index] = song;
    m->size++;
    return 1;
}

int appendSong(struct Music *m, int song)
{
    m->musicList[m->size++] = song;
    return 1;
}

int deleteSongAt(struct Music *m, int index)
{

    for (int i = index; i < m->size - 1; i++)
    {
        m->musicList[i] = m->musicList[i + 1];
    }

    m->size--;
    return 1;
}

void reversePlayList(struct Music *m)
{
    int reversePlayList[m->size];

    for (int i = 0; i < m->size; i++)
    {
        reversePlayList[i] = m->musicList[m->size - i - 1];
    }

    for (int i = 0; i < m->size; i++)
    {
        m->musicList[i] = reversePlayList[i];
    }
}

// ----------------------------------------------------

void initQueue(struct Queue *q)
{
    q->front = -1;
    q->rear = -1;
}

int enqueue(struct Queue *q, int patientId)
{
    if (q->rear == MAX - 1)
    {
        printf("Queue is overflow...\n");
    }

    if (q->front == -1)
    {
        q->front = 0;
    }

    q->rear++;
    q->data[q->rear] = patientId;
    return 1;
}

int dequeue(struct Queue *q)
{

    if (q->front == -1 || q->front > q->rear)
    {
        printf("Queue is Underflow...\n");
        return -1;
    }

    int removed = q->data[q->front];
    q->front++;
    return removed;
}

void peek(struct Queue *q)
{
    if (q->front == -1 || q->front > q->rear)
    {
        printf("Queue is Underflow...\n");
    }

    printf("Next Patient : %d\n", q->data[q->front]);
}

int search(struct Queue *q, int patientId)
{
    for (int i = q->front; i <= q->rear; i++)
    {
        if (q->data[i] == patientId)
        {
            return i - q->front;
        }
    }

    return -1;
}

void displayQueue(struct Queue *q)
{
    if (q->front == -1 || q->front > q->rear)
    {
        printf("Queue is Empty...\n");
    }

    printf("Queue : ");
    for (int i = q->front; i <= q->rear; i++)
    {
        printf("%d ", q->data[i]);
    }
    printf("\n");
}