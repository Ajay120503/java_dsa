#include <stdio.h>
#include "arrayadt.h"
// #define MAX 100

// struct Queue
// {
//     int data[MAX];
//     int front;
//     int rear;
// };

// void initQueue(struct Queue *q);
// int enqueue(struct Queue *q, int patientId);
// int dequeue(struct Queue *q);
// void peek(struct Queue *q);
// int search(struct Queue *q, int patientId);
// void display(struct Queue *q);

// void initQueue(struct Queue *q)
// {
//     q->front = -1;
//     q->rear = -1;
// }

// int enqueue(struct Queue *q, int patientId)
// {
//     if (q->rear == MAX - 1)
//     {
//         printf("Queue is overflow...\n");
//     }

//     if (q->front == -1)
//     {
//         q->front = 0;
//     }

//     q->rear++;
//     q->data[q->rear] = patientId;
//     return 1;
// }

// int dequeue(struct Queue *q)
// {

//     if (q->front == -1 || q->front > q->rear)
//     {
//         printf("Queue is Underflow...\n");
//         return -1;
//     }

//     int removed = q->data[q->front];
//     q->front++;
//     return removed;
// }

// void peek(struct Queue *q)
// {
//     if (q->front == -1 || q->front > q->rear)
//     {
//         printf("Queue is Underflow...\n");
//     }

//     printf("Next Patient : %d\n", q->data[q->front]);
// }

// int search(struct Queue *q, int patientId)
// {
//     for (int i = q->front; i <= q->rear; i++)
//     {
//         if (q->data[i] == patientId)
//         {
//             return i - q->front;
//         }
//     }

//     return -1;
// }

// void display(struct Queue *q)
// {
//     if (q->front == -1 || q->front > q->rear)
//     {
//         printf("Queue is Empty...\n");
//     }

//     printf("Queue : ");
//     for (int i = q->front; i <= q->rear; i++)
//     {
//         printf("%d ", q->data[i]);
//     }
//     printf("\n");
// }

int main()
{

    struct Queue q;
    initQueue(&q);

    enqueue(&q, 11);
    enqueue(&q, 12);
    enqueue(&q, 14);
    enqueue(&q, 15);
    displayQueue(&q);

    enqueue(&q, 105);
    displayQueue(&q);

    int removed = dequeue(&q);
    if (removed != -1)
    {
        printf("Removed: %d\n", removed);
    }
    displayQueue(&q);

    int index = search(&q, 14);
    if (index != -1)
    {
        printf("Found at index %d\n", index);
    }
    else
    {
        printf("Patient not found\n");
    }

    return 0;
}