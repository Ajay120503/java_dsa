#include<stdio.h>
#include<stdlib.h>
#define MAX 5

int queue[MAX];
int front = -1;
int rear = -1;

void enqueue();
void dequeue();
void peek();
void display();

int main(){

    int option;

    do{
        printf("\n------------ menu ---------------\n");
        printf("1. enqueue\n2. dequeue\n3. peek\n4. display\n5. exit\n");
        printf("Enter the option : ");
        scanf("%d",&option);

        switch(option){
            case 1:
                enqueue();
                break;
            case 2:
                dequeue();
                break;
            case 3:
                peek();
                break;
            case 4:
                display();
                break;
            case 5:
                exit(0);
            default :
                printf("\n.........invalid option");
            
        }

    }while(option!=5);

    return 0;
}

void enqueue(){

    int value;

    if((front == 0 && rear == MAX - 1)||(rear + 1 == front)){
        printf("Queue is overflow\n");
    }else{
        printf("Enter the value : ");
        scanf("%d",&value);

        if(front == -1){
            front = rear = 0;
        }else if(rear == MAX - 1){
            rear = 0;
        }
        else{
            rear++;
        }

    }
        queue[rear] = value;
        printf("enqueue sucessfully\n");
}

void dequeue(){
    
    if((front == rear) || (front == -1)){
        printf("queue is underflow\n");
    }else{

        printf("deleted element %d",queue[front]);
        
        if(front == rear){
            front = rear = -1;
        }else if(front == MAX - 1){
            front = 0;
        }else{
            front++;
        }
    }
    
}

void peek(){
    
    if(front == -1){
        printf("queue is empty\n");
    }else{
        printf("peek element %d ",queue[front]);
    }
}

void display(){
    printf("queue is : ");
    
    if(front == -1){
        printf("queue is empty\n");
    }else{
        if(front <= rear){
            for(int i = front; i <= rear; i++){
                printf("%d ",queue[i]);
            }
        }else{
            for(int i = front; i < MAX; i++){
                printf("%d ",queue[i]);
            }

            for(int i = 0; i <= rear; i++){
                printf("%d ",queue[i]);
            }
        }
    }
}