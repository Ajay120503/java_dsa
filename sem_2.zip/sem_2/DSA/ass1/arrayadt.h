#include<stdio.h>
#include<stdlib.h>
#define MAX 100

struct Array{
    int data[10];
    int size;
    int length;
};

void display(struct Array arr);
int append(struct Array *arr, int value);
int insertAt(struct Array *arr, int index, int value);
int deleteAt(struct Array *arr, int index, int *deleteValue);
int linearSearch(struct Array *arr, int key);

// -----------------------------------------------

struct Student
{
    int marks[6];
    int subjects;
};

void displayMarks(struct Student *s);
void acceptMarks(struct Student *s);
int appendMarks(struct Student *s, int marks);
int insertMarksAt(struct Student *s, int index, int marks);
int deletedMarksAt(struct Student *s, int index);
void findMinMaxMarks(struct Student *s);
int searchMarks(struct Student *s, int marks);

// -------------------------------------------------------

struct Music
{
    int musicList[100];
    int size;
};

void displayMusicPlayList(struct Music *m);
void acceptMusicPlayList(struct Music *m);
int insertSongAt(struct Music *m, int index, int song);
int appendSong(struct Music *m, int song);
int deleteSongAt(struct Music *m, int index);
void reversePlayList(struct Music *m);

// -------------------------------------------------------------

struct Queue
{
    int data[MAX];
    int front;
    int rear;
};

void initQueue(struct Queue *q);
int enqueue(struct Queue *q, int patientId);
int dequeue(struct Queue *q);
void peek(struct Queue *q);
int search(struct Queue *q, int patientId);
void displayQueue(struct Queue *q);

// void display(struct Array arr){
//     if(arr.length == 0){
//         printf("array is empty");
//     }else{
//         for(int i=0;i<arr.length;i++){
//             printf("%d ",arr.data[i]);
//         }
//     }    
// }
// int append(struct Array *arr, int value){

//     if(arr->length >= arr->size){
//         return 0;
//     }else{
//         arr->data[arr->length]=value;
//         arr->length++;
//         return 1;
//     }
// }

// int insertAt(struct Array *arr, int index, int value){
    
//     if(index < 0 || index >= arr->length){
//         return 0;
//     }

//     if(arr->length >= arr->size){
//         return 0;
//     }

//     for(int i=arr->length; i > index; i--){
//         arr->data[i] = arr->data[i-1];
//     }
// linearSearch
//     arr->data[index] = value;
//     arr->length++;
//     return 1;
// }

// int deleteAt(struct Array *arr, int index, int *deletedValue){

//     if(index < 0 || index >= arr->length){
//         return 0;
//     }

//     *deletedValue = arr->data[index];

//     for(int i=index; i<arr->length-1;i++){
//         arr->data[i] = arr->data[i+1];
//     }

//     arr->length--;
//     return 1;
    
// }

// int linearSearch(struct Array *arr, int key){

//     for(int i=0; i<arr->length; i++){
//         if(arr->data[i] == key){
//             return 1;
//         }
//     }
//     return -1;
// }