
#include<stdio.h>
#include<stdlib.h>
#include "arrayadt.h"

// struct Array{
//     int data[10];
//     int size;
//     int length;
// };

// void display(struct Array arr);
// int append(struct Array *arr, int value);
// int insertAt(struct Array *arr, int index, int value);
// int deleteAt(struct Array *arr, int index, int *deleteValue);
// int linearSearch(struct Array *arr, int key);

// void display(struct Array arr){
//     if(arr.length == 0){
//         printf("array is empty");
//     }else{
//         for(int i=0;i<arr.length;i++){
//             printf("%d ",arr.data[i]);
//         }
//     }    
// }
// int append(struct Array *arr, int value){

//     if(arr->length >= arr->size){
//         return 0;
//     }else{
//         arr->data[arr->length]=value;
//         arr->length++;
//         return 1;
//     }
// }

// int insertAt(struct Array *arr, int index, int value){
    
//     if(index < 0 || index >= arr->length){
//         return 0;
//     }

//     if(arr->length >= arr->size){
//         return 0;
//     }

//     for(int i=arr->length; i > index; i--){
//         arr->data[i] = arr->data[i-1];
//     }

//     arr->data[index] = value;
//     arr->length++;
//     return 1;
// }

// int deleteAt(struct Array *arr, int index, int *deletedValue){

//     if(index < 0 || index >= arr->length){
//         return 0;
//     }

//     *deletedValue = arr->data[index];

//     for(int i=index; i<arr->length-1;i++){
//         arr->data[i] = arr->data[i+1];
//     }

//     arr->length--;
//     return 1;
    
// }

// int linearSearch(struct Array *arr, int key){

//     for(int i=0; i<arr->length; i++){
//         if(arr->data[i] == key){
//             return 1;
//         }
//     }
//     return -1;
// }

int main(){

    struct Array arr;
    int n,size;
    int choice, value, index, deletedValue, result;

    printf("\nEnter the max size of array : ");
    scanf("%d",&size);
    if(size>100){
        size=100;
    }

    arr.size=size;
    arr.length=0;

    printf("\nEnter the init size of array : ");
    scanf("%d",&n);
    if(n>size){
        n=size;
    }

    printf("\nEnter the array elements : ");
    for(int i=0;i<n;i++){
        scanf("%d",&arr.data[i]);
    }

    arr.length=n;

    do{
        printf("\n----- menu -----\n1. Display\n2. Insert\n3. Append\n4. Delete\n5. Search\n6. Exit\n");
        printf("\nEnter the Choice : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                display(arr);
                break;
            
            case 2:
                printf("\nEnter the Index and value to insert in the array : ");
                scanf("%d and %d",&index, &value);

                result = insertAt(&arr, index, value);

                if(result){
                    printf("value inserted...\n");
                }else{
                    printf("fault to value insert...\n");
                }
                break;
            
            case 3:
                printf("Enter the value to append : ");
                scanf("%d",&value);

                result = append(&arr, value);

                if(result){
                    printf("value appended...\n");
                }else{
                    printf("fault to value append...\n");
                }
                break;
            
            case 4:
                printf("\nEnter the Index : ");
                scanf("%d",&index);

                result = deleteAt(&arr, index, &deletedValue);

                if(result){
                    printf("value is deleted %d ...\n",deletedValue);
                }else{
                    printf("fault to value delete...\n");
                }
                break;
            
            case 5:
                printf("\nEnter the key : ");
                scanf("%d",&value);

                result = linearSearch(&arr, value);

                if(result){
                    printf("value is not found...\n");
                }else{
                    printf("value is found at the index %d ...\n",index);
                }
                break;
            
            case 6:
                exit(0);
            default:
                printf("Invalid choice try again...\n");
                break;
            
        }
    }while(choice!=6);

    return 0;
}

