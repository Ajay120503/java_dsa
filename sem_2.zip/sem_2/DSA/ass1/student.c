#include <stdio.h>
#include"arrayadt.h"

// struct Student
// {
//     int marks[6];
//     int subjects;
// };

// void displayMarks(struct Student *s);
// void acceptMarks(struct Student *s);
// int appendMarks(struct Student *s, int marks);
// int insertMarksAt(struct Student *s, int index, int marks);
// int deletedMarksAt(struct Student *s, int index);
// void findMinMaxMarks(struct Student *s);
// int searchMarks(struct Student *s, int marks);

// void displayMarks(struct Student *s)
// {
//     if (s->subjects == 0)
//     {
//         printf("Marks set is Empty!");
//         return;
//     }

//     else
//     {
//         printf("\nMarks of subject is : ");
//         for (int i = 0; i < s->subjects; i++)
//         {
//             printf("%d ", s->marks[i]);
//         }
//     }
// }

// void acceptMarks(struct Student *s)
// {

//     printf("\nEnter the Subject Marks : ");
//     for (int i = 0; i < s->subjects; i++)
//     {
//         scanf("%d", &s->marks[i]);
//     }
// }

// int appendMarks(struct Student *s, int marks)
// {
//     if (s->subjects == 0)
//     {
//         return 0;
//     }

//     s->marks[s->subjects++] = marks;
//     return 1;
// }

// int insertMarksAt(struct Student *s, int index, int marks)
// {

//     for (int i = s->subjects; i > index; i--)
//     {
//         s->marks[i] = s->marks[i - 1];
//     }

//     s->marks[index] = marks;
//     s->subjects++;
//     return 1;
// }

// int deletedMarksAt(struct Student *s, int index)
// {
//     for (int i = index; i < s->subjects - 1; i++)
//     {
//         s->marks[i] = s->marks[i + 1];
//     }

//     s->subjects--;
//     return 1;
// }

// void findMinMaxMarks(struct Student *s)
// {
//     int min = s->marks[0], max = s->marks[0];

//     for (int i = 0; i < s->subjects; i++)
//     {
//         if (s->marks[i] < min)
//         {
//             min = s->marks[i];
//         }
//         if (s->marks[i] > max)
//         {
//             max = s->marks[i];
//         }
//     }

//     printf("\nmin marks is %d\nmax marks is %d\n", min, max);
// }

// int searchMarks(struct Student *s, int marks)
// {
//     for (int i = 0; i < s->subjects; i++)
//     {
//         if (s->marks[i] == marks)
//         {
//             return i;
//         }
//     }
//     return -1;
// }

int main()
{
    struct Student s;
    int subjects, marks, index, result;

    printf("\nEnter the total Subjects count : ");
    scanf("%d", &subjects);
    s.subjects = subjects;

    acceptMarks(&s);
    displayMarks(&s);

    // printf("\nEnter the marks to be appended : ");
    // scanf("%d", &marks);
    // appendMarks(&s, marks);
    // displayMarks(&s);

    // printf("\nEnter the Index : ");
    // scanf("%d", &index);
    // printf("\nEnter the marks to be inserted : ");
    // scanf("%d", &marks);
    // insertMarksAt(&s, index, marks);
    // displayMarks(&s);

    // printf("\nEnter the Index : ");
    // scanf("%d", &index);
    // deletedMarksAt(&s, index);
    // displayMarks(&s);

    // findMinMaxMarks(&s);

    // printf("\nEnter the marks to be inserted : ");
    // scanf("%d", &marks);

    // result = searchMarks(&s, marks);

    // if (result == 1)
    // {
    //     printf("\nmarks found at the index %d\n", result);
    // }
    // else
    // {
    //     printf("\nmarks not found\n");
    // }

    return 0;
}