#include <stdio.h>

#define MAX 100

int seats[MAX];
int n;

void displaySeats()
{
    printf("Seats: ");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", seats[i]);
    }
    printf("\n");
}

void bookSeat()
{
    int seatNo;
    printf("Enter seat number to book (1-%d): ", n);
    scanf("%d", &seatNo);

    if (seatNo < 1 || seatNo > n)
    {
        printf("Invalid seat number!\n");
    }
    else if (seats[seatNo - 1] == 1)
    {
        printf("Seat already booked!\n");
    }
    else
    {
        seats[seatNo - 1] = 1;
        printf("Seat %d booked successfully.\n", seatNo);
    }
}

void cancelSeat()
{
    int seatNo;
    printf("Enter seat number to cancel (1-%d): ", n);
    scanf("%d", &seatNo);

    if (seatNo < 1 || seatNo > n)
    {
        printf("Invalid seat number!\n");
    }
    else if (seats[seatNo - 1] == 0)
    {
        printf("Seat already available!\n");
    }
    else
    {
        seats[seatNo - 1] = 0;
        printf("Booking cancelled for seat %d.\n", seatNo);
    }
}

void countSeats()
{
    int booked = 0, available = 0;

    for (int i = 0; i < n; i++)
    {
        if (seats[i] == 1)
            booked++;
        else
            available++;
    }

    printf("Booked = %d\n", booked);
    printf("Available = %d\n", available);
}

void searchSeat()
{
    int seatNo;
    printf("Enter seat number to search: ");
    scanf("%d", &seatNo);

    if (seatNo < 1 || seatNo > n)
    {
        printf("Invalid seat number!\n");
    }
    else if (seats[seatNo - 1] == 1)
    {
        printf("Seat %d is Booked.\n", seatNo);
    }
    else
    {
        printf("Seat %d is Available.\n", seatNo);
    }
}

int main()
{
    int choice;

    printf("Enter number of seats (max 100): ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
        seats[i] = 0;

    do
    {
        printf("\n--- CINEMA SEAT BOOKING SYSTEM ---\n");
        printf("1. Display Seats\n");
        printf("2. Book Seat\n");
        printf("3. Cancel Booking\n");
        printf("4. Count Seats\n");
        printf("5. Search Seat\n");
        printf("6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            displaySeats();
            break;
        case 2:
            bookSeat();
            break;
        case 3:
            cancelSeat();
            break;
        case 4:
            countSeats();
            break;
        case 5:
            searchSeat();
            break;
        case 6:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice!\n");
        }
    } while (choice != 6);

    return 0;
}
