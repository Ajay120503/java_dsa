#include <stdio.h>
#include "arrayadt.h"

// struct Music
// {
//     int musicList[100];
//     int size;
// };

// void displayMusicPlayList(struct Music *m);
// void acceptMusicPlayList(struct Music *m);
// int insertSongAt(struct Music *m, int index, int song);
// int appendSong(struct Music *m, int song);
// int deleteSongAt(struct Music *m, int index);
// void reversePlayList(struct Music *m);

// void displayMusicPlayList(struct Music *m)
// {
//     for (int i = 0; i < m->size; i++)
//     {
//         printf("%d ", m->musicList[i]);
//     }
//     printf("\n");
// }

// void acceptMusicPlayList(struct Music *m)
// {
//     printf("Enter the music playlist : ");
//     for (int i = 0; i < m->size; i++)
//     {
//         scanf("%d", &m->musicList[i]);
//     }
// }

// int insertSongAt(struct Music *m, int index, int song)
// {

//     for (int i = m->size; i > index; i--)
//     {
//         m->musicList[i] = m->musicList[i - 1];
//     }

//     m->musicList[index] = song;
//     m->size++;
//     return 1;
// }

// int appendSong(struct Music *m, int song)
// {
//     m->musicList[m->size++] = song;
//     return 1;
// }

// int deleteSongAt(struct Music *m, int index)
// {

//     for (int i = index; i < m->size - 1; i++)
//     {
//         m->musicList[i] = m->musicList[i + 1];
//     }

//     m->size--;
//     return 1;
// }

// void reversePlayList(struct Music *m)
// {
//     int reversePlayList[m->size];

//     for (int i = 0; i < m->size; i++)
//     {
//         reversePlayList[i] = m->musicList[m->size - i - 1];
//     }

//     for (int i = 0; i < m->size; i++)
//     {
//         m->musicList[i] = reversePlayList[i];
//     }
// }

int main()
{

    struct Music m;
    int size = 5;

    m.size = size;

    acceptMusicPlayList(&m);
    printf("Music Playlist is : ");
    displayMusicPlayList(&m);

    printf("after appended : ");
    appendSong(&m, 99);
    displayMusicPlayList(&m);

    printf("after inserted at index : ");
    insertSongAt(&m, 2, 55);
    displayMusicPlayList(&m);

    printf("after deleted at index : ");
    deleteSongAt(&m, 1);
    displayMusicPlayList(&m);

    printf("after reverse the playlist : ");
    reversePlayList(&m);
    displayMusicPlayList(&m);

    return 0;
}