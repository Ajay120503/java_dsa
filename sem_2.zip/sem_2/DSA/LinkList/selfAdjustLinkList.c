#include<stdio.h>
#include<stdlib.h>

struct Node{
    int data;
    struct Node *next;
};

struct Node *head = NULL;
struct Node *tail = NULL;


void insertAtEnd(int value){
    struct Node *newNode = malloc(sizeof(struct Node));

    if(newNode == NULL){
        printf("Memory allocation failed\n");
        return;
    }

    newNode->data = value;
    newNode->next = NULL;

    if(head == NULL){
        head = tail = newNode;
    }else{
        tail->next = newNode;
        tail = newNode;
    }
}

void display(){
    struct Node *temp = head;

    if(temp == NULL){
        printf("LinkList is Empty\n");
        return;
    }

    printf("LinkList is : ");
    while(temp != NULL){
        printf("%d ",temp->data);
        temp = temp->next;
    }

}

void searchMoveToFront(int key){

    struct Node* temp = head;
    struct Node* prev = NULL;

    if(head == NULL){
        printf("LinkList is Empty\n");
        return;
    }

    if(head->data == key){
        printf("\nelement %d found at head no movement required\n",key);
        return;
    }

    while(temp != NULL && temp->data != key){
        prev = temp;
        temp = temp->next;
    }

    if(temp == NULL){
        printf("\n%d element not found\n",key);
    }

    if(temp == tail){
        tail = prev;
    }

    prev->next = temp->next;
    temp->next = head;
    head = temp;

    printf("\nelement %d found and move to front\n",key);

}

int main(){

    insertAtEnd(10);
    insertAtEnd(20);
    insertAtEnd(30);
    insertAtEnd(50);
    insertAtEnd(40);
    display();
    searchMoveToFront(40);
    display();
    searchMoveToFront(10);
    display();
    searchMoveToFront(10);
    display();
    return 0;
}