#include<stdio.h>
#include<stdlib.h>

struct Node{
    int data;
    struct Node *next;
};

struct Node *head = NULL;
struct Node *tail = NULL;

void insertAtFirst(int value){
    struct Node *newNode = malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = head;
    head = newNode;

    if(tail == NULL){
        tail = newNode;
    }
}

void insertAtEnd(int value){
    struct Node *newNode = malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = NULL;

    if(head == NULL){
        head = tail = newNode;
    }
    else{
        tail->next = newNode;
        tail = newNode;
    }
}

void insertAtPosition(int value, int position){
    if(position == 1){
        insertAtFirst(value);
    }

    struct Node *temp = head;

    for(int i = 1; i < position - 1 && temp != NULL; i++ ){
        temp = temp->next;

        if(temp == NULL){
            printf("Invalid Position\n");
        }
    }

    struct Node *newNode = malloc(sizeof(struct Node));

    newNode->data = value;
    newNode->next = temp->next;
    temp->next = newNode;

    if(newNode->next == NULL){
        tail = newNode;
    }
}

void deleteAtFirst(){
    if(head == NULL){
        printf("Link List is Empty");
        return;
    }

    struct Node *temp = head;
    head = head->next;
    free(temp);

    if(head == NULL){
        tail = NULL;
    }
}

void deleteAtEnd(){
    if(head == NULL){
        printf("Link List is Empty");
        return;
    }

    if(head == tail){
        free(head);
        head = tail = NULL;
        return;
    }

    struct Node *temp = head;

    while(temp->next != tail){
        temp = temp->next;
    }

    free(tail);
    tail = temp;
    tail->next = NULL;
}

void deleteByValue(int value){
    if(head == NULL){
        printf("Link List is Empty");
        return;
    }

    if(head->data == value){
        deleteAtFirst();
        return;
    }

    struct Node *temp = head;
    while(temp->next != NULL && temp->next->data != value){
        temp = temp->next;
    }

    if(temp->next == NULL){
        printf("Value not found\n");
        return;
    }

    struct Node *del = temp->next;
    temp->next = del->next;

    if(del == tail){
        tail = temp;
    }

    free(del);
}

int search(int value){
    if(head == NULL){
        printf("Link List is Empty!\n");
    }

    struct Node *temp = head;
    int pos = 1;

    while(temp != NULL){
        if(temp->data == value){
            return pos;
        }
        temp = temp->next;
        pos++;
    }
    return 0;
}

void withoutReturnSearch(int value){
     if(head == NULL){
        printf("Link List is Empty!\n");
    }

    struct Node *temp = head;
    int pos = 1;

    while(temp != NULL){
        if(temp->data == value){
            printf("found at %d\n",pos);
        }
        else{
            printf("not found\n");
        }
        temp = temp->next;
        pos++;
    }
}

void display(){
    struct Node *temp = head;

    if(temp == NULL ){
        printf("Link List is Empty\n");
        return;
    }

    while(temp != NULL){
        printf("%d-->",temp->data);
        temp = temp -> next;
    }
    //printf("NULL\n");
}


int main(){

    int value, choice, pos;

     do{
        printf("\n----- menu -----\n1. Display\n2. InsertAtFirst\n3. InsertAtEnd\n4. InsertAtPos\n5. DeleteAtFirst\n6. DeleteAtEnd\n7. DeleteByValue\n8. Search\n9. Exit\n");
        printf("\nEnter the Choice : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                display();
                break;
            
            case 2:
                printf("\nEnter the Value : ");
                scanf("%d",&value);
                insertAtFirst(value);
                printf("inserted at first...\n");
                break;
            
            case 3:
                printf("\nEnter the Value : ");
                scanf("%d",&value);
                insertAtEnd(value);
                printf("inserted at last...\n");
                break;
            
            case 4:
                printf("\nEnter the Value : ");
                scanf("%d",&value);
                printf("\nEnter the pos : ");
                scanf("%d",&pos);
                insertAtPosition(value, pos);
                printf("inserted by postion...\n");
                break;
            
            case 5:
                deleteAtFirst();
                printf("deleted at fist...\n");
                break;
            case 6:
                deleteAtEnd();
                printf("deleted at end ...\n");
                break;
            case 7:
                printf("\nEnter the Value : ");
                scanf("%d",&value);
                deleteByValue(value);
                printf("deleted...\n");
                break;
            case 8:
                printf("\nEnter the Value : ");
                scanf("%d",&value);
                pos = search(value);
                if(pos){
                    printf("founded at %d\n",pos);
                }
                else{
                    printf("not found\n");
                }
                break;
            case 9:
                exit(0);
            default:
                printf("Invalid choice try again...\n");
                break;
            
        }
    }while(choice!=9);

    // display();
    // insertAtFirst(20);
    // insertAtFirst(200);
    // insertAtEnd(10);
    // insertAtEnd(10);
    // insertAtEnd(100);
    // insertAtPosition(30,2);
    // insertAtPosition(31,3);
    // display();
    // deleteAtFirst();
    // deleteAtEnd();
    // display();
    // deleteByValue(31);
    // display();
    // withoutReturnSearch(20);
    return 0;
}