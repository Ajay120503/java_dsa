/*
Stack Implementation as an ADT
Write a C program to implement a stack as an Abstract Data Type (ADT) using an array.
Program Requirements:
- Define stack structure
- Implement initialize, push, pop, and peek operations
- Check stack overflow and underflow conditions
- Display appropriate messages
*/

#include <stdio.h>
#define MAX 5

// struct ADT 
typedef struct {
    int arr[MAX];
    int top;
} Stack;

void initialize (Stack *s) {
    s->top = -1;
}

int isFull(Stack *s) {
    return s->top == MAX -1;
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

void push (Stack *s, int value) {
    if(isFull(s)) {
        printf("Stack Overflow! value cannot be inserted");
        return;
    }
    s->top++;
    s->arr[s->top] = value;
    printf("%d is pushed into the stack", value);
}

void pop (Stack *s) {
    if(isEmpty(s)) {
        printf("Stack Underflow! notthing to POP");
        return;
    }
    printf("%d value is poped from the stack", s->arr[s->top]);
    s->top--;
}

void peek(Stack *s){
    if(isEmpty(s)) {
        printf("Stack is empty notthing to show");
        return;
    }
    printf("Top element: %d", s->arr[s->top]);
}

void display(Stack *s) {
    if (isEmpty(s)) {
        printf("Stack is empty");
        return;
    }
    printf("Stack Elements are: \n");
    for (int i = s->top; i >= 0; i--) {
        printf("%d ", s->arr[i]);   
    }
}

int main() {
    Stack s;
    initialize(&s);

    int choice, value;

    do {
        printf("\n\n--Stack Menu--\n1. Push \n2. Pop \n3. Peek \n4. Display \n5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1: 
                printf("Enter the value to push: ");
                scanf("%d", &value);
                push(&s, value);
                break;
            case 2: 
                pop(&s);
                break;
            case 3:
                peek(&s);
                break;
            case 4: 
                display(&s);
                break;
            case 5: 
                printf("Exiting...");
                break;
            default: 
                printf("invalid choice!");
        }
    } while (choice != 5);
    return 0;
}
