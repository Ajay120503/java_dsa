/*
Circular Queue
• Implement a circular queue using an array
• Perform Insertion, Deletion, and Display operations
• Understand the limitations of the Linear Queue
• Apply circular logic to the front and rear
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 5

int queue[MAX];
int front = -1;
int rear = -1;

void enqueue (int value) {
    if ((rear + 1) % MAX == front) {
        printf("Queue is FULL\n");
    } else {
        if (front == -1) 
            front = rear = 0;
        else 
            rear = (rear + 1) % MAX;

        queue[rear] = value;
        printf("%d inserted\n", value);
    }
}

void dequeue() {
    if (front == -1) {
        printf("Queue is Empty\n");
    } else {
        printf("%d deleted\n", queue[front]);
        if (front == rear) 
            front = rear = -1;
        else 
            front = (front + 1) % MAX;
    }
}

void display() {
    if (front == -1) {
        printf("Queue is EMPTY\n");
        return;
    }

    int i=front;
    printf("Queue: ");
    while (1) {
        printf("%d ", queue[i]);
        if (i == rear) 
            break;
        i = (i+1) % MAX;
    }
    printf("\n");
}

int main() {
    int choice, value;

    while (1) {
        printf("\n--- Circular Queue Menu ---\n");
        printf("Enter your choice: \n1. Enqueue \n2. Dequeue \n3. Display \n4.Exit \n");
        scanf("%d", &choice);
        switch (choice) {
            case 1: 
                printf("Enter a value: ");
                scanf("%d", &value);
                enqueue(value);
                break;
            case 2: 
                dequeue();
                break;
            case 3:
                display();
                break;
            case 4: 
                exit(0);
            default: 
                printf("Invalid choice\n");
        }
    }
}