/*
Write a menu-driven C program to perform the following operations on a Doubly Linked List:
a. Create
b. Display
c. Insert at the given position
d. Delete from Beginning
e. Count Nodes
f. Exit
*/

#include <stdio.h>
#include <stdlib.h>

// Node structure
struct Node {
    int data;
    struct Node *prev;
    struct Node *next;
};

struct Node *head = NULL;

// Free entire list
void freeList() {
    struct Node *temp = head;
    while (temp != NULL) {
        struct Node *nextNode = temp->next;
        free(temp);
        temp = nextNode;
    }
    head = NULL;
}

// a) Create
void create() {
    int n, val;
    struct Node *newNode, *temp;

    freeList(); // clear old list

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    if (n <= 0) return;

    printf("Enter %d elements: ", n);
    scanf("%d", &val);

    head = (struct Node*)malloc(sizeof(struct Node));
    head->data = val;
    head->prev = NULL;
    head->next = NULL;

    temp = head;

    for (int i = 1; i < n; i++) {
        scanf("%d", &val);

        newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = val;
        newNode->next = NULL;
        newNode->prev = temp;

        temp->next = newNode;
        temp = newNode;
    }
}

// b) Display
void display() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = head;
    printf("List: ");

    while (temp != NULL) {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    }

    printf("NULL\n");
}

// c) Insert at given position (1-based)
void insertAtPosition() {
    int pos, val;
    printf("Enter position: ");
    scanf("%d", &pos);
    printf("Enter value: ");
    scanf("%d", &val);

    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = val;

    // Insert at beginning
    if (pos == 1) {
        newNode->prev = NULL;
        newNode->next = head;

        if (head != NULL)
            head->prev = newNode;

        head = newNode;
        printf("Inserted at position %d\n", pos);
        return;
    }

    struct Node *temp = head;
    int i = 1;

    while (temp != NULL && i < pos - 1) {
        temp = temp->next;
        i++;
    }
    if (temp == NULL) {
        printf("Invalid position\n");
        free(newNode);
        return;
    }

    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;

    printf("Inserted at position %d\n", pos);
}

// d) Delete from Beginning
void deleteBeginning() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = head;

    printf("Deleted: %d\n", temp->data);

    head = head->next;

    if (head != NULL)
        head->prev = NULL;

    free(temp);
}

// e) Count Nodes
void countNodes() {
    int count = 0;
    struct Node *temp = head;

    while (temp != NULL) {
        count++;
        temp = temp->next;
    }

    printf("Total nodes: %d\n", count);
}

// f) Main Menu
int main() {
    int choice;

    while (1) {
        printf("\n--- Doubly Linked List Menu ---\n");
        printf("1. Create\n2. Display\n3. Insert at Position \n4. Delete from Beginning\n5. Count Nodes\n6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: create(); break;
            case 2: display(); break;
            case 3: insertAtPosition(); break;
            case 4: deleteBeginning(); break;
            case 5: countNodes(); break;
            case 6: freeList(); exit(0);
            default: printf("Invalid choice\n");
        }
    }
}