/*
Stack Implementation as an ADT
Write a C program to implement a stack as an Abstract Data Type (ADT) using a linked list.
Program Requirements:
- Define stack structure
- Implement initialize, push, pop, and peek operations
- Check stack overflow and underflow
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

typedef struct {
    Node* top;
} Stack; 

void initialize (Stack *s) {
    s->top = NULL;
}

int isEmpty(Stack *s) {
    return s->top == NULL;
}

void push (Stack *s, int value) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    if(newNode == NULL) {
        printf("Stack OVERLFLOW!! Memory not available");
        return;
    }
    newNode->data = value;
    newNode->next = s->top;
    s->top = newNode;
    printf("%d pushed into stack", value);
}

void pop (Stack *s) {
    if(isEmpty(s)) {
        printf("Stack underflow notthing to pop");
        return;
    }
    Node *temp = s->top;
    printf("%d value is popped from the stack", temp->data);
    s->top = temp->next;
    free(temp);
}

void peek(Stack *s) {
    if(isEmpty(s)) {
        printf("Stack is empty notthing to show");
        return;
    }
    printf("Top element: %d", s->top->data);   
}

void display(Stack *s) {
    if(isEmpty(s)) {
        printf("Stack is empty");
        return;
    }
    Node *temp = s->top;
    printf("Stack elements are: \n");
    while (temp != NULL) {
        printf("%d\n", temp->data);
        temp = temp->next;
    }
}

int main() {
    Stack s;
    initialize(&s);
    int choice, value;

    do {
        printf("\n\n--Stack Menu Linked List--\n");
        printf("1. Push \n2. Pop \n3. Peek \n4. Display \n5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: 
                printf("Enter the value: ");
                scanf("%d", &value);
                push(&s, value);
                break;
            case 2: 
                pop(&s);
                break;
            case 3: 
                peek(&s);
                break;
            case 4: 
                display(&s);
                break;
            case 5: 
                printf("Exiting...");
                break;
            default: 
                printf("invalid choice");
        }
    } while (choice != 5);
    return 0;
}
