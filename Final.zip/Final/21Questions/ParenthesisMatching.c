#include <stdio.h>   
#include <stdlib.h>  
#include <string.h>  

#define MAX 100   

typedef struct {
    char arr[MAX]; // Array to store brackets
    int top;       // Index of top element
} Stack;

// Initialize stack (empty)
void initialize(Stack *s) {
    s->top = -1; // Empty stack
}

// Check if stack is empty
int isEmpty(Stack *s) {
    return (s->top == -1);
}

// Check if stack is full
int isFull(Stack *s) {
    return (s->top == MAX - 1);
}

// Push character into stack
void push(Stack *s, char ch) {
    if (isFull(s)) {               // Overflow condition
        printf("Stack Overflow\n");
        exit(1);
    }
    s->arr[++(s->top)] = ch;       // Increment top and insert element
}

// Pop character from stack
char pop(Stack *s) {
    if (isEmpty(s)) {              // Underflow condition
        return '\0';               // Return null character
    }
    return s->arr[(s->top)--];     // Return top element and decrease top
}

// Function to check matching pair of brackets
int isMatchingPair(char open, char close) {
    if (open == '(' && close == ')')  return 1;
    if (open == '{' && close == '}')  return 1;
    if (open == '[' && close == ']')  return 1;
    return 0; // Not matching
}

int main() {
    Stack s;
    initialize(&s); // Initialize stack

    char exp[MAX];  // Input expression

    printf("Enter Expression: ");
    fgets(exp, MAX, stdin); // Read full line (including spaces)

    // Traverse expression character by character
    for (int i = 0; exp[i] != '\0'; i++) {

        char ch = exp[i];

        // If opening bracket → push to stack
        if (ch == '(' || ch == '{' || ch == '[') {
            push(&s, ch);
        }

        // If closing bracket
        else if (ch == ')' || ch == '}' || ch == ']') {

            // If stack is empty → no matching opening bracket
            if (isEmpty(&s)) {
                printf("Unbalanced Parentheses\n");
                return 0;
            }

            // Pop top element
            char top = pop(&s);

            // Check if pair matches
            if (!isMatchingPair(top, ch)) {
                printf("Unbalanced Parentheses\n");
                return 0;
            }
        }
    }

    // After processing entire expression
    if (isEmpty(&s))
        printf("Balanced Parentheses\n");
    else
        printf("Unbalanced Parentheses\n");

    return 0;
}