/*
Write a menu-driven C program for Skip List to perform the following operations:
a. Insert Node
b. Search Node
c. Delete Node
d. Display All Levels of Skip List
e. Exit
*/


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_LEVEL 5
#define P 0.5   // Probability for random level

// Node structure
typedef struct Node {
    int key;
    struct Node* forward[MAX_LEVEL + 1];
} Node;

// Skip List structure
typedef struct SkipList {
    int level;
    Node* header;
} SkipList;

// Create new node
Node* createNode(int key, int level) {
    Node* n = (Node*)malloc(sizeof(Node));
    n->key = key;
    for (int i = 0; i <= MAX_LEVEL; i++)
        n->forward[i] = NULL;
    return n;
}

// Create skip list
SkipList* createSkipList() {
    SkipList* list = (SkipList*)malloc(sizeof(SkipList));
    list->level = 0;
    list->header = createNode(-1, MAX_LEVEL);
    return list;
}

// Generate random level
int randomLevel() {
    int level = 0;
    while ((rand() / (double)RAND_MAX) < P && level < MAX_LEVEL)
        level++;
    return level;
}

// Insert node
void insert(SkipList* list, int key) {
    Node* update[MAX_LEVEL + 1];
    Node* current = list->header;

    for (int i = list->level; i >= 0; i--) {
        while (current->forward[i] && current->forward[i]->key < key)
            current = current->forward[i];
        update[i] = current;
    }

    current = current->forward[0];

    if (current == NULL || current->key != key) {
        int rlevel = randomLevel();

        if (rlevel > list->level) {
            for (int i = list->level + 1; i <= rlevel; i++)
                update[i] = list->header;
            list->level = rlevel;
        }

        Node* newNode = createNode(key, rlevel);

        for (int i = 0; i <= rlevel; i++) {
            newNode->forward[i] = update[i]->forward[i];
            update[i]->forward[i] = newNode;
        }

        printf("Inserted: %d\n", key);
    } else {
        printf("Key already exists\n");
    }
}

// Search node
void search(SkipList* list, int key) {
    Node* current = list->header;

    for (int i = list->level; i >= 0; i--) {
        while (current->forward[i] && current->forward[i]->key < key)
            current = current->forward[i];
    }

    current = current->forward[0];

    if (current && current->key == key)
        printf("Found: %d\n", key);
    else
        printf("Not Found\n");
}

// Delete node
void deleteNode(SkipList* list, int key) {
    Node* update[MAX_LEVEL + 1];
    Node* current = list->header;

    for (int i = list->level; i >= 0; i--) {
        while (current->forward[i] && current->forward[i]->key < key)
            current = current->forward[i];
        update[i] = current;
    }

    current = current->forward[0];

    if (current && current->key == key) {
        for (int i = 0; i <= list->level; i++) {
            if (update[i]->forward[i] != current)
                break;
            update[i]->forward[i] = current->forward[i];
        }

        free(current);

        while (list->level > 0 && list->header->forward[list->level] == NULL)
            list->level--;

        printf("Deleted: %d\n", key);
    } else {
        printf("Key not found\n");
    }
}

// Display skip list
void display(SkipList* list) {
    printf("\nSkip List Levels:\n");

    for (int i = list->level; i >= 0; i--) {
        Node* node = list->header->forward[i];
        printf("Level %d: ", i);

        while (node != NULL) {
            printf("%d ", node->key);
            node = node->forward[i];
        }
        printf("\n");
    }
}

// Main menu
int main() {
    srand(time(NULL));

    SkipList* list = createSkipList();
    int choice, value;

    while (1) {
        printf("\n--- Skip List Menu ---\n");
        printf("1. Insert Node\n");
        printf("2. Search Node\n");
        printf("3. Delete Node\n");
        printf("4. Display All Levels\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                insert(list, value);
                break;

            case 2:
                printf("Enter value to search: ");
                scanf("%d", &value);
                search(list, value);
                break;

            case 3:
                printf("Enter value to delete: ");
                scanf("%d", &value);
                deleteNode(list, value);
                break;

            case 4:
                display(list);
                break;

            case 5:
                printf("Exiting...\n");
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }

    return 0;
}