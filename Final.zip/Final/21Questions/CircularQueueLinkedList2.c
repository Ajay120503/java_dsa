/*
Write a menu-driven C program to perform the following operations on a Circular Linked List:
a. Create
b. Display
c. Insert at End
d. Delete from Beginning
e. Count Nodes
f. Exit
*/

#include <stdio.h>
#include <stdlib.h>

// Node structure
struct Node {
    int data;
    struct Node *next;
};

struct Node *last = NULL;

// Free entire list (used before re-creating)
void freeList() {
    if (last == NULL) return;

    struct Node *temp = last->next;
    struct Node *nextNode;

    while (temp != last) {
        nextNode = temp->next;
        free(temp);
        temp = nextNode;
    }
    free(last);
    last = NULL;
}

// a) Create
void create() {
    int n, val;
    struct Node *newNode;

    freeList();  // reset old list

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &val);

        newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = val;

        if (last == NULL) {
            last = newNode;
            last->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
            last = newNode;
        }
    }
}

// b) Display
void display() {
    if (last == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = last->next;
    printf("List: ");

    do {
        printf("%d -> ", temp->data);
        temp = temp->next;
    } while (temp != last->next);

    printf("(back to start)\n");
}

// c) Insert at End
void insertEnd() {
    int val;
    struct Node *newNode;

    printf("Enter value: ");
    scanf("%d", &val);

    newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = val;

    if (last == NULL) {
        last = newNode;
        last->next = last;
    } else {
        newNode->next = last->next;
        last->next = newNode;
        last = newNode;
    }

    printf("Inserted at end\n");
}

// d) Delete from Beginning
void deleteBeginning() {
    if (last == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node *first = last->next;

    if (first == last) {
        printf("Deleted: %d\n", first->data);
        free(first);
        last = NULL;
        return;
    }

    printf("Deleted: %d\n", first->data);
    last->next = first->next;
    free(first);
}

// e) Count Nodes
void countNodes() {
    if (last == NULL) {
        printf("Total nodes: 0\n");
        return;
    }

    int count = 0;
    struct Node *temp = last->next;

    do {
        count++;
        temp = temp->next;
    } while (temp != last->next);

    printf("Total nodes: %d\n", count);
}

// f) Main Menu
int main() {
    int choice;

    while (1) {
        printf("\n--- Circular Linked List Menu ---\n");
        printf("1. Create\n2. Display\n3. Insert at End\n4. Delete from Beginning\n5. Count Nodes\n6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: create(); break;
            case 2: display(); break;
            case 3: insertEnd(); break;
            case 4: deleteBeginning(); break;
            case 5: countNodes(); break;
            case 6: freeList(); exit(0);
            default: printf("Invalid choice\n");
        }
    }
}