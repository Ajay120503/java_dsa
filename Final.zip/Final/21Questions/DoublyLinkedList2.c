/*
Write a menu-driven C program to perform the following operations on a Doubly Linked List:
a. Create
b. Display
c. Insert at the beginning
d. Delete from End
e. Search Element
f. Exit
*/

#include <stdio.h>
#include <stdlib.h>

// Node structure
struct Node {
    int data;
    struct Node *prev;
    struct Node *next;
};

struct Node *head = NULL;

// Free entire list
void freeList() {
    struct Node *temp = head;
    while (temp != NULL) {
        struct Node *nextNode = temp->next;
        free(temp);
        temp = nextNode;
    }
    head = NULL;
}

// a) Create
void create() {
    int n, val;
    struct Node *newNode, *temp;

    freeList(); // clear old list

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    if (n <= 0) return;

    printf("Enter %d elements: ", n);

    // first node
    scanf("%d", &val);
    head = (struct Node*)malloc(sizeof(struct Node));
    head->data = val;
    head->prev = NULL;
    head->next = NULL;

    temp = head;

    for (int i = 1; i < n; i++) {
        scanf("%d", &val);

        newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = val;
        newNode->next = NULL;
        newNode->prev = temp;

        temp->next = newNode;
        temp = newNode;
    }
}

// b) Display
void display() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = head;
    printf("List: ");

    while (temp != NULL) {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    }

    printf("NULL\n");
}

// c) Insert at Beginning
void insertBeginning() {
    int val;
    printf("Enter value: ");
    scanf("%d", &val);

    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = val;
    newNode->prev = NULL;
    newNode->next = head;

    if (head != NULL)
        head->prev = newNode;

    head = newNode;

    printf("Inserted at beginning\n");
}

// d) Delete from End
void deleteEnd() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = head;

    // Only one node
    if (temp->next == NULL) {
        printf("Deleted: %d\n", temp->data);
        free(temp);
        head = NULL;
        return;
    }

    // Traverse to last node
    while (temp->next != NULL) {
        temp = temp->next;
    }

    printf("Deleted: %d\n", temp->data);

    temp->prev->next = NULL;
    free(temp);
}

// e) Search
void search() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    int key, pos = 1;
    printf("Enter element to search: ");
    scanf("%d", &key);

    struct Node *temp = head;

    while (temp != NULL) {
        if (temp->data == key) {
            printf("Found at position %d\n", pos);
            return;
        }
        temp = temp->next;
        pos++;
    }

    printf("Not found\n");
}

// f) Main
int main() {
    int choice;

    while (1) {
        printf("\n--- Doubly Linked List Menu ---\n");
        printf("1. Create\n2. Display\n3. Insert at Beginning \n4. Delete from End\n5. Search\n6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: create(); break;
            case 2: display(); break;
            case 3: insertBeginning(); break;
            case 4: deleteEnd(); break;
            case 5: search(); break;
            case 6: freeList(); exit(0);
            default: printf("Invalid choice\n");
        }
    }
}