#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define MAX 100

typedef struct {
	char* items[MAX];
	int top;
} Stack; 

void init (Stack *s) {
	s->top = -1;
}
int isEmpty(Stack *s) {
	return s->top == -1;
}

void push (Stack *s, char *str) { 
	if (s->top == MAX-1) {
		printf("Stack Overflow, Cannot push value\n");
		exit(1);
	}
	s->items[++(s->top)] = str;
}


char* pop (Stack *s) {
	if (isEmpty(s)) {
		printf("Stack Undeflow\n");
		exit(1);
	}
	return s->items[(s->top)--];
}

int isOperator (char ch) {
	return (ch=='+' || ch=='-' || ch=='*' || ch=='/');
}

void prefixToPostfix (char *prefix) {
	Stack s;
	init (&s);
	int len = strlen(prefix);

	for(int i=len-1; i>=0; i--) {
		char ch = prefix[i];
		
		if (ch==' ')
			continue;

		if (isalnum(ch)) {
			char *op = (char*)malloc(2);
			op[0] = ch;
			op[1] = '\0';
			push (&s, op);
		}
		else if (isOperator(ch)) {
			char *op1 = pop(&s);
			char *op2 = pop(&s);
			char *expr = (char*)malloc(strlen(op1) + strlen(op2) + 2);
			strcpy(expr, op1);
			strcat(expr, op2);

			int l = strlen(expr);
			expr[l] = ch;
			expr[l+1] = '\0';
			push (&s, expr);
		}
	}
	printf("Postfix Expression: %s \n", pop(&s));
}

int main() {
	char prefix[MAX];
	printf("Enter your prefix expression: ");
	scanf("%s", prefix);
	prefixToPostfix(prefix);
	return 0;
}
