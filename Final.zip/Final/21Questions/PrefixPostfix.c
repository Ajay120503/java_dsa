/*
Prefix to Postfix Conversion Using Stack
Write a C program to convert a given Prefix expression into a postfix expression using a stack.
Program Requirements:
- Accept prefix expression from user
- Use a stack for temporary storage
- Support operators +, -, *, /
- Display postfix expression
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 100

// Stack of strings
typedef struct {
    char* items[MAX];
    int top;
} Stack;

void init(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

void push(Stack *s, char *str) {
    if (s->top == MAX - 1) {
        printf("Stack Overflow\n");
        exit(1);
    }
    s->items[++(s->top)] = str; // Increment top and store string
}

char* pop(Stack *s) {
    if (isEmpty(s)) {
        printf("Stack Underflow\n");
        exit(1);
    }
    return s->items[(s->top)--]; // Return top element and decrease top
}

// Function to check operator
int isOperator(char ch) {
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/');
}

// Function to convert prefix to postfix
void prefixToPostfix(char *prefix) {
    Stack s;
    init(&s);  //Initialize stack

    int len = strlen(prefix);

    // Traverse from right to left
    for (int i = len - 1; i >= 0; i--) {
        char ch = prefix[i];

        // Skip spaces
        if (ch == ' ')
            continue;

        // If operand (A-Z, a-z, 0-9)
        if (isalnum(ch)) {
            //Allocate memory for single character operand
            char *op = (char*)malloc(2);
            op[0] = ch;  //store operand
            op[1] = '\0'; //null terminate string
            push(&s, op); //push operand to stack
        }

/*
\0 is the null character in C. It marks the end of a string.
In C, strings are not objects—they are arrays of characters. The compiler does not store length, so it needs a way to know where the string ends.
That’s where \0 comes in.
Without \0, functions like printf, strlen, strcpy will keep reading memory until they accidentally find a \0
*/

        // If operator (+, -, *, /)
        else if (isOperator(ch)) {
            //pop tow oprands from stack
            char *op1 = pop(&s);
            char *op2 = pop(&s);

            // Allocate memory for new expression
            // +2 for operator and null terminator
            char *expr = (char*)malloc(strlen(op1) + strlen(op2) + 2);

            // postfix = op1 op2 operator
            strcpy(expr, op1);  //copy 1st operand
            strcat(expr, op2);  //append second operand

            int l = strlen(expr);   //current length
            expr[l] = ch;           //add opeartor at end
            expr[l + 1] = '\0';     //null terminate
            //push new expressionn back to stack
            push(&s, expr);
        }
    }

    // Final result
    printf("Postfix Expression: %s\n", pop(&s));
}

int main() {
    char prefix[MAX];
    printf("Enter Prefix Expression: ");
    scanf("%s", prefix);
    prefixToPostfix(prefix);
    return 0;
}

/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 50

typedef struct {
    char arr[MAX][MAX];
    int top;
} Stack;

void initialize(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return (s->top == -1);
}

// Fixed push with overflow check
void push(Stack *s, char *str) {
    if (s->top == MAX - 1) {
        printf("Stack Overflow!\n");
        exit(1);
    }
    strcpy(s->arr[++(s->top)], str);
}

char* pop(Stack *s) {
    if (isEmpty(s)) {
        printf("Stack Underflow!\n");
        exit(1);
    }
    return s->arr[(s->top)--];
}

int isOperator(char ch) {
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/');
}

int main() {
    Stack s;
    initialize(&s);

    char prefix[MAX], temp[MAX];

    printf("Enter Prefix Expression: ");
    scanf("%s", prefix);

    int len = strlen(prefix);

    for (int i = len - 1; i >= 0; i--) {

        // If operand
        if (isalnum(prefix[i])) {
            temp[0] = prefix[i];
            temp[1] = '\0';
            push(&s, temp);
        }

        // If operator
        else if (isOperator(prefix[i])) {
            char op1[MAX], op2[MAX];

            strcpy(op1, pop(&s));
            strcpy(op2, pop(&s));

            strcpy(temp, op1);
            strcat(temp, op2);

            int l = strlen(temp);
            temp[l] = prefix[i];
            temp[l + 1] = '\0';

            push(&s, temp);
        }
    }

    printf("Postfix Expression: %s\n", pop(&s));
    return 0;
}
*/
