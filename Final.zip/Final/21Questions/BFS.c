/*
Write a menu-driven C program to perform the following operations on a graph using an adjacency matrix representation:
a. Create Graph – Accept the number of vertices and the adjacency matrix from the user.
b. Display Graph – Display the adjacency matrix of the graph.
c. Breadth First Search (BFS) – Traverse the graph using BFS starting from a given vertex.
*/




#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int adj[MAX][MAX];   // adjacency matrix
int visited[MAX];    // visited array
int n;               // number of vertices

// a) Create Graph
void createGraph() {
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &adj[i][j]);
        }
    }
}

// b) Display Graph
void displayGraph() {
    printf("\nAdjacency Matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", adj[i][j]);
        }
        printf("\n");
    }
}

// c) BFS using Queue
void BFS(int start) {
    int queue[MAX], front = 0, rear = 0;

    // initialize visited array
    for (int i = 0; i < n; i++)
        visited[i] = 0;

    // start BFS
    visited[start] = 1;
    queue[rear++] = start;

    printf("BFS Traversal: ");

    while (front < rear) {
        int vertex = queue[front++];
        printf("%d ", vertex);

        for (int i = 0; i < n; i++) {
            if (adj[vertex][i] == 1 && visited[i] == 0) {
                visited[i] = 1;
                queue[rear++] = i;
            }
        }
    }
    printf("\n");
}

// Menu
int main() {
    int choice, start;

    while (1) {
        printf("\n--- Graph Menu ---\n");
        printf("1. Create Graph\n");
        printf("2. Display Graph\n");
        printf("3. BFS Traversal\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                createGraph();
                break;

            case 2:
                displayGraph();
                break;

            case 3:
                printf("Enter starting vertex (0 to %d): ", n - 1);
                scanf("%d", &start);

                if (start < 0 || start >= n) {
                    printf("Invalid vertex\n");
                } else {
                    BFS(start);
                }
                break;

            case 4:
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }
}