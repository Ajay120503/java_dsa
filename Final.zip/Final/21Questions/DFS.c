/*
Write a menu-driven C program to perform the following operations on a graph using an
adjacency matrix representation:
d. Create Graph – Accept the number of vertices and the adjacency matrix from the user.
e. Display Graph – Display the adjacency matrix of the graph.
f. Breadth First Search (DFS) – Traverse the graph using DFS starting from a given vertex.
*/



#include <stdio.h>
#include <stdlib.h>

#define MAX 20

int adj[MAX][MAX];   // adjacency matrix
int visited[MAX];    // visited array
int n;               // number of vertices

// d) Create Graph
void createGraph() {
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &adj[i][j]);
        }
    }
}

// e) Display Graph
void displayGraph() {
    printf("\nAdjacency Matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", adj[i][j]);
        }
        printf("\n");
    }
}

// f) DFS (Recursive)
void DFS(int v) {
    visited[v] = 1;
    printf("%d ", v);

    for (int i = 0; i < n; i++) {
        if (adj[v][i] == 1 && visited[i] == 0) {
            DFS(i);
        }
    }
}

// Wrapper for DFS
void startDFS(int start) {
    for (int i = 0; i < n; i++)
        visited[i] = 0;

    printf("DFS Traversal: ");
    DFS(start);
    printf("\n");
}

// Menu
int main() {
    int choice, start;

    while (1) {
        printf("\n--- Graph Menu ---\n");
        printf("1. Create Graph\n");
        printf("2. Display Graph\n");
        printf("3. DFS Traversal\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                createGraph();
                break;

            case 2:
                displayGraph();
                break;

            case 3:
                printf("Enter starting vertex (0 to %d): ", n - 1);
                scanf("%d", &start);

                if (start < 0 || start >= n) {
                    printf("Invalid vertex\n");
                } else {
                    startDFS(start);
                }
                break;

            case 4:
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }
}