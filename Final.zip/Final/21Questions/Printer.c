/*
Printer Job Scheduling System
Problem Scenario: Multiple print jobs are sent to a single printer and processed in order they are received.
Programming Task: Write a C program to manage Printer Job Scheduling using a queue.
Program Requirements:
- Store job ID and number of pages
- Add print job
- Process print job
- Display pending print jobs
- Handle queue full and empty conditions
*/

#include <stdio.h>   // For input/output functions
#include <stdlib.h>  // For exit()

#define MAX 20        // Maximum number of jobs in queue

// Structure to represent a print job
typedef struct {
    int jobId;  // Unique job ID
    int pages;  // Number of pages in job
} PrintJob;

// Queue structure
typedef struct {
    PrintJob jobs[MAX]; // Array to store jobs
    int front;          // Points to first job
    int rear;           // Points to last job
} Queue;

// Initialize queue
void initialize(Queue *q) {
    q->front = -1;
    q->rear = -1;
}

// Check if queue is empty
int isEmpty(Queue *q) {
    return (q->front == -1);
}

// Check if queue is full
int isFull(Queue *q) {
    return (q->rear == MAX - 1);
}

// Add print job (enqueue)
void addJob(Queue *q, int id, int pages) {

    // Check overflow condition
    if (isFull(q)) {
        printf("Queue Full! Cannot add new job\n");
        return;
    }

    // If queue is empty → set front to 0
    if (isEmpty(q))
        q->front = 0;

    // Move rear forward
    q->rear++;

    // Insert job details
    q->jobs[q->rear].jobId = id;
    q->jobs[q->rear].pages = pages;

    printf("Print Job %d added (%d pages)\n", id, pages);
}

// Process print job (dequeue)
void processJob(Queue *q) {

    // Check underflow condition
    if (isEmpty(q)) {
        printf("Queue Empty! No jobs to process\n");
        return;
    }

    // Get front job
    PrintJob job = q->jobs[q->front];

    // Display processing job
    printf("Processing Job ID: %d (%d pages)\n", job.jobId, job.pages);

    // Move front forward
    q->front++;

    // If queue becomes empty, reset both pointers
    if (q->front > q->rear)
        q->front = q->rear = -1;
}

// Display all pending jobs
void displayJobs(Queue *q) {

    // Check if empty
    if (isEmpty(q)) {
        printf("No pending print jobs\n");
        return;
    }

    printf("Pending Print Jobs:\n");

    // Traverse from front to rear
    for (int i = q->front; i <= q->rear; i++) {
        printf("Job ID: %d, Pages: %d\n",
               q->jobs[i].jobId,
               q->jobs[i].pages);
    }
}

// Main function (menu-driven)
int main() {
    Queue q;
    initialize(&q); // Initialize queue

    int choice, id, pages;

    while (1) { // Infinite loop

        printf("\n--- Printer Job Scheduling ---\n");
        printf("1. Add Print Job\n");
        printf("2. Process Print Job\n");
        printf("3. Display Pending Jobs\n");
        printf("4. Exit\n");
        printf("Enter choice: ");

        scanf("%d", &choice);

        switch (choice) {

            case 1:
                printf("Enter Job ID: ");
                scanf("%d", &id);

                printf("Enter Number of Pages: ");
                scanf("%d", &pages);

                addJob(&q, id, pages);
                break;

            case 2:
                processJob(&q);
                break;

            case 3:
                displayJobs(&q);
                break;

            case 4:
                exit(0); // Exit program

            default:
                printf("Invalid choice\n");
        }
    }

    return 0;
}