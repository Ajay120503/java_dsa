/*
Write a menu-driven C program to perform the following operations on a Circular Linked List:
a. Create
b. Display
c. Insert at Beginning
d. Delete from End
e. Search Element
f. Exit
*/

#include <stdio.h>
#include <stdlib.h>

// Node structure
struct Node {
    int data;
    struct Node *next;
};

struct Node *last = NULL;

// 🔴 Free entire circular list
void freeList() {
    if (last == NULL) return;

    struct Node *temp = last->next;
    struct Node *nextNode;

    while (temp != last) {
        nextNode = temp->next;
        free(temp);
        temp = nextNode;
    }

    free(last);
    last = NULL;
}

// Create Circular Linked List (fixed + reset)
void create() {
    int n, val;
    struct Node *newNode;

    // 🔴 Clear old list before creating new
    freeList();

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &val);

        newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = val;

        if (last == NULL) {
            last = newNode;
            last->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
            last = newNode;
        }
    }
}

// Display
void display() {
    if (last == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = last->next;
    printf("List: ");

    do {
        printf("%d -> ", temp->data);
        temp = temp->next;
    } while (temp != last->next);

    printf("(back to start)\n");
}

// Insert at Beginning
void insertBeginning() {
    int val;
    struct Node *newNode;

    printf("Enter value: ");
    scanf("%d", &val);

    newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = val;

    if (last == NULL) {
        last = newNode;
        last->next = last;
    } else {
        newNode->next = last->next;
        last->next = newNode;
    }

    printf("Inserted at beginning\n");
}

// Delete from End
void deleteEnd() {
    if (last == NULL) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = last->next;

    if (temp == last) {
        printf("Deleted: %d\n", last->data);
        free(last);
        last = NULL;
        return;
    }

    while (temp->next != last) {
        temp = temp->next;
    }

    printf("Deleted: %d\n", last->data);
    temp->next = last->next;
    free(last);
    last = temp;
}

// Search
void search() {
    if (last == NULL) {
        printf("List is empty\n");
        return;
    }

    int key, pos = 1, found = 0;
    printf("Enter element to search: ");
    scanf("%d", &key);

    struct Node *temp = last->next;

    do {
        if (temp->data == key) {
            printf("Found at position %d\n", pos);
            found = 1;
            break;
        }
        temp = temp->next;
        pos++;
    } while (temp != last->next);

    if (!found)
        printf("Not found\n");
}

// Main
int main() {
    int choice;

    while (1) {
        printf("\n--- Circular Linked List Menu ---\n");
        printf("1. Create\n2. Display\n3. Insert at Beginning\n4. Delete from End\n5. Search\n6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: create(); break;
            case 2: display(); break;
            case 3: insertBeginning(); break;
            case 4: deleteEnd(); break;
            case 5: search(); break;
            case 6: freeList(); exit(0);
            default: printf("Invalid choice\n");
        }
    }
}