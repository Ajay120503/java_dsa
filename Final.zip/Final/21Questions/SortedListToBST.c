/*
Convert Sorted List to Binary Search Tree
Given the head of a singly linked list where elements are sorted in ascending order, convert it
to a height-balanced binary search tree.
*/


#include <stdio.h>
#include <stdlib.h>

typedef struct ListNode {
    int data;
    struct ListNode* next;
} ListNode;

typedef struct TreeNode {
    int data;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

ListNode* createListNode(int value) {
    ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}

void append(ListNode** head, int value) {
    ListNode* newNode = createListNode(value);
    if (*head == NULL) {
        *head = newNode;
        return;
    }

    ListNode* temp = *head;
    while (temp->next)
        temp = temp->next;

    temp->next = newNode;
}

TreeNode* createTreeNode(int value) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->data = value;
    newNode->left = newNode->right = NULL;
    return newNode;
}

ListNode* findMiddle(ListNode* head) {
    ListNode* slow = head;
    ListNode* fast = head;
    ListNode* prev = NULL;

    while (fast && fast->next) {
        prev = slow;
        slow = slow->next;
        fast = fast->next->next;
    }

    if (prev)
        prev->next = NULL;

    return slow;
}

TreeNode* sortedListToBST(ListNode* head) {
    if (head == NULL)
        return NULL;

    if (head->next == NULL)
        return createTreeNode(head->data);

    ListNode* mid = findMiddle(head);

    TreeNode* root = createTreeNode(mid->data);

    root->left = sortedListToBST(head);
    root->right = sortedListToBST(mid->next);

    return root;
}

void preorder(TreeNode* root) {
    if (root) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

int main() {
    ListNode* head = NULL;
    int n, value;

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        scanf("%d", &value);
        append(&head, value);
    }

    TreeNode* root = sortedListToBST(head);

    printf("Preorder Traversal of BST: ");
    preorder(root);
    printf("\n");

    return 0;
}