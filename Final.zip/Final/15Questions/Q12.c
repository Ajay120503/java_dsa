#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

Node* createNode(int value) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}

void append(Node** head, int value) {
    Node* newNode = createNode(value);
    if (*head == NULL) {
        *head = newNode;
        return;
    }

    Node* temp = *head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
}

void display(Node* head) {
    while (head != NULL) {
        printf("%d ", head->data);
        head = head->next;
    }
    printf("\n");
}

Node* deleteDuplicates(Node* head) {
    if (head == NULL)
        return NULL;

    Node dummy;
    dummy.next = head;

    Node* prev = &dummy;
    Node* curr = head;

    while (curr != NULL) {
        int duplicate = 0;

        while (curr->next != NULL && curr->data == curr->next->data) {
            duplicate = 1;
            Node* temp = curr;
            curr = curr->next;
            free(temp);
        }

        if (duplicate) {
            Node* temp = curr;
            curr = curr->next;
            free(temp);
            prev->next = curr;
        } else {
            prev = curr;
            curr = curr->next;
        }
    }

    return dummy.next;
}

int main() {
    Node* head = NULL;
    int n, value;

    printf("Enter number of nodes: ");
    scanf("%d", &n);
    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &value);
        append(&head, value);
    }

    printf("Original List: ");
    display(head);

    head = deleteDuplicates(head);

    printf("After Removing Duplicates: ");
    display(head);

    return 0;
}