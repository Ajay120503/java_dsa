#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

Node* head = NULL;
void create() {
    int n, value;
    Node *newNode, *temp;
    printf("Enter number of nodes: ");
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        printf("Enter value: ");
        scanf("%d", &value);
        newNode = (Node*)malloc(sizeof(Node));
        newNode->data = value;
        if (head == NULL) {
            head = newNode;
            newNode->next = head;
        } else {
            temp = head;
            while (temp->next != head)
                temp = temp->next;

            temp->next = newNode;
            newNode->next = head;
        }
    }
}

void display() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }
    Node* temp = head;
    printf("Circular Linked List: ");
    do {
        printf("%d ", temp->data);
        temp = temp->next;
    } while (temp != head);
    printf("\n");
}

void insertBeginning() {
    int value;
    printf("Enter value: ");
    scanf("%d", &value);
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;

    if (head == NULL) {
        head = newNode;
        newNode->next = head;
    } else {
        Node* temp = head;
        while (temp->next != head)
            temp = temp->next;

        newNode->next = head;
        temp->next = newNode;
        head = newNode;
    }
}

void insertEnd() {
    int value;
    printf("Enter value: ");
    scanf("%d", &value);

    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;
    if (head == NULL) {
        head = newNode;
        newNode->next = head;
    } else {
        Node* temp = head;
        while (temp->next != head)
            temp = temp->next;
        temp->next = newNode;
        newNode->next = head;
    }
}

void deleteBeginning() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }
    if (head->next == head) {
        free(head);
        head = NULL;
    } else {
        Node* temp = head;
        Node* last = head;
        while (last->next != head)
            last = last->next;
        head = head->next;
        last->next = head;
        free(temp);
    }
    printf("Node deleted from beginning\n");
}

void deleteEnd() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }
    if (head->next == head) {
        free(head);
        head = NULL;
    } else {
        Node *temp = head, *prev;
        while (temp->next != head) {
            prev = temp;
            temp = temp->next;
        }
        prev->next = head;
        free(temp);
    }
    printf("Node deleted from end\n");
}

void search() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }
    int key, found = 0;
    printf("Enter element to search: ");
    scanf("%d", &key);
    Node* temp = head;
    do {
        if (temp->data == key) {
            found = 1;
            break;
        }
        temp = temp->next;
    } while (temp != head);
    if (found)
        printf("Element found in the list\n");
    else
        printf("Element not found\n");
}

void countNodes() {
    if (head == NULL) {
        printf("Total Nodes: 0\n");
        return;
    }
    int count = 0;
    Node* temp = head;
    do {
        count++;
        temp = temp->next;
    } while (temp != head);
    printf("Total Nodes: %d\n", count);
}

int main() {
    int choice;
    while (1) {
        printf("\n--- Circular Linked List Menu ---\n");
        printf("1. Create\n");
        printf("2. Display\n");
        printf("3. Insert at Beginning\n");
        printf("4. Insert at End\n");
        printf("5. Delete from Beginning\n");
        printf("6. Delete from End\n");
        printf("7. Search Element\n");
        printf("8. Count Nodes\n");
        printf("9. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: create(); 
                break;
            case 2: display(); 
                break;
            case 3: insertBeginning(); 
                break;
            case 4: insertEnd(); 
                break;
            case 5: deleteBeginning(); 
                break;
            case 6: deleteEnd(); 
                break;
            case 7: search(); 
                break;
            case 8: countNodes(); 
                break;
            case 9: exit(0);
                default: printf("Invalid choice\n");
        }
    }
}