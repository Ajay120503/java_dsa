/*
10. Write a menu-driven C program to perform the following operations on a graph using an
adjacency matrix:
a. Create Graph
b. Display Graph
c. Breadth First Search (BFS)
d. Depth First Search (DFS)
e. Exit
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int adj[MAX][MAX];
int visited[MAX];
int n;

void createGraph() {
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &adj[i][j]);
        }
    }
}

void displayGraph() {
    printf("Adjacency Matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", adj[i][j]);
        }
        printf("\n");
    }
}

void BFS(int start) {
    int queue[MAX], front = 0, rear = 0;

    for (int i = 0; i < n; i++)
        visited[i] = 0;

    queue[rear++] = start;
    visited[start] = 1;

    printf("BFS Traversal: ");

    while (front < rear) {
        int vertex = queue[front++];
        printf("%d ", vertex);

        for (int i = 0; i < n; i++) {
            if (adj[vertex][i] == 1 && !visited[i]) {
                queue[rear++] = i;
                visited[i] = 1;
            }
        }
    }
    printf("\n");
}

void DFS(int vertex) {
    printf("%d ", vertex);
    visited[vertex] = 1;

    for (int i = 0; i < n; i++) {
        if (adj[vertex][i] == 1 && !visited[i]) {
            DFS(i);
        }
    }
}

int main() {
    int choice, start;

    while (1) {
        printf("\n--- Graph Menu ---\n");
        printf("1. Create Graph\n");
        printf("2. Display Graph\n");
        printf("3. Breadth First Search (BFS)\n");
        printf("4. Depth First Search (DFS)\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                createGraph();
                break;

            case 2:
                displayGraph();
                break;

            case 3:
                printf("Enter starting vertex (0 to %d): ", n - 1);
                scanf("%d", &start);
                BFS(start);
                break;

            case 4:
                for (int i = 0; i < n; i++)
                    visited[i] = 0;

                printf("Enter starting vertex (0 to %d): ", n - 1);
                scanf("%d", &start);

                printf("DFS Traversal: ");
                DFS(start);
                printf("\n");
                break;

            case 5:
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }

    return 0;
}