#include <stdio.h>
#include <stdlib.h>

#define MAX_LEVEL 4

typedef struct Node {
    int key;
    struct Node **forward;
} Node;

typedef struct SkipList {
    int level;
    Node *header;
} SkipList;

Node* createNode(int key, int level);
SkipList* createSkipList();
int fixedLevel(int key);
void insertNode(SkipList *list, int key);
void searchNode(SkipList *list, int key);
void deleteNode(SkipList *list, int key);
void displayList(SkipList *list);

Node* createNode(int key, int level) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->key = key;
    newNode->forward = (Node**)malloc(sizeof(Node*) * (level + 1));
    for (int i = 0; i <= level; i++)
        newNode->forward[i] = NULL;
    return newNode;
}


SkipList* createSkipList() {
    SkipList *list = (SkipList*)malloc(sizeof(SkipList));
    list->level = 0;
    list->header = createNode(-1, MAX_LEVEL);
    return list;
}


int fixedLevel(int key) {
    if (key == 10) return 2;
    if (key == 20) return 1;
    if (key == 25) return 2;
    if (key == 30) return 0;
    return 0; 
}

void insertNode(SkipList *list, int key) {
    Node *update[MAX_LEVEL + 1];
    Node *current = list->header;
    
    for (int i = list->level; i >= 0; i--) {
        while (current->forward[i] &&
               current->forward[i]->key < key)
            current = current->forward[i];
        update[i] = current;
    }

    current = current->forward[0];
    if (current == NULL || current->key != key) {
        int newLevel = fixedLevel(key);
        if (newLevel > list->level) {
            for (int i = list->level + 1; i <= newLevel; i++)
                update[i] = list->header;
            list->level = newLevel;
        }
        Node *newNode = createNode(key, newLevel);
        for (int i = 0; i <= newLevel; i++) {
            newNode->forward[i] = update[i]->forward[i];
            update[i]->forward[i] = newNode;
        }
        printf("Inserted: %d (Level %d)\n", key, newLevel);
    } else {
        printf("Duplicate key!\n");
    }
}

void searchNode(SkipList *list, int key) {
    Node *current = list->header;
    for (int i = list->level; i >= 0; i--) {
        while (current->forward[i] &&
               current->forward[i]->key < key)
            current = current->forward[i];
    }
    current = current->forward[0];
    if (current && current->key == key)
        printf("Key %d found\n", key);
    else
        printf("Key %d NOT found\n", key);
}

void deleteNode(SkipList *list, int key) {
    Node *update[MAX_LEVEL + 1];
    Node *current = list->header;
    for (int i = list->level; i >= 0; i--) {
        while (current->forward[i] &&
               current->forward[i]->key < key)
            current = current->forward[i];

        update[i] = current;
    }
    current = current->forward[0];
    if (current && current->key == key) {
        for (int i = 0; i <= list->level; i++) {
            if (update[i]->forward[i] != current)
                break;
            update[i]->forward[i] = current->forward[i];
        }
        free(current);
        while (list->level > 0 &&
               list->header->forward[list->level] == NULL)
            list->level--;

        printf("Deleted: %d\n", key);
    } else {
        printf("Key not found!\n");
    }
}

void displayList(SkipList *list) {
    printf("\n--- Skip List ---\n");
    for (int i = list->level; i >= 0; i--) {
        Node *current = list->header->forward[i];
        printf("Level %d: ", i);
        while (current != NULL) {
            printf("%d ", current->key);
            current = current->forward[i];
        }
        printf("\n");
    }
}

int main() {
    SkipList *list = createSkipList();
    int choice, key;

    while (1) {
        printf("\n===== SKIP LIST MENU =====\n");
        printf("1. Insert Node\n");
        printf("2. Search Node\n");
        printf("3. Delete Node\n");
        printf("4. Display\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter key: ");
                scanf("%d", &key);
                insertNode(list, key);
                break;

            case 2:
                printf("Enter key: ");
                scanf("%d", &key);
                searchNode(list, key);
                break;

            case 3:
                printf("Enter key: ");
                scanf("%d", &key);
                deleteNode(list, key);
                break;

            case 4:
                displayList(list);
                break;

            case 5:
                printf("Exiting...\n");
                exit(0);

            default:
                printf("Invalid choice!\n");
        }
    }
}
