/*
Write a menu-driven C program to perform the following operations on a Binary Search Tree:
a. Insert Node
b. Delete Node
c. Search Node
d. Inorder Traversal
e. Preorder Traversal
f. Postorder Traversal
g. Find Minimum
h. Find the maximum
i. Exit
*/
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *left, *right;
};

struct Node* createNode(int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->left = newNode->right = NULL;
    return newNode;
}

struct Node * insert(struct Node* root, int value) {
  if (root == NULL) 
    return createNode(value);
    
    if (value < root->data) 
      root->left = insert(root->left, value);
    else if (value > root->data) 
      root->right = insert(root->right, value);
      return root;
}

struct Node* findmin(struct Node* root) {
  while (root && root->left !=NULL) 
    root = root->left;
  return root;
}

struct Node* findmax(struct Node* root) {
  while (root && root->right!=NULL)
    root = root->right;
  return root;
}

struct Node* deleteNode(struct Node* root, int value) {
  if (root == NULL) 
    return root;
    
    if (value < root->data) 
      root->left = deleteNode(root->left, value);
    else if (value > root->data) 
      root->right = deleteNode(root->right, value);
    else {
      deleteStatus = 1;
 
      if (root->left == NULL && root->right == NULL) {
      struct Node* temp = root->right;
      free(root);
      return temp;
    }
    else if (root->right == NULL) {
      struct Node* temp = root->left;
      free(root);
      return temp;
    } 

    struct Node* temp = findmin(root->right);
    root->data = temp->data;
    root->right = deleteNode(root->right, temp->data);
  }
  return root;
}


int search (struct Node* root, int value) {
  if (root == NULL)
    return 0;
  if (root->data == value) 
    return 1;
  else if (value < root->data) 
    return search (root->left, value);
  else 
    return search (root->right, value);
}

void inorder(struct Node* root) {
  if (root != NULL) {
    inorder (root->left);
    printf("%d ", root->data);
    inorder(root->right);
  }
}

void preorder (struct Node* root) {
  if (root != NULL) {
    printf("%d ", root->data);
    preorder(root->left);
    preorder(root->right);
  }
}

void postorder (struct Node* root) {
  if (root != NULL) {
    postorder(root->left);
    postorder(root->right);
    printf("%d ", root->data);
  }
}

int main() {
  struct Node* root = NULL;
  int choice, value;

  while (1) {
    printf("\n--BST MENU--\n");
    printf("1. Insert Node \n2. Delete Node \n3. Search Node \n4. Inorder Traversal \n5. Preorder Traversal \n6. Postorder Traversal \n7. Find Minimum \n8. Find Maximum \n9. Exit\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
      switch (choice) {
        case 1:
          printf("Enter value: ");
          scanf("%d", &value);
          root = insert(root, value);
          break;
        case 2:
          printf("Enter value to delete: ");
          scanf("%d", &value);
          root = deleteNode(root, value);
          if (deleteStatus)
            printf("Element Deleted\n");
          else
            printf("Element Not Found\n");
          break;
        case 3:
          printf("Enter value to search: ");
          scanf("%d", &value);
          if (search(root, value))
            printf("Found\n");
          else
            printf("Not Found\n");
          break;
        case 4:
          printf("Inorder: ");
          inorder(root);
          break;
        case 5:
          printf("Preorder: ");
          preorder(root);
          break;
        case 6:
         printf("Postorder: ");
         postorder(root);
         break;
        case 7: {
          struct Node* min = findmin(root);
          if (min)
            printf("Minimum: %d\n", min->data);
          else
            printf("Tree is empty\n");
          break;
        }
        case 8: {
          struct Node* max = findmax(root);
          if (max)
            printf("Maximum: %d\n", max->data);
          else
            printf("Tree is empty\n");
          break;
        }
        case 9:
          exit(0);
        default:
          printf("Invalid choice\n");
        }
    }
    return 0;
}