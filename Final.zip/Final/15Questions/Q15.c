#include <stdio.h>
#include <stdlib.h>

#define MAX 20

int graph[MAX][MAX];
int visited[MAX];
int n;

void createGraph() {
    printf("Enter number of airports: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            graph[i][j] = 0;
    printf("Graph created with %d airports\n", n);
}

void addRoute() {
    int src, dest;
    printf("Enter source airport (0 to %d): ", n - 1);
    scanf("%d", &src);
    printf("Enter destination airport (0 to %d): ", n - 1);
    scanf("%d", &dest);
    if (src >= 0 && src < n && dest >= 0 && dest < n) {
        graph[src][dest] = 1;
        graph[dest][src] = 1;
        printf("Route added between %d and %d\n", src, dest);
    } else {
        printf("Invalid airport number\n");
    }
}

void displayGraph() {
    printf("\nAdjacency Matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            printf("%d ", graph[i][j]);
        printf("\n");
    }
}

void BFS(int start) {
    int queue[MAX], front = 0, rear = 0;
    for (int i = 0; i < n; i++)
        visited[i] = 0;

    queue[rear++] = start;
    visited[start] = 1;

    printf("BFS Traversal: ");

    while (front < rear) {
        int airport = queue[front++];
        printf("%d ", airport);

        for (int i = 0; i < n; i++) {
            if (graph[airport][i] == 1 && !visited[i]) {
                queue[rear++] = i;
                visited[i] = 1;
            }
        }
    }
    printf("\n");
}

void checkConnectivity() {
    int start;
    printf("Enter starting airport (0 to %d): ", n - 1);
    scanf("%d", &start);
    for (int i = 0; i < n; i++)
        visited[i] = 0;

    BFS(start);
    int connected = 1;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            connected = 0;
            break;
        }
    }
    if (connected)
        printf("All airports are connected\n");
    else
        printf("Graph is not fully connected\n");
}

int main() {
    int choice, start;

    while (1) {
        printf("\n--- Airport Network Menu ---\n");
        printf("1. Create Graph\n");
        printf("2. Add Flight Route\n");
        printf("3. Display Routes\n");
        printf("4. Check Connectivity\n");
        printf("5. BFS Traversal\n");
        printf("6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                createGraph();
                break;
            case 2:
                addRoute();
                break;
            case 3:
                displayGraph();
                break;
            case 4:
                checkConnectivity();
                break;
            case 5:
                printf("Enter starting airport (0 to %d): ", n - 1);
                scanf("%d", &start);
                BFS(start);
                break;
            case 6:
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }
    return 0;
}