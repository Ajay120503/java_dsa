/*
Program 2: Prefix to Postfix Conversion Using Stack
Problem Statement:
Write a C program to convert a given Prefix expression into a postfix expression using a stack.
Program Requirements:
Accept prefix expression from user
use a stack for temporary storage
Support operators +, -, *, /
Display postfix expression
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 10

typedef struct {
    char arr[MAX][MAX];
    int top;
} Stack;

void initialize(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return (s->top == -1);
}

void push(Stack *s, char *str) {
    strcpy(s->arr[++(s->top)], str);
}

char* pop(Stack *s) {
    if (isEmpty(s)) {
        printf("Stack Underflow!\n");
        exit(1);
    }
    return s->arr[(s->top)--];
}

int isOperator(char ch) {
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/');
}

int main() {
    Stack s;
    initialize(&s);
    char prefix[MAX];
    char temp[MAX];

    printf("Enter Prefix Expression: ");
    scanf("%s", prefix);

    int len = strlen(prefix);
    for (int i = len - 1; i >= 0; i--) {
        if (isalnum(prefix[i])) {
            temp[0] = prefix[i];
            temp[1] = '\0';
            push(&s, temp);
        }
        else if (isOperator(prefix[i])) {
            char op1[MAX], op2[MAX];
            strcpy(op1, pop(&s));
            strcpy(op2, pop(&s));
            strcpy(temp, op1);
            strcat(temp, op2);
            int l = strlen(temp);
            temp[l] = prefix[i];
            temp[l + 1] = '\0';

            push(&s, temp);
        }
    }
    printf("Postfix Expression: %s\n", pop(&s));
    return 0;
}