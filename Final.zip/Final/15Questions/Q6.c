#include <stdio.h>
#include <stdlib.h>

#define MAX 5

typedef struct {
    int jobId;
    int pages;
} PrintJob;

typedef struct {
    PrintJob jobs[MAX];
    int front;
    int rear;
} Queue;

void initialize(Queue *q) {
    q->front = -1;
    q->rear = -1;
}

int isEmpty(Queue *q) {
    return (q->front == -1);
}

int isFull(Queue *q) {
    return (q->rear == MAX - 1);
}

void addJob(Queue *q, int id, int pages) {
    if (isFull(q)) {
        printf("Queue Full! Cannot add new job\n");
        return;
    }

    if (isEmpty(q))
        q->front = 0;

    q->rear++;
    q->jobs[q->rear].jobId = id;
    q->jobs[q->rear].pages = pages;

    printf("Print Job %d added (%d pages)\n", id, pages);
}

void processJob(Queue *q) {
    if (isEmpty(q)) {
        printf("Queue Empty! No jobs to process\n");
        return;
    }

    PrintJob job = q->jobs[q->front];
    printf("Processing Job ID: %d (%d pages)\n", job.jobId, job.pages);

    q->front++;
    if (q->front > q->rear)
        q->front = q->rear = -1;
}

void displayJobs(Queue *q) {
    if (isEmpty(q)) {
        printf("No pending print jobs\n");
        return;
    }

    printf("Pending Print Jobs:\n");
    for (int i = q->front; i <= q->rear; i++) {
        printf("Job ID: %d, Pages: %d\n",
               q->jobs[i].jobId,
               q->jobs[i].pages);
    }
}

int main() {
    Queue q;
    initialize(&q);

    int choice, id, pages;

    while (1) {
        printf("\n--- Printer Job Scheduling ---\n");
        printf("1. Add Print Job\n");
        printf("2. Process Print Job\n");
        printf("3. Display Pending Jobs\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Enter Job ID: ");
                scanf("%d", &id);
                printf("Enter Number of Pages: ");
                scanf("%d", &pages);
                addJob(&q, id, pages);
                break;
            case 2:
                processJob(&q);
                break;
            case 3:
                displayJobs(&q);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice\n");
        }
    }
    return 0;
}