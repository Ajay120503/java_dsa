#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100
typedef struct {
    char arr[MAX];
    int top;
} Stack;

void initialize(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return (s->top == -1);
}

int isFull(Stack *s) {
    return (s->top == MAX - 1);
}

void push(Stack *s, char ch) {
    if (isFull(s)) {
        printf("Stack Overflow\n");
        exit(1);
    }
    s->arr[++(s->top)] = ch;
}

char pop(Stack *s) {
    if (isEmpty(s)) {
        return '\0';
    }
    return s->arr[(s->top)--];
}

int isMatchingPair(char open, char close) {
    if (open == '(' && close == ')')  return 1;
    if (open == '{' && close == '}') return 1;
    if (open == '[' && close == ']') return 1;
    return 0;
}

int main() {
    Stack s;
    initialize(&s);

    char exp[MAX];
    printf("Enter Expression: ");
    fgets(exp, MAX, stdin);

    for (int i = 0; exp[i] != '\0'; i++) {

        char ch = exp[i];

        if (ch == '(' || ch == '{' || ch == '[') {
            push(&s, ch);
        }

        else if (ch == ')' || ch == '}' || ch == ']') {
            if (isEmpty(&s)) {
                printf("Unbalanced Parentheses\n");
                return 0;
            }

            char top = pop(&s);
            if (!isMatchingPair(top, ch)) {
                printf("Unbalanced Parentheses\n");
                return 0;
            }
        }
    }

    if (isEmpty(&s))
        printf("Balanced Parentheses\n");
    else
        printf("Unbalanced Parentheses\n");
    return 0;
}