/*
14. Write a menu-driven C program for Skip List to perform the following operations:
a. Insert Node
b. Search Node
c. Delete Node
d. Display All Levels of Skip List
e. Exit
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_LEVEL 4
#define P 0.5

typedef struct Node {
    int key;
    struct Node* forward[MAX_LEVEL + 1];
} Node;

typedef struct SkipList {
    int level;
    Node* header;
} SkipList;

Node* createNode(int key, int level) {
    Node* n = (Node*)malloc(sizeof(Node));
    n->key = key;
    for (int i = 0; i <= level; i++)
        n->forward[i] = NULL;
    return n;
}

SkipList* createSkipList() {
    SkipList* list = (SkipList*)malloc(sizeof(SkipList));
    list->level = 0;
    list->header = createNode(-1, MAX_LEVEL);
    return list;
}

int randomLevel() {
    int level = 0;
    while ((float)rand() / RAND_MAX < P && level < MAX_LEVEL)
        level++;
    return level;
}

void insert(SkipList* list, int key) {
    Node* update[MAX_LEVEL + 1];
    Node* x = list->header;

    for (int i = list->level; i >= 0; i--) {
        while (x->forward[i] && x->forward[i]->key < key)
            x = x->forward[i];
        update[i] = x;
    }

    x = x->forward[0];

    if (x == NULL || x->key != key) {
        int lvl = randomLevel();

        if (lvl > list->level) {
            for (int i = list->level + 1; i <= lvl; i++)
                update[i] = list->header;
            list->level = lvl;
        }

        x = createNode(key, lvl);

        for (int i = 0; i <= lvl; i++) {
            x->forward[i] = update[i]->forward[i];
            update[i]->forward[i] = x;
        }

        printf("Inserted %d\n", key);
    }
}

void search(SkipList* list, int key) {
    Node* x = list->header;

    for (int i = list->level; i >= 0; i--) {
        while (x->forward[i] && x->forward[i]->key < key)
            x = x->forward[i];
    }

    x = x->forward[0];

    if (x && x->key == key)
        printf("Element %d found\n", key);
    else
        printf("Element %d not found\n", key);
}

void deleteNode(SkipList* list, int key) {
    Node* update[MAX_LEVEL + 1];
    Node* x = list->header;

    for (int i = list->level; i >= 0; i--) {
        while (x->forward[i] && x->forward[i]->key < key)
            x = x->forward[i];
        update[i] = x;
    }

    x = x->forward[0];

    if (x && x->key == key) {
        for (int i = 0; i <= list->level; i++) {
            if (update[i]->forward[i] != x)
                break;
            update[i]->forward[i] = x->forward[i];
        }

        free(x);

        while (list->level > 0 && list->header->forward[list->level] == NULL)
            list->level--;

        printf("Deleted %d\n", key);
    } else {
        printf("Element not found\n");
    }
}

void display(SkipList* list) {
    printf("\nSkip List Levels:\n");
    for (int i = list->level; i >= 0; i--) {
        Node* node = list->header->forward[i];
        printf("Level %d: ", i);
        while (node != NULL) {
            printf("%d ", node->key);
            node = node->forward[i];
        }
        printf("\n");
    }
}

int main() {
    srand(time(NULL));

    SkipList* list = createSkipList();
    int choice, key;

    while (1) {
        printf("\n--- Skip List Menu ---\n");
        printf("1. Insert Node\n");
        printf("2. Search Node\n");
        printf("3. Delete Node\n");
        printf("4. Display All Levels\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &key);
                insert(list, key);
                break;
            case 2:
                printf("Enter value: ");
                scanf("%d", &key);
                search(list, key);
                break;
            case 3:
                printf("Enter value: ");
                scanf("%d", &key);
                deleteNode(list, key);
                break;
            case 4:
                display(list);
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid choice\n");
        }
    }
}




/*
#include <stdio.h>
#include<stdlib.h>

#define MAX 5
#define P 0.5

struct Node {
    int key;
    struct Node *forward[MAX+1];
};

struct SkipList {
    int level;
    struct Node *header;
};

struct Node* createNode(int key, int level) { 
    struct Node *n = (struct Node*)malloc(sizeof(struct Node));
    n->key = key;
    for (int i=0; i<=level; i++) 
        n->forward[i] = NULL;
    return n;
}

struct SkipList* createSkipList() {
    struct SkipList *list = (structSkipList*)malloc(sizeof(struct SkipList));
    list->level = 0;
    list->header = createNode(-1, MAX);
    return list;
}

int randomLevel() {
    int level = 0;
    while (((float)rand() / RAND_MAX) < P && level<MAX)
        level++;
    return level;
}

void insert(struct SkipList *list, int key) {
    struct Node *update[MAX+1];
    struct Node *current = list->header;

    for (int i=list->level; i>=0; i--) {
        while(current->forward[i] != NULL && current->forward[i]->key < key)
            current = current->forward[i];
        update[i] = current;
    }
    current = current->forward[0];
    if (current == NULL || current->key != key) {
        int rlevel = randomLevel();
        if (rlevel > list->level) {
            for (int i=list->level+1; i<=rlevel; i++)
                update[i] = list->header;
            list->level = rlevel;
        }
        struct Node *n = createNode(key, elevel);
        for (int i=0; i<=rlevel;i++) {
            n->forward[i] = update[i]->forward[i];
            update[i]->forward[i] = n;
        }
        printf("Inserted %d\n", key);
    }
}

void search(struct SkipList *list, int key) {
    struct Node *current = list->header;

    for (int i=list->level; i>=0; i--) {
        while (current->forward[i] && current->forward[i]->key < key) 
            current = current->forward[i];
    }
    current = current->forward[0];
    if(current && current current->key == key) 
        printf("Found %d\n", key)
    else 
        printf("Element Not found");
}

void deleteNode(struct SkipList *list, int key) {
    struct Node *update[MAX+1];
    struct Node *current = list->header;

    for (int i=list->level; i>=0; i--) {
        while (current->forward)
    }
}
*/