#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* prev;
    struct Node* next;
} Node;

Node* head = NULL;
void create() {
    int n, value;
    Node *newNode, *temp;

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Enter value: ");
        scanf("%d", &value);

        newNode = (Node*)malloc(sizeof(Node));
        newNode->data = value;
        newNode->prev = NULL;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
        } else {
            temp = head;
            while (temp->next != NULL)
                temp = temp->next;

            temp->next = newNode;
            newNode->prev = temp;
        }
    }
}

void display() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    Node* temp = head;
    printf("Doubly Linked List: ");

    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

void insertBeginning() {
    int value;
    printf("Enter value: ");
    scanf("%d", &value);

    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = head;

    if (head != NULL)
        head->prev = newNode;

    head = newNode;
}

void insertEnd() {
    int value;
    printf("Enter value: ");
    scanf("%d", &value);
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {
        newNode->prev = NULL;
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newNode;
        newNode->prev = temp;
    }
}

void deleteBeginning() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    Node* temp = head;
    head = head->next;
    if (head != NULL)
        head->prev = NULL;

    free(temp);
    printf("Node deleted from beginning\n");
}

void deleteEnd() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    Node* temp = head;
    if (temp->next == NULL) {
        free(temp);
        head = NULL;
    } else {
        while (temp->next != NULL)
            temp = temp->next;

        temp->prev->next = NULL;
        free(temp);
    }
    printf("Node deleted from end\n");
}

void search() {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    int key, found = 0;
    printf("Enter element to search: ");
    scanf("%d", &key);

    Node* temp = head;
    while (temp != NULL) {
        if (temp->data == key) {
            found = 1;
            break;
        }
        temp = temp->next;
    }

    if (found)
        printf("Element found in the list\n");
    else
        printf("Element not found\n");
}

int main() {
    int choice;

    while (1) {
        printf("\n--- Doubly Linked List Menu ---\n");
        printf("1. Create\n");
        printf("2. Display\n");
        printf("3. Insert at Beginning\n");
        printf("4. Insert at End\n");
        printf("5. Delete from Beginning\n");
        printf("6. Delete from End\n");
        printf("7. Search Element\n");
        printf("8. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: create(); break;
            case 2: display(); break;
            case 3: insertBeginning(); break;
            case 4: insertEnd(); break;
            case 5: deleteBeginning(); break;
            case 6: deleteEnd(); break;
            case 7: search(); break;
            case 8: exit(0);
            default: printf("Invalid choice\n");
        }
    }

    return 0;
}