/*
Stack Implementation in C using ADT
definestack structure
implement initialze, push, pop, peek operations
check stack overflow and underflow
display appropriate messages 
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 3

typedef struct {
    int arr[MAX];
    int top;
} Stack;

void initialize(Stack *s) {
    s->top = -1;
}

// full
int isFull(Stack *s) {
    if (s->top == MAX - 1)
        return 1;
    return 0;
}

// empty
int isEmpty(Stack *s) {
    if (s->top == -1)
        return 1;
    return 0;
}

// Push 
void push(Stack *s, int value) {
    if (isFull(s)) {
        printf("--Stack Overflow! Cannot push--\n", value);
        return;
    }
    s->top++;
    s->arr[s->top] = value;
    printf("%d pushed into stack\n", value);
}

// Pop 
int pop(Stack *s) {
    if (isEmpty(s)) {
        printf("--Stack Underflow! Cannot pop--\n");
        return -1;
    }
    int popped = s->arr[s->top];
    s->top--;
    return popped;
}

// Peek 
int peek(Stack *s) {
    if (isEmpty(s)) {
        printf("Stack is empty\n");
        return -1;
    }
    return s->arr[s->top];
}

int main() {
    Stack s;
    initialize(&s);

    int choice, value;

    while (1) {
        printf("\n--- Stack Menu ---\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Peek\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to push: ");
                scanf("%d", &value);
                push(&s, value);
                break;

            case 2:
                value = pop(&s);
                if (value != -1)
                    printf("Popped element: %d\n", value);
                break;

            case 3:
                value = peek(&s);
                if (value != -1)
                    printf("Top element: %d\n", value);
                break;

            case 4:
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }

    return 0;
}