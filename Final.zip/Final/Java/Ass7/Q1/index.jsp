<html>
<head>
    <title>File Search</title>
</head>
<body>
    <h2>Search Files by Extension</h2>

    <form action="display.jsp" method="get">
        Enter Extension: 
        <input type="text" name="ext" placeholder="e.g. txt, java" required>
        <input type="submit" value="Search">
    </form>
</body>
</html>