<%
    String color = request.getParameter("color");

    if (color == null || color.trim().equals("")) {
        color = "white"; // default
    }
%>

<html>
<head>
    <title>Selected Color</title>
</head>

<body style="background-color:<%= color %>;">

    <h2 align="center">
        Selected Color: <%= color.toUpperCase() %>
    </h2>

</body>
</html>