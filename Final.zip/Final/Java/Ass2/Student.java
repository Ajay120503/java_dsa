import MScCAI.MScCAIMarks;
import MScCAII.MScCAIIMarks;

public class Student {

    int roll;
    String name;
    MScCAIMarks m1;
    MScCAIIMarks m2;

    public Student(int roll, String name, MScCAIMarks m1, MScCAIIMarks m2) {
        this.roll = roll;
        this.name = name;
        this.m1 = m1;
        this.m2 = m2;
    }

    public int getTotal() {
        return m1.getTotal() + m2.getTotal();
    }

    public double getPercentage() {
        return getTotal() / 4.0;
    }

    public String getGrade() {
        double p = getPercentage();

        if (p >= 70) return "A";
        else if (p >= 60) return "B";
        else if (p >= 50) return "C";
        else if (p >= 40) return "Pass Class";
        else return "FAIL";
    }

    public void display() {
        System.out.println("Roll No   : " + roll);
        System.out.println("Name      : " + name);
        System.out.println("Total     : " + getTotal());
        System.out.println("Percentage: " + getPercentage());
        System.out.println("Grade     : " + getGrade());
		System.out.println("\n");
    }
}