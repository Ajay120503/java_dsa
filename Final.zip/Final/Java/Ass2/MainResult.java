/*
Write a program to create a Package “MScCAI” which has a class 
MScCAIMarks (members – SemITotal, SemIITotal).
Create another package “MScCAII” which has a class MScCAIIMarks
(members – SemITotal, SemIITotal). Create n objects of Student class (having
rollNumber, name, MScCAIMarks and MScCAIIMarks). Add the marks of
MScCAI and MScCAII.
Calculate the Grade (‘A’ >=70, ‘B’>=60, ‘C’>=50, Pass Class>=40 else ‘FAIL’)
and display the result of student in proper format.
*/

import java.util.Scanner;
import MScCAI.*;
import MScCAII.*;

public class MainResult {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();

        Student[] students = new Student[n];

        for (int i = 0; i < n; i++) {

            System.out.println("\nEnter details for Student " + (i + 1));

            System.out.print("Roll Number: ");
            int roll = sc.nextInt();
            sc.nextLine();

            System.out.print("Name: ");
            String name = sc.nextLine();

            // MScCAI Marks
            int s1, s2;
            while (true) {
                System.out.print("Enter MScCAI Sem I & II Marks: ");
                s1 = sc.nextInt();
                s2 = sc.nextInt();

                if (s1 >= 0 && s1 <= 100 && s2 >= 0 && s2 <= 100)
                    break;
                else
                    System.out.println("Invalid! Enter marks between 0–100.\n");
            }

            MScCAIMarks m1 = new MScCAIMarks(s1, s2);

            // MScCAII Marks
            int s3, s4;
            while (true) {
                System.out.print("Enter MScCAII Sem I & II Marks: ");
                s3 = sc.nextInt();
                s4 = sc.nextInt();

                if (s3 >= 0 && s3 <= 100 && s4 >= 0 && s4 <= 100)
                    break;
                else
                    System.out.println("Invalid! Enter marks between 0–100.\n");
            }

            MScCAIIMarks m2 = new MScCAIIMarks(s3, s4);

            students[i] = new Student(roll, name, m1, m2);
        }

        // Display Results
        System.out.println("\n========== RESULT ==========");
        for (Student s : students) {
            s.display();
        }

        sc.close();
    }
}