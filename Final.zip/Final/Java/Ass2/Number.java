/*
Create a package named NumOperation having three different classes.
a. Prime Number
b. Perfect Number
c. Armstrong Number
Write a program to accept number ‘n’ from the user and check whether
it is prime number or perfect number or Armstrong number 
using the above NumOperation package.
*/

import java.util.Scanner;
import numoperation.*;

public class Number {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int n = sc.nextInt();

        if (PrimeNumber.isPrime(n)) {
            System.out.println(n + " is a Prime Number");
        } else {
            System.out.println(n + " is NOT a Prime Number");
        }

        if (PerfectNumber.isPerfect(n)) {
            System.out.println(n + " is a Perfect Number");
        } else {
            System.out.println(n + " is NOT a Perfect Number");
        }

        if (ArmstrongNumber.isArmstrong(n)) {
            System.out.println(n + " is an Armstrong Number");
        } else {
            System.out.println(n + " is NOT an Armstrong Number");
        }

        sc.close();
    }
}