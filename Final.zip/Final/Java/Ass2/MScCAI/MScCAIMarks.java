package MScCAI;

public class MScCAIMarks {

    public int sem1;
    public int sem2;

    public MScCAIMarks(int sem1, int sem2) {
        if (isValid(sem1) && isValid(sem2)) {
            this.sem1 = sem1;
            this.sem2 = sem2;
        } else {
            throw new IllegalArgumentException("Marks must be between 0 and 100");
        }
    }

    private boolean isValid(int m) {
        return m >= 0 && m <= 100;
    }

    public int getTotal() {
        return sem1 + sem2;
    }
}