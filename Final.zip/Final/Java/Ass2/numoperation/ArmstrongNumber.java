package numoperation;

public class ArmstrongNumber {

    public static boolean isArmstrong(int n) {
        int original = n;
        int sum = 0;

        int digits = String.valueOf(n).length();

        while (n != 0) {
            int rem = n % 10;
            sum += Math.pow(rem, digits);
            n /= 10;
        }

        return sum == original;
    }
}