import javax.swing.*;
import java.awt.event.*;

public class LoginScreen extends JFrame implements ActionListener {

    JTextField usernameField;
    JPasswordField passwordField;
    JButton submitBtn, cancelBtn;

    LoginScreen() {

        setTitle("Login Screen");
        setSize(400, 250);
        setLayout(null);

        // Labels
        JLabel userLabel = new JLabel("User Name");
        userLabel.setBounds(50, 50, 100, 25);
        add(userLabel);

        JLabel passLabel = new JLabel("Password");
        passLabel.setBounds(50, 90, 100, 25);
        add(passLabel);

        // Text fields
        usernameField = new JTextField();
        usernameField.setBounds(150, 50, 150, 25);
        add(usernameField);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 90, 150, 25);
        add(passwordField);

        // Buttons
        submitBtn = new JButton("Submit");
        submitBtn.setBounds(80, 140, 100, 30);
        add(submitBtn);

        cancelBtn = new JButton("Cancel");
        cancelBtn.setBounds(200, 140, 100, 30);
        add(cancelBtn);

        // Action listeners
        submitBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // center window
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword()).trim();

        // Submit button logic
        if (e.getSource() == submitBtn) {

            // Check empty fields
            if (user.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty");
            }
            // Check username == password
            else if (user.equals(pass)) {
                JOptionPane.showMessageDialog(this, "Correct login details");
            }
            else {
                JOptionPane.showMessageDialog(this, "Wrong details");
                passwordField.setText(""); // clear password
            }
        }

        // Cancel button logic
        if (e.getSource() == cancelBtn) {
            usernameField.setText("");
            passwordField.setText("");
        }
    }

    public static void main(String[] args) {
        new LoginScreen();
    }
}