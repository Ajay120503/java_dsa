import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StudentResult extends JFrame implements ActionListener {

    private JTextField txtRoll, txtName;
    private JTextField[][] marks = new JTextField[5][3]; // CE, ESE, Total
    private JTextField txtGrandTotal, txtGrade;
    private JButton btnCalculate;

    public StudentResult() {

        setTitle("Student Result");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        // Top Panel
        JPanel topPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 10, 50));

        topPanel.add(new JLabel("Roll Number:"));
        txtRoll = new JTextField();
        topPanel.add(txtRoll);

        topPanel.add(new JLabel("Name:"));
        txtName = new JTextField();
        topPanel.add(txtName);

        add(topPanel, BorderLayout.NORTH);

        // Center Panel
        JPanel centerPanel = new JPanel(new GridLayout(6, 4, 10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50));

        centerPanel.add(new JLabel("Sub Name"));
        centerPanel.add(new JLabel("CE"));
        centerPanel.add(new JLabel("ESE"));
        centerPanel.add(new JLabel("Total"));

        for (int i = 0; i < 5; i++) {
            centerPanel.add(new JLabel("Sub" + (i + 1)));

            for (int j = 0; j < 3; j++) {
                marks[i][j] = new JTextField();

                // Total column should not be editable
                if (j == 2) {
                    marks[i][j].setEditable(false);
                }

                centerPanel.add(marks[i][j]);
            }
        }

        add(centerPanel, BorderLayout.CENTER);

        // Bottom Panel
        JPanel bottomPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 50, 20, 50));

        bottomPanel.add(new JLabel("Grand Total:"));
        txtGrandTotal = new JTextField();
        txtGrandTotal.setEditable(false);
        bottomPanel.add(txtGrandTotal);

        bottomPanel.add(new JLabel("Grade:"));
        txtGrade = new JTextField();
        txtGrade.setEditable(false);
        bottomPanel.add(txtGrade);

        btnCalculate = new JButton("Calculate");
        bottomPanel.add(btnCalculate);

        add(bottomPanel, BorderLayout.SOUTH);

        btnCalculate.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // Roll No validation
        String roll = txtRoll.getText().trim();
        if (!roll.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Roll No must be integer");
            return;
        }

        // Name validation
        String name = txtName.getText().trim();
        if (!name.matches("[a-zA-Z ]+")) {
            JOptionPane.showMessageDialog(this, "Name must contain only alphabets");
            return;
        }

        int grandTotal = 0;

        for (int i = 0; i < 5; i++) {

            try {
                int ce = Integer.parseInt(marks[i][0].getText().trim());
                int ese = Integer.parseInt(marks[i][1].getText().trim());

                // Marks validation (0–50)
                if (ce < 0 || ce > 50 || ese < 0 || ese > 50) {
                    JOptionPane.showMessageDialog(this, "Marks must be between 0 and 50");
                    return;
                }

                int total = ce + ese;
                marks[i][2].setText(String.valueOf(total));

                grandTotal += total;

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter valid numeric marks");
                return;
            }
        }

        txtGrandTotal.setText(String.valueOf(grandTotal));

        double percentage = grandTotal / 5.0;

        // Grade calculation
        if (percentage >= 70)
            txtGrade.setText("A");
        else if (percentage >= 60)
            txtGrade.setText("B");
        else if (percentage >= 50)
            txtGrade.setText("C");
        else if (percentage >= 40)
            txtGrade.setText("Pass");
        else
            txtGrade.setText("Fail");
    }

    public static void main(String[] args) {
        new StudentResult().setVisible(true);
    }
}