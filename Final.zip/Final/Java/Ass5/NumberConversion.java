import javax.swing.*;
import java.awt.event.*;

public class NumberConversion {

    NumberConversion() {

        JFrame frame = new JFrame("Number Conversion");
        frame.setSize(350,300);
        frame.setLayout(null);

        JLabel lblDec = new JLabel("Decimal");
        lblDec.setBounds(40, 30, 100, 25);

        JLabel lblBin = new JLabel("Binary");
        lblBin.setBounds(40, 70, 100, 25);

        JLabel lblOct = new JLabel("Octal");
        lblOct.setBounds(40, 110, 100, 25);

        JLabel lblHex = new JLabel("Hexadecimal");
        lblHex.setBounds(40, 150, 100, 25);

        JTextField txtDec = new JTextField();
        txtDec.setBounds(150, 30, 130, 25);

        JTextField txtBin = new JTextField();
        txtBin.setBounds(150, 70, 130, 25);
        txtBin.setEditable(false);   

        JTextField txtOct = new JTextField();
        txtOct.setBounds(150, 110, 130, 25);
        txtOct.setEditable(false);   

        JTextField txtHex = new JTextField();
        txtHex.setBounds(150, 150, 130, 25);
        txtHex.setEditable(false);

        JButton btnConvert = new JButton("Convert");
        btnConvert.setBounds(60, 200, 100, 30);

        JButton btnExit = new JButton("Exit");
        btnExit.setBounds(180, 200, 100, 30);

        frame.add(lblDec);
        frame.add(lblBin);
        frame.add(lblOct);
        frame.add(lblHex);

        frame.add(txtDec);
        frame.add(txtBin);
        frame.add(txtOct);
        frame.add(txtHex);

        frame.add(btnConvert);
        frame.add(btnExit);

        btnConvert.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int num = Integer.parseInt(txtDec.getText());

                    txtBin.setText(Integer.toBinaryString(num));
                    txtOct.setText(Integer.toOctalString(num));
                    txtHex.setText(Integer.toHexString(num).toUpperCase());

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Enter valid decimal number");
                }
            }
        });

        btnExit.addActionListener(e -> System.exit(0));

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new NumberConversion();
    }
}