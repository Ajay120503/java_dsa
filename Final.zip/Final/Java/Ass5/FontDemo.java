import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FontDemo extends JFrame implements ActionListener {

    JComboBox<String> fontFamily;
    JTextField fontSize;
    JCheckBox bold, italic;
    JTextField text;
    JButton applyBtn, exitBtn;

    FontDemo() {

        setTitle("Font Demo");
        setSize(400, 300);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Font Family
        JLabel lblFamily = new JLabel("Font Family:");
        lblFamily.setBounds(30, 30, 100, 25);
        add(lblFamily);

        String fonts[] = GraphicsEnvironment.getLocalGraphicsEnvironment()
                .getAvailableFontFamilyNames();

        fontFamily = new JComboBox<>(fonts);
        fontFamily.setBounds(150, 30, 150, 25);
        add(fontFamily);

        // Font Size
        JLabel lblSize = new JLabel("Font Size:");
        lblSize.setBounds(30, 70, 100, 25);
        add(lblSize);

        fontSize = new JTextField();
        fontSize.setBounds(150, 70, 100, 25);
        add(fontSize);

        // Font Style
        JLabel lblStyle = new JLabel("Font Style:");
        lblStyle.setBounds(30, 110, 100, 25);
        add(lblStyle);

        bold = new JCheckBox("Bold");
        bold.setBounds(150, 110, 70, 25);
        add(bold);

        italic = new JCheckBox("Italic");
        italic.setBounds(230, 110, 70, 25);
        add(italic);

        // Text Field
        text = new JTextField("Hello Everyone");
        text.setBounds(100, 150, 200, 30);
        text.setEditable(false);
        add(text);

        // Buttons
        applyBtn = new JButton("Apply");
        applyBtn.setBounds(80, 200, 100, 30);
        add(applyBtn);

        exitBtn = new JButton("Exit");
        exitBtn.setBounds(200, 200, 100, 30);
        add(exitBtn);

        applyBtn.addActionListener(this);
        exitBtn.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        // Apply button logic
        if (e.getSource() == applyBtn) {

            try {
                String selectedFont = (String) fontFamily.getSelectedItem();
                int size = Integer.parseInt(fontSize.getText().trim());

                if (size <= 0) {
                    JOptionPane.showMessageDialog(this, "Enter valid font size");
                    return;
                }

                int style = Font.PLAIN;

                if (bold.isSelected() && italic.isSelected())
                    style = Font.BOLD | Font.ITALIC;
                else if (bold.isSelected())
                    style = Font.BOLD;
                else if (italic.isSelected())
                    style = Font.ITALIC;

                Font f = new Font(selectedFont, style, size);
                text.setFont(f);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Font size must be a number");
            }
        }

        // Exit button logic
        if (e.getSource() == exitBtn) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new FontDemo();
    }
}