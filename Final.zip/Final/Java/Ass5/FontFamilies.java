/*
Write a program to obtain and display the names of the available font
families on multiple lines of text
*/

import javax.swing.*;
import java.awt.*;

public class FontFamilies {

    FontFamilies() {

        JFrame frame = new JFrame("Font Families");
        frame.setSize(400,350);
        frame.setLayout(null);

        JLabel lblTitle = new JLabel("Available Font Families");
        lblTitle.setBounds(110, 10, 200, 25);

        JTextArea area = new JTextArea();
        area.setEditable(false);

        JScrollPane scroll = new JScrollPane(area);
        scroll.setBounds(40, 40, 300, 240);

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();

        String fonts[] = ge.getAvailableFontFamilyNames();

        for(String f : fonts) {
            area.append(f + "\n");
        }

        frame.add(lblTitle);
        frame.add(scroll);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new FontFamilies();
    }
}