/*
Write a program to accept a string as a command line argument and check whether it is a file or directory. 
If it is a directory, list the contents of the directory, count how many files the directory has and 
display the name of the files in that directory having extensions .txt. 
If it is a file, display all information about the file (path, size, attributes etc).
*/

import java.io.File;

public class FileDirectoryInfo {

    public static void main(String[] args) {

        // Check command line argument
        if (args.length == 0) {
            System.out.println("Please provide a file/directory path as argument.");
            return;
        }

        File f = new File(args[0]);

        // Check if exists
        if (!f.exists()) {
            System.out.println("File or Directory does not exist.");
            return;
        }

        // If it is a directory
        if (f.isDirectory()) {

            System.out.println("It is a Directory\n");

            File[] list = f.listFiles();
            int fileCount = 0;

            System.out.println("Contents of Directory:");
            for (File file : list) {
                System.out.println(file.getName());

                if (file.isFile()) {
                    fileCount++;

                    // Check for .txt files
                    if (file.getName().endsWith(".txt")) {
                        System.out.println("  -> TXT File: " + file.getName());
                    }
                }
            }

            System.out.println("\nTotal number of files: " + fileCount);
        }

        // If it is a file
        else if (f.isFile()) {

            System.out.println("It is a File\n");

            System.out.println("File Name     : " + f.getName());
            System.out.println("Path          : " + f.getAbsolutePath());
            System.out.println("Size (bytes)  : " + f.length());
            System.out.println("Readable      : " + f.canRead());
            System.out.println("Writable      : " + f.canWrite());
            System.out.println("Executable    : " + f.canExecute());
            System.out.println("Hidden        : " + f.isHidden());
            System.out.println("Last Modified : " + f.lastModified());
        }
    }
}