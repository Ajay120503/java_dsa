class ThreadOne extends Thread{
	public void run(){
		while(true){
			System.out.println("Thread One");
			try{
				Thread.sleep(100);
			}catch(InterruptedException e){
				System.out.println(e);
			}
		}	
	}
}

class ThreadTwo extends Thread{
	public void run(){
		while(true){
			System.out.println("Thread Two");
			try{
				Thread.sleep(100);
			}catch(InterruptedException e){
				System.out.println(e);
			}
		}	
	}
}


public class TwoThread{
	public static void main(String args[]){
		
		ThreadOne threadOne = new ThreadOne();
		ThreadTwo threadTwo= new ThreadTwo(); 
		threadOne.start();
		threadTwo.start();
		
	}
}
