/*
Write a java program to calculate the sum and average of an array of 1000
integers (generated randomly) using 10 threads. 
Each thread calculates the sum of 100 integers. 
Use these values to calculate average. [Use join method]
*/

import java.util.Random;

// Thread class
class SumThread extends Thread {

    int[] arr;
    int start, end;
    int partialSum = 0;

    // Constructor
    SumThread(int[] arr, int start, int end) {
        this.arr = arr;
        this.start = start;
        this.end = end;
    }

    // Each thread calculates sum of its part
    public void run() {
        for (int i = start; i < end; i++) {
            partialSum += arr[i];
        }
        System.out.println("Thread " + getName() + " Sum: " + partialSum);
    }

    // Getter for sum
    public int getSum() {
        return partialSum;
    }
}

// Main class
public class SumAvg {

    public static void main(String[] args) {

        int[] arr = new int[1000];
        Random rand = new Random();

        // Generate random numbers
        for (int i = 0; i < 1000; i++) {
            arr[i] = rand.nextInt(100); // 0–99
        }

        SumThread[] threads = new SumThread[10];

        // Create 10 threads (each handles 100 elements)
        for (int i = 0; i < 10; i++) {
            threads[i] = new SumThread(arr, i * 100, (i + 1) * 100);
            threads[i].start();
        }

        int totalSum = 0;

        // Wait for all threads using join()
        try {
            for (int i = 0; i < 10; i++) {
                threads[i].join();
                totalSum += threads[i].getSum();
            }
        } catch (InterruptedException e) {
            System.out.println(e);
        }

        // Calculate average
        double average = totalSum / 1000.0;

        // Output
        System.out.println("\nTotal Sum = " + totalSum);
        System.out.println("Average   = " + average);
    }
}