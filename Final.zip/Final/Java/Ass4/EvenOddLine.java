/*
Write a program to accept a file called “input.txt” as command line argument. 
Write all text as even line numbers from the file in “even.txt” and
all text at odd line numbers from the file in “odd.txt”.
*/

import java.io.*;

public class EvenOddLine
{
	public static void main(String args[])throws IOException
	{
		if(args.length==0)
		{
			System.out.println("plz provide file name as cmd \n");
			return;
		}

		File inputFile=new File(args[0]);

		if(!inputFile.exists())
		{
			System.out.println("file does not exist \n");
			return;
		}
		try
		{
			BufferedReader br=new BufferedReader(new FileReader(args[0]));
			BufferedWriter odd=new BufferedWriter(new FileWriter("odd_lines.txt"));
			BufferedWriter even=new BufferedWriter(new FileWriter("even_lines.txt"));

			String line;

			int lineNumber=1;

			while((line=br.readLine())!= null)
			{
				if(lineNumber%2==0)
				{
					even.write(line);
					even.newLine();
				}
				else
				{
					odd.write(line);
					odd.newLine();
				}

				lineNumber++;
			}
		
			br.close();
			odd.close();
			even.close();
		
			System.out.println("Lines separated successfullyy");
		}
		catch(Exception e)
		{
			System.out.println("Error"+e.getMessage());
		}//catch
	}//psvm
}//class
