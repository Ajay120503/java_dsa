/*
Write a program to accept a filename as command line argument and print
the number of lines, number of characters and number of words in the file.
*/

import java.io.*;

public class NoOfLines {

    public static void main(String[] args) {

        // Check argument
        if (args.length == 0) {
            System.out.println("Please provide file name as argument.");
            return;
        }

        File file = new File(args[0]);

        // Check file exists
        if (!file.exists()) {
            System.out.println("File does not exist.");
            return;
        }

        int lines = 0, words = 0, characters = 0;

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            // Read file line by line
            while ((line = br.readLine()) != null) {
                lines++;

                // Count characters
                characters += line.length();

                // Count words
                String[] w = line.trim().split("\\s+");
                if (line.trim().length() > 0)
                    words += w.length;
            }

            br.close();

            // Output
            System.out.println("Number of lines      : " + lines);
            System.out.println("Number of words      : " + words);
            System.out.println("Number of characters : " + characters);

        } catch (IOException e) {
            System.out.println("Error reading file.");
        }
    }
}