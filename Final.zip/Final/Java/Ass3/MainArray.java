/*
Create an interface Java_Array with methods: 
Array_reverse(), array_copy(), array_max(). 
Write a program to accept array elements from the user and
implement above methods on it to generate relevant output.
*/

import java.util.*;

// Interface
interface JavaArray {
    void arrayReverse();
    void arrayCopy();
    void arrayMax();
}

// Class implementing interface
class MainArray implements JavaArray {

    int[] arr;

    MainArray(int[] arr) {
        this.arr = arr;
    }

    // Reverse Array
    public void arrayReverse() {
        System.out.print("Reversed Array: ");
        for (int i = arr.length - 1; i >= 0; i--) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    // Copy Array
    public void arrayCopy() {
        int[] copy = arr.clone();
        System.out.println("Copied Array: " + Arrays.toString(copy));
    }

    // Maximum Element
    public void arrayMax() {
        int max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max)
                max = arr[i];
        }
        System.out.println("Maximum Element: " + max);
    }

    // Main Method
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements: ");
        int n = sc.nextInt();

        int[] a = new int[n];

        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }

        MainArray op = new MainArray(a);

        op.arrayReverse();
        op.arrayCopy();
        op.arrayMax();

        sc.close();
    }
}