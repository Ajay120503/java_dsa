/*
Create an interface “CreditCardInterface” with methods:
viewCreditAmount(), userCard(), payCredit() and increaseLimit(). 
Create a class SilverCardCustomer (name, cardnumber (16 digits), creditAmount – initialized to 0, creditLimit – set to 50,000) which implements the above interface. 
Inherit class GoldCardCustomer from SilverCardCustomer having the same methods but creditLimit to 1,00,000. 
Create an object of each class and perform operations. 
Display appropriate messages for success or failure of transactions. (Use method overriding)
i. useCard() method increases the creditAmount by a specific amount upto creditiLimit
ii. payCredit() reduces the creditAmount by a specific amount.
iii. increaseLimit() increases the creditLimit for GoldCardCustomer (only 3 times, not more than 5000Rs. each time)
*/

import java.util.Scanner;

// Interface
interface CreditCardInterface {
    void viewCreditAmount();
    void useCard(double amount);
    void payCredit(double amount);
    void increaseLimit(double amount);
}

// Silver Card Class
class SilverCardCustomer implements CreditCardInterface {

    protected String name;
    protected String cardNumber;
    protected double creditAmount = 0;
    protected double creditLimit = 50000;

    SilverCardCustomer(String name, String cardNumber) {
        this.name = name;
        this.cardNumber = cardNumber;
    }

    public void viewCreditAmount() {
        System.out.println("Current Credit Used: " + creditAmount);
        System.out.println("Credit Limit: " + creditLimit);
    }

    public void useCard(double amount) {
        if (creditAmount + amount <= creditLimit) {
            creditAmount += amount;
            System.out.println("Transaction Successful!");
        } else {
            System.out.println("Transaction Failed! Limit exceeded.");
        }
    }

    public void payCredit(double amount) {
        if (amount <= creditAmount) {
            creditAmount -= amount;
            System.out.println("Payment Successful!");
        } else {
            System.out.println("Payment Failed! Amount exceeds credit used.");
        }
    }

    public void increaseLimit(double amount) {
        System.out.println("Limit increase not allowed for Silver Card.");
    }
}

// Gold Card Class
class GoldCardCustomer extends SilverCardCustomer {

    private int increaseCount = 0;

    GoldCardCustomer(String name, String cardNumber) {
        super(name, cardNumber);
        this.creditLimit = 100000;
    }

    // Override increaseLimit
    public void increaseLimit(double amount) {

        if (increaseCount >= 3) {
            System.out.println("Limit increase failed! Maximum attempts reached.");
            return;
        }

        if (amount > 5000) {
            System.out.println("Limit increase failed! Max 5000 allowed at a time.");
            return;
        }

        creditLimit += amount;
        increaseCount++;
        System.out.println("Limit increased successfully!");
    }
}

// Main Class
public class MainCard {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Silver Customer
        System.out.println("Enter Silver Card Customer Details:");
        System.out.print("Name: ");
        String name1 = sc.nextLine();

        System.out.print("Card Number (16 digits): ");
        String card1 = sc.nextLine();

        SilverCardCustomer silver = new SilverCardCustomer(name1, card1);

        // Gold Customer
        System.out.println("\nEnter Gold Card Customer Details:");
        System.out.print("Name: ");
        String name2 = sc.nextLine();

        System.out.print("Card Number (16 digits): ");
        String card2 = sc.nextLine();

        GoldCardCustomer gold = new GoldCardCustomer(name2, card2);

        // Operations
        System.out.println("\n--- Silver Card Operations ---");
        silver.useCard(20000);
        silver.payCredit(5000);
        silver.increaseLimit(3000);
        silver.viewCreditAmount();

        System.out.println("\n--- Gold Card Operations ---");
        gold.useCard(70000);
        gold.payCredit(10000);
        gold.increaseLimit(4000);
        gold.increaseLimit(3000);
        gold.increaseLimit(2000);
        gold.increaseLimit(1000); // should fail
        gold.viewCreditAmount();

        sc.close();
    }
}