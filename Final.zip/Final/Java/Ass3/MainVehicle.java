import java.util.Scanner;

class Vehicle {
    String company;
    double price;

    Vehicle(String company, double price) {
        this.company = company;
        this.price = price;
    }

    void display() {
        System.out.println("Company: " + company);
        System.out.println("Price: " + price);
    }
}

class LightMotorVehicle extends Vehicle {
    double mileage;

    LightMotorVehicle(String company, double price, double mileage) {
        super(company, price);
        this.mileage = mileage;
    }

    void display() {
        super.display();
        System.out.println("Mileage: " + mileage);
        System.out.println("-----------------------");
    }
}

class HeavyMotorVehicle extends Vehicle {
    double capacity;

    HeavyMotorVehicle(String company, double price, double capacity) {
        super(company, price);
        this.capacity = capacity;
    }

    void display() {
        super.display();
        System.out.println("Capacity (tons): " + capacity);
        System.out.println("-----------------------");
    }
}

public class MainVehicle {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of vehicles: ");
        int n = sc.nextInt();

        Vehicle[] v = new Vehicle[n]; 

        for (int i = 0; i < n; i++) {

            System.out.println("\n1. Light Motor Vehicle");
            System.out.println("2. Heavy Motor Vehicle");
            System.out.print("Enter vehicle type: ");
            int ch = sc.nextInt();

            System.out.print("Enter Company: ");
            String company = sc.next();

            System.out.print("Enter Price: ");
            double price = sc.nextDouble();

            if (ch == 1) {

                System.out.print("Enter Mileage: ");
                double mileage = sc.nextDouble();

                v[i] = new LightMotorVehicle(company, price, mileage);

            } else if (ch == 2) {

                System.out.print("Enter Capacity (in tons): ");
                double capacity = sc.nextDouble();

                v[i] = new HeavyMotorVehicle(company, price, capacity);
            }
        }

        System.out.println("\n----- Vehicle Details -----");

        for (int i = 0; i < n; i++) {
            v[i].display();
        }

    }
}