/*
Define a class Employee having private members – 
id, name, department,salary. 
Define default and parameterized constructors. 
Create a subclass called “Manager” with private member bonus. 
Define method display in both the classes. 
Create n objects of the Manager class and 
display the details of the manager having the maximum total salary (salary + bonus).
*/

import java.util.Scanner;

class Employee {
    private int id;
    private String name, department;
    protected double salary;

    Employee() {
        id = 0;
        name = "NA";
        department = "NA";
        salary = 0.0f;
    }

    Employee(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Department: " + department);
        System.out.println("Salary: " + salary);
    }
}

class MainEmployee extends Employee {
    private double bonus;

    MainEmployee(int id, String name, String dept, double salary, double bonus) {
        super(id, name, dept, salary);
        this.bonus = bonus;
    }

    double totalSalary() {
        return salary + bonus;
    }

    void display() {
        super.display();
        System.out.println("Bonus: " + bonus);
        System.out.println("Total Salary: " + totalSalary());
        System.out.println("\n");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of managers: ");
        int n = sc.nextInt();

        MainEmployee[] m = new MainEmployee[n];
        int maxIndex = 0;

        for (int i = 0; i < n; i++) {
            System.out.println("\nManager " + (i + 1));
            System.out.print("Enter ID: ");
            int id = sc.nextInt();
            System.out.print("Enter Name: ");
            String name = sc.next();
            System.out.print("Enter Department: ");
            String dept = sc.next();
            System.out.print("Enter Salary: ");
            double salary = sc.nextDouble();
            System.out.print("Enter Bonus: ");
            double bonus = sc.nextDouble();

            m[i] = new MainEmployee(id, name, dept, salary, bonus);
            if (m[i].totalSalary() > m[maxIndex].totalSalary())
                maxIndex = i;
        }

        System.out.println("\nManager with Maximum Salary:");
        m[maxIndex].display();
    }
}
