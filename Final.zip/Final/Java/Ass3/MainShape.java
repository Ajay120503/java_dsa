/*
Create an abstract class Shape with methods calc_area and calc_volume.
Derive three classes Sphere(radius), Cone (radius, height) and Cylinder
(radius, height), Box (length, breadth, height) from it. 
Calculate area and volume of all. 
(Use Method overriding and Reference variable concept).
*/

import java.util.Scanner;

// Abstract Class
abstract class Shape {
    abstract void calcArea();
    abstract void calcVolume();
}

// Sphere
class Sphere extends Shape {
    double r;

    Sphere(double r) {
        this.r = r;
    }

    void calcArea() {
        System.out.println("Sphere Area   : " + (4 * Math.PI * r * r));
    }

    void calcVolume() {
        System.out.println("Sphere Volume : " + ((4.0 / 3) * Math.PI * r * r * r));
    }
}

// Cone
class Cone extends Shape {
    double r, h;

    Cone(double r, double h) {
        this.r = r;
        this.h = h;
    }

    void calcArea() {
        double l = Math.sqrt(r * r + h * h);
        System.out.println("Cone Area     : " + (Math.PI * r * (r + l)));
    }

    void calcVolume() {
        System.out.println("Cone Volume   : " + ((1.0 / 3) * Math.PI * r * r * h));
    }
}

// Cylinder
class Cylinder extends Shape {
    double r, h;

    Cylinder(double r, double h) {
        this.r = r;
        this.h = h;
    }

    void calcArea() {
        System.out.println("Cylinder Area : " + (2 * Math.PI * r * (r + h)));
    }

    void calcVolume() {
        System.out.println("Cylinder Vol  : " + (Math.PI * r * r * h));
    }
}

// Box (renamed from MainShape)
class Box extends Shape {
    double l, b, h;

    Box(double l, double b, double h) {
        this.l = l;
        this.b = b;
        this.h = h;
    }

    void calcArea() {
        System.out.println("Box Area      : " + (2 * (l * b + b * h + l * h)));
    }

    void calcVolume() {
        System.out.println("Box Volume    : " + (l * b * h));
    }
}

// Main Class
public class MainShape {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Shape s;

        // Sphere
        System.out.print("Enter radius of Sphere: ");
        double r = sc.nextDouble();
        s = new Sphere(r);
        s.calcArea();
        s.calcVolume();

        // Cone
        System.out.print("\nEnter radius and height of Cone: ");
        double r1 = sc.nextDouble();
        double h1 = sc.nextDouble();
        s = new Cone(r1, h1);
        s.calcArea();
        s.calcVolume();

        // Cylinder
        System.out.print("\nEnter radius and height of Cylinder: ");
        double r2 = sc.nextDouble();
        double h2 = sc.nextDouble();
        s = new Cylinder(r2, h2);
        s.calcArea();
        s.calcVolume();

        // Box
        System.out.print("\nEnter length, breadth and height of Box: ");
        double l = sc.nextDouble();
        double b = sc.nextDouble();
        double h = sc.nextDouble();
        s = new Box(l, b, h);
        s.calcArea();
        s.calcVolume();

        sc.close();
    }
}