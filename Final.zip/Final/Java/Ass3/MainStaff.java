/*
Define an abstract class “Staff” with members name and address. 
Define two sub-classes of this class – “FullTimeStaff” (department, salsry) and “PartTimeStaff” (number-of-hours, rate perhour). 
Define appropriate constructors. 
Create n objects which could be of either FullTimeStaff or PartTimeStaff class by asking the user’s choice. 
Display details of all “FullTimeStaff” objects and all “PartTimeStaff” objects. 
(Use Method overriding and Reference variable concept).
*/

import java.util.Scanner;

abstract class Staff {
    String name;
    String address;

    Staff(String name, String address) {
        this.name = name;
        this.address = address;
    }

    abstract void display();
}

class FullTimeStaff extends Staff {
    String department;
    double salary;

    FullTimeStaff(String name, String address, String department, double salary) {
        super(name, address);
        this.department = department;
        this.salary = salary;
    }

    void display() {
        System.out.println("\n--- Full Time Staff ---");
        System.out.println("Name: " +name+"\nAddress: "+address+"\nDepartment: "+department+"\nSalary: "+salary);
    }
}

class PartTimeStaff extends Staff {
    int hours;
    double ratePerHour;

    PartTimeStaff(String name, String address,
                  int hours, double ratePerHour) {
        super(name, address);
        this.hours = hours;
        this.ratePerHour = ratePerHour;
    }

    void display() {
        System.out.println("\n--- Part Time Staff ---");
        System.out.println("Name: " +name+"\nAddress: "+address+"\nHours Worked: "+hours+"\nRate Per Hour: "+ratePerHour+"\nTotal Salary: "+(hours * ratePerHour));
    }
}

public class MainStaff {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of staff: ");
        int n = sc.nextInt();
        sc.nextLine();

        Staff[] s = new Staff[n];  

        for (int i = 0; i < n; i++) {

            System.out.println("\n1. Full Time Staff");
            System.out.println("2. Part Time Staff");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Address: ");
            String address = sc.nextLine();

            if (choice == 1) {

                System.out.print("Enter Department: ");
                String dept = sc.nextLine();

                System.out.print("Enter Salary: ");
                double salary = sc.nextDouble();

                s[i] = new FullTimeStaff(name, address, dept, salary);

            } else if (choice == 2) {

                System.out.print("Enter Number of Hours: ");
                int hours = sc.nextInt();

                System.out.print("Enter Rate per Hour: ");
                double rate = sc.nextDouble();

                s[i] = new PartTimeStaff(name, address, hours, rate);
            }
        }

        System.out.println("\n===== Full Time Staff Details =====");
        for (int i = 0; i < n; i++) {
            if (s[i] instanceof FullTimeStaff) {
                s[i].display();
            }
        }

        System.out.println("\n===== Part Time Staff Details =====");
        for (int i = 0; i < n; i++) {
            if (s[i] instanceof PartTimeStaff) {
                s[i].display();
            }
        }
    }
}