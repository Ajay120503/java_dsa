import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentNavigation extends JFrame implements ActionListener {

    JTextField t1, t2, t3, t4;
    JButton first, next, prev, last;

    Connection con;
    Statement stmt;
    ResultSet rs;

    public StudentNavigation() {
        setTitle("Student Records");

        t1 = new JTextField(10);
        t2 = new JTextField(10);
        t3 = new JTextField(10);
        t4 = new JTextField(5);

        first = new JButton("First");
        next = new JButton("Next");
        prev = new JButton("Previous");
        last = new JButton("Last");

        setLayout(new FlowLayout());

        add(new JLabel("Roll No")); add(t1);
        add(new JLabel("Name")); add(t2);
        add(new JLabel("Marks")); add(t3);
        add(new JLabel("Record No")); add(t4);

        add(first); add(next);
        add(prev); add(last);

        first.addActionListener(this);
        next.addActionListener(this);
        prev.addActionListener(this);
        last.addActionListener(this);

        try {
            con = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/mcafy7", "mcafy7", "");


            stmt = con.createStatement(
                ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);

		stmt.executeUpdate("create table if not exists Student(rollNo int, name varchar(20),marks int)");
		stmt.executeUpdate("INSERT INTO Student VALUES(12, 'Ajay', 200)");
		stmt.executeUpdate("INSERT INTO Student VALUES(13, 'Harshda', 300)");
		stmt.executeUpdate("INSERT INTO Student VALUES(14, 'Akash', 250)");
            rs = stmt.executeQuery("SELECT * FROM Student");

            if (rs.next()) display();

        } catch (Exception e) {
            e.printStackTrace();
        }

        setSize(250,300);
        setVisible(true);
    }

    void display() throws Exception {
        t1.setText(rs.getString(1));
        t2.setText(rs.getString(2));
        t3.setText(rs.getString(3));
        t4.setText(String.valueOf(rs.getRow()));
    }

    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == first) rs.first();
            if (e.getSource() == last) rs.last();
            if (e.getSource() == next && !rs.isLast()) rs.next();
            if (e.getSource() == prev && !rs.isFirst()) rs.previous();

            display();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new StudentNavigation();
    }
}
