import java.sql.*;
import java.util.Scanner;

public class AlumniCRUD {
    static Connection con;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            con = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/mcafy7", "mcafy7", "");

		Statement stmt = con.createStatement();
        stmt.executeUpdate("Drop table if exists Alumni");
		stmt.executeUpdate("create table if not exists Alumni(name varchar(20), address varchar(500),dest varchar(500) ,contact varchar(10), email varchar(50), year int)");

            int choice;
            do {
                System.out.println("\n--- Alumni MENU ---");
                System.out.println("1. Add");
                System.out.println("2. Delete");
                System.out.println("3. Update");
                System.out.println("4. Search");
                System.out.println("5. Exit");
                System.out.print("Enter choice: ");
                choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {
                    case 1: add(); break;
                    case 2: delete(); break;
                    case 3: update(); break;
                    case 4: search(); break;
                }
            } while (choice != 5);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void add() throws Exception {
        System.out.print("Enter Name: ");
        String name = sc.nextLine();

        if (name.isEmpty())
            throw new Exception("Invalid Name!");

        System.out.print("Address: ");
        String address = sc.nextLine();

        System.out.print("Destination: ");
        String dest = sc.nextLine();

        System.out.print("Contact No: ");
        String contact = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Year: ");
        int year = sc.nextInt();

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO Alumni VALUES (?, ?, ?, ?, ?, ?)");

        ps.setString(1, name);
        ps.setString(2, address);
        ps.setString(3, dest);
        ps.setString(4, contact);
        ps.setString(5, email);
        ps.setInt(6, year);

        ps.executeUpdate();
        System.out.println("Record Added!");
    }

    static void delete() throws Exception {
        System.out.print("Enter Name to delete: ");
        String name = sc.nextLine();

        PreparedStatement ps = con.prepareStatement(
            "DELETE FROM Alumni WHERE Name=?");

        ps.setString(1, name);
        ps.executeUpdate();

        System.out.println("Record Deleted!");
    }

    static void update() throws Exception {
        System.out.print("Enter Name to update: ");
        String name = sc.nextLine();

        System.out.print("New Address: ");
        String address = sc.nextLine();

        PreparedStatement ps = con.prepareStatement(
            "UPDATE Alumni SET Address=? WHERE Name=?");

        ps.setString(1, address);
        ps.setString(2, name);

        ps.executeUpdate();
        System.out.println("Record Updated!");
    }

    static void search() throws Exception {
        System.out.print("Enter Name to search: ");
        String name = sc.nextLine();

        PreparedStatement ps = con.prepareStatement(
            "SELECT * FROM Alumni WHERE Name=?");

        ps.setString(1, name);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            System.out.println("Name: " + rs.getString(1));
            System.out.println("Address: " + rs.getString(2));
            System.out.println("Destination: " + rs.getString(3));
            System.out.println("Contact: " + rs.getString(4));
            System.out.println("Email: " + rs.getString(5));
            System.out.println("Year: " + rs.getInt(6));
        } else {
            System.out.println("Record not found!");
        }
    }
}
