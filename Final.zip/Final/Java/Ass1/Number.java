/*
Define a class MyNumber having one private int data member. 
Write a default constructor to initialize it to 0 and another constructor to initialize itto value pass by user (Use this). 
Write methods to check whether this data member is Negative, Positive, Zero, Odd or Even. 
Create an object in main.
Use command line arguments to pass a value to object. 
(Hint: convert string argument to integer) and perform the above checking.
*/

class MyNumber {
    private int number;

    // Default constructor
    MyNumber() {
        this.number = 0;
    }

    // Parameterized constructor using 'this'
    MyNumber(int number) {
        this.number = number;
    }

    // Check Positive
    void isPositive() {
        if (number > 0)
            System.out.println("Number is Positive");
    }

    // Check Negative
    void isNegative() {
        if (number < 0)
            System.out.println("Number is Negative");
    }

    // Check Zero
    void isZero() {
        if (number == 0)
            System.out.println("Number is Zero");
    }

    // Check Even
    void isEven() {
        if (number % 2 == 0)
            System.out.println("Number is Even");
    }

    // Check Odd
    void isOdd() {
        if (number % 2 != 0)
            System.out.println("Number is Odd");
    }
}

public class Number {
    public static void main(String args[]) {

        if (args.length == 0) {
            System.out.println("Please provide a number as command line argument.");
            return;
        }

        // Convert String to int
        int value = Integer.parseInt(args[0]);

        // Create object using parameterized constructor
        MyNumber obj = new MyNumber(value);

        obj.isPositive();
        obj.isNegative();
        obj.isZero();
        obj.isEven();
        obj.isOdd();
    }
}
