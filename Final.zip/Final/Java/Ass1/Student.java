/*
Define a Student class (roll number, name, percentage). 
Define a default and parameterized constructor. 
Create n objects of the Student class. 
Accept details from the user for each object. 
Define a static method “sortStudent” which sorts all data on the basis of percentage.
*/

import java.util.Scanner;

class Student {

    int rollNo;
    String name;
    double percentage;

    // Default constructor
    Student() {
        rollNo = 0;
        name = "NA";
        percentage = 0.0;
    }

    // Parameterized constructor
    Student(int rollNo, String name, double percentage) {
        this.rollNo = rollNo;
        this.name = name;
        this.percentage = percentage;
    }

    // Display method
    void display() {
        System.out.println("\nRoll No     : " + rollNo);
        System.out.println("Name        : " + name);
        System.out.println("Percentage  : " + percentage);
    }

    // Sorting students based on percentage (Descending)
    static void sortStudents(Student[] students, int n) {
        Student temp;

        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                if (students[i].percentage < students[j].percentage) {
                    temp = students[i];
                    students[i] = students[j];
                    students[j] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();

        Student[] students = new Student[n];

        // Input
        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Student " + (i + 1));

            System.out.print("Roll No: ");
            int roll = sc.nextInt();
            sc.nextLine(); // clear buffer

            System.out.print("Name: ");
            String name = sc.nextLine();

            System.out.print("Percentage: ");
            double percentage = sc.nextDouble();

            students[i] = new Student(roll, name, percentage);
        }

        // Sorting
        sortStudents(students, n);

        // Output
        System.out.println("\n\nSorted Student Details by percentage");
        for (Student s : students) {
            s.display();
        }

        sc.close();
    }
}