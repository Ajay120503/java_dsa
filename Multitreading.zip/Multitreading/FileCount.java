import java.io.*;

public class FileCount {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("Provide filename");
            return;
        }

        FileReader fr = new FileReader(args[0]);
        BufferedReader br = new BufferedReader(fr);

        int lines = 0, words = 0, chars = 0;
        String line;

        while ((line = br.readLine()) != null) {
            lines++;
            chars += line.length();

            String[] w = line.split("\\s+");
            words += w.length;
        }

        br.close();

        System.out.println("Lines: " + lines);
        System.out.println("Words: " + words);
        System.out.println("Characters: " + chars);
    }
}