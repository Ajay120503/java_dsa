class MyThread extends Thread {
    String message;

    MyThread(String msg) {
        message = msg;
    }

    public void run() {
        while (true) {
            System.out.println("Thread: " + currentThread().getName());
            System.out.println("Message: " + message);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

public class ThreadDemo {
    public static void main(String[] args) {
        MyThread t1 = new MyThread("Hello from Thread 1");
        MyThread t2 = new MyThread("Hello from Thread 2");

        t1.start();
        t2.start();
    }
}