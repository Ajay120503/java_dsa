import java.util.Random;

class SumThread extends Thread {
    int[] arr;
    int start, end;
    int sum = 0;

    SumThread(int[] arr, int start, int end) {
        this.arr = arr;
        this.start = start;
        this.end = end;
    }

    public void run() {
        for (int i = start; i < end; i++) {
            sum += arr[i];
        }
    }
}

public class MultiThreadSum {
    public static void main(String[] args) throws Exception {
        int[] arr = new int[1000];
        Random r = new Random();

        for (int i = 0; i < 1000; i++) {
            arr[i] = r.nextInt(100);
        }

        SumThread[] threads = new SumThread[10];

        for (int i = 0; i < 10; i++) {
            threads[i] = new SumThread(arr, i * 100, (i + 1) * 100);
            threads[i].start();
        }

        int totalSum = 0;

        for (int i = 0; i < 10; i++) {
            threads[i].join();
            totalSum += threads[i].sum;
        }

        double avg = totalSum / 1000.0;

        System.out.println("Total Sum = " + totalSum);
        System.out.println("Average = " + avg);
    }
}