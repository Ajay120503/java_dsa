import java.io.*;

public class FileDirectoryCheck {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Provide file/directory name");
            return;
        }

        File f = new File(args[0]);

        if (f.isDirectory()) {
            System.out.println("It is a Directory");

            File[] files = f.listFiles();
            int count = 0;

            for (File file : files) {
                if (file.isFile()) {
                    count++;
                    if (file.getName().endsWith(".txt")) {
                        System.out.println(file.getName());
                    }
                }
            }

            System.out.println("Total files: " + count);
        } 
        else if (f.isFile()) {
            System.out.println("It is a File");
            System.out.println("Path: " + f.getAbsolutePath());
            System.out.println("Size: " + f.length() + " bytes");
            System.out.println("Readable: " + f.canRead());
            System.out.println("Writable: " + f.canWrite());
        } 
        else {
            System.out.println("Invalid path");
        }
    }
}