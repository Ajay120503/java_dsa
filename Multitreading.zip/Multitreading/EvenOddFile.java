import java.io.*;

public class EvenOddFile {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("Provide filename");
            return;
        }

        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        BufferedWriter even = new BufferedWriter(new FileWriter("even.txt"));
        BufferedWriter odd = new BufferedWriter(new FileWriter("odd.txt"));

        String line;
        int lineNo = 1;

        while ((line = br.readLine()) != null) {
            if (lineNo % 2 == 0) {
                even.write(line);
                even.newLine();
            } else {
                odd.write(line);
                odd.newLine();
            }
            lineNo++;
        }

        br.close();
        even.close();
        odd.close();

        System.out.println("Data written to even.txt and odd.txt");
    }
}